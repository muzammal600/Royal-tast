import {
  AdminUser,
  CartItem,
  Category,
  Chef,
  ContactMessage,
  Deal,
  GalleryItem,
  MenuItem,
  Offer,
  Order,
  OrderStatus,
  Reservation,
  SiteSettings,
  Testimonial,
  WeeklySpecial
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_CHEFS,
  INITIAL_DEALS,
  INITIAL_GALLERY,
  INITIAL_MENU_ITEMS,
  INITIAL_OFFERS,
  INITIAL_SITE_SETTINGS,
  INITIAL_TESTIMONIALS,
  INITIAL_WEEKLY_SPECIALS
} from '../data/initialData';
import { getSupabaseClient, isSupabaseConfigured } from '../lib/supabase';

export interface RoyalTasteSnapshot {
  categories: Category[];
  menuItems: MenuItem[];
  weeklySpecials: WeeklySpecial[];
  deals: Deal[];
  offers: Offer[];
  chefs: Chef[];
  gallery: GalleryItem[];
  testimonials: Testimonial[];
  siteSettings: SiteSettings;
  orders: Order[];
  reservations: Reservation[];
  messages: ContactMessage[];
  newsletterSubscribers: string[];
  cart: CartItem[];
  appliedPromoCode: string | null;
  currentAdmin: AdminUser | null;
  activeOrderCode: string | null;
  cartCalculations: {
    subtotal: number;
    discount: number;
    deliveryFee: number;
    isFreeDelivery: boolean;
    freeDeliveryThreshold: number;
    totalAmount: number;
    totalItemsCount: number;
  };
}

type Listener = () => void;

class RoyalTasteStore {
  private categories: Category[] = [];
  private menuItems: MenuItem[] = [];
  private weeklySpecials: WeeklySpecial[] = [];
  private deals: Deal[] = [];
  private offers: Offer[] = [];
  private chefs: Chef[] = [];
  private gallery: GalleryItem[] = [];
  private testimonials: Testimonial[] = [];
  private siteSettings: SiteSettings = INITIAL_SITE_SETTINGS;
  private orders: Order[] = [];
  private reservations: Reservation[] = [];
  private messages: ContactMessage[] = [];
  private newsletterSubscribers: string[] = [];
  private cart: CartItem[] = [];
  private appliedPromoCode: string | null = null;
  private activeOrderCode: string | null = null;

  // Auth State
  private currentAdmin: AdminUser | null = null;
  private lastActivityTimestamp: number = Date.now();
  private inactivityTimer: NodeJS.Timeout | null = null;

  private listeners: Set<Listener> = new Set();
  private initialized: boolean = false;
  private snapshot: RoyalTasteSnapshot | null = null;

  constructor() {
    this.init();
    this.setupInactivityListener();
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  public getSnapshot(): RoyalTasteSnapshot {
    if (!this.snapshot) {
      this.updateSnapshot();
    }
    return this.snapshot!;
  }

  private updateSnapshot() {
    this.snapshot = {
      categories: this.categories,
      menuItems: this.menuItems,
      weeklySpecials: this.weeklySpecials,
      deals: this.deals,
      offers: this.offers,
      chefs: this.chefs,
      gallery: this.gallery,
      testimonials: this.testimonials,
      siteSettings: this.siteSettings,
      orders: this.orders,
      reservations: this.reservations,
      messages: this.messages,
      newsletterSubscribers: this.newsletterSubscribers,
      cart: this.cart,
      appliedPromoCode: this.appliedPromoCode,
      currentAdmin: this.currentAdmin,
      activeOrderCode: this.activeOrderCode,
      cartCalculations: this.getCartCalculations()
    };
  }

  private notify() {
    this.updateSnapshot();
    this.saveToStorage();
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (err) {
        console.error('Store notification error:', err);
      }
    });
  }

  private init() {
    if (this.initialized) return;

    // Load from localStorage or defaults
    try {
      const storedCategories = localStorage.getItem('rt_categories');
      this.categories = storedCategories ? JSON.parse(storedCategories) : INITIAL_CATEGORIES;

      const storedItems = localStorage.getItem('rt_menu_items');
      this.menuItems = storedItems ? JSON.parse(storedItems) : INITIAL_MENU_ITEMS;

      const storedSpecials = localStorage.getItem('rt_weekly_specials');
      this.weeklySpecials = storedSpecials ? JSON.parse(storedSpecials) : INITIAL_WEEKLY_SPECIALS;

      const storedDeals = localStorage.getItem('rt_deals');
      this.deals = storedDeals ? JSON.parse(storedDeals) : INITIAL_DEALS;

      const storedOffers = localStorage.getItem('rt_offers');
      this.offers = storedOffers ? JSON.parse(storedOffers) : INITIAL_OFFERS;

      const storedChefs = localStorage.getItem('rt_chefs');
      this.chefs = storedChefs ? JSON.parse(storedChefs) : INITIAL_CHEFS;

      const storedGallery = localStorage.getItem('rt_gallery');
      this.gallery = storedGallery ? JSON.parse(storedGallery) : INITIAL_GALLERY;

      const storedTestimonials = localStorage.getItem('rt_testimonials');
      this.testimonials = storedTestimonials ? JSON.parse(storedTestimonials) : INITIAL_TESTIMONIALS;

      const storedSettings = localStorage.getItem('rt_site_settings');
      this.siteSettings = storedSettings ? JSON.parse(storedSettings) : INITIAL_SITE_SETTINGS;

      const storedOrders = localStorage.getItem('rt_orders');
      this.orders = storedOrders ? JSON.parse(storedOrders) : [];

      const storedReservations = localStorage.getItem('rt_reservations');
      this.reservations = storedReservations ? JSON.parse(storedReservations) : [];

      const storedMessages = localStorage.getItem('rt_messages');
      this.messages = storedMessages ? JSON.parse(storedMessages) : [];

      const storedSubs = localStorage.getItem('rt_newsletter');
      this.newsletterSubscribers = storedSubs ? JSON.parse(storedSubs) : ['guest@royaltaste.pk'];

      const storedCart = localStorage.getItem('rt_cart');
      this.cart = storedCart ? JSON.parse(storedCart) : [];

      const storedActiveOrder = localStorage.getItem('rt_active_order_code');
      this.activeOrderCode = storedActiveOrder || null;

      const storedAdminSession = localStorage.getItem('rt_admin_session');
      if (storedAdminSession) {
        this.currentAdmin = JSON.parse(storedAdminSession);
      }
    } catch (e) {
      console.warn('Error reading local cache, falling back to initial data', e);
      this.categories = INITIAL_CATEGORIES;
      this.menuItems = INITIAL_MENU_ITEMS;
      this.weeklySpecials = INITIAL_WEEKLY_SPECIALS;
      this.deals = INITIAL_DEALS;
      this.offers = INITIAL_OFFERS;
      this.chefs = INITIAL_CHEFS;
      this.gallery = INITIAL_GALLERY;
      this.testimonials = INITIAL_TESTIMONIALS;
      this.siteSettings = INITIAL_SITE_SETTINGS;
    }

    this.initialized = true;
    this.updateSnapshot();

    // Check remote Supabase sync if connected
    this.syncFromSupabase();
  }

  private saveToStorage() {
    try {
      localStorage.setItem('rt_categories', JSON.stringify(this.categories));
      localStorage.setItem('rt_menu_items', JSON.stringify(this.menuItems));
      localStorage.setItem('rt_weekly_specials', JSON.stringify(this.weeklySpecials));
      localStorage.setItem('rt_deals', JSON.stringify(this.deals));
      localStorage.setItem('rt_offers', JSON.stringify(this.offers));
      localStorage.setItem('rt_chefs', JSON.stringify(this.chefs));
      localStorage.setItem('rt_gallery', JSON.stringify(this.gallery));
      localStorage.setItem('rt_testimonials', JSON.stringify(this.testimonials));
      localStorage.setItem('rt_site_settings', JSON.stringify(this.siteSettings));
      localStorage.setItem('rt_orders', JSON.stringify(this.orders));
      localStorage.setItem('rt_reservations', JSON.stringify(this.reservations));
      localStorage.setItem('rt_messages', JSON.stringify(this.messages));
      localStorage.setItem('rt_newsletter', JSON.stringify(this.newsletterSubscribers));
      localStorage.setItem('rt_cart', JSON.stringify(this.cart));
      if (this.activeOrderCode) {
        localStorage.setItem('rt_active_order_code', this.activeOrderCode);
      } else {
        localStorage.removeItem('rt_active_order_code');
      }
      if (this.currentAdmin) {
        localStorage.setItem('rt_admin_session', JSON.stringify(this.currentAdmin));
      } else {
        localStorage.removeItem('rt_admin_session');
      }
    } catch (e) {
      console.error('Storage write error', e);
    }
  }

  private async syncFromSupabase() {
    const client = getSupabaseClient();
    if (!client) return;

    try {
      const [catRes, itemRes, settingsRes, ordersRes, resRes] = await Promise.all([
        client.from('categories').select('*').order('display_order', { ascending: true }),
        client.from('menu_items').select('*'),
        client.from('site_settings').select('*').limit(1).maybeSingle(),
        client.from('orders').select('*').order('created_at', { ascending: false }),
        client.from('reservations').select('*').order('created_at', { ascending: false })
      ]);

      let hasChanges = false;
      if (catRes.data && catRes.data.length > 0) {
        this.categories = catRes.data;
        hasChanges = true;
      }
      if (itemRes.data && itemRes.data.length > 0) {
        this.menuItems = itemRes.data;
        hasChanges = true;
      }
      if (settingsRes.data) {
        this.siteSettings = { ...this.siteSettings, ...settingsRes.data };
        hasChanges = true;
      }
      if (ordersRes.data && ordersRes.data.length > 0) {
        this.orders = ordersRes.data;
        hasChanges = true;
      }
      if (resRes.data && resRes.data.length > 0) {
        this.reservations = resRes.data;
        hasChanges = true;
      }

      if (hasChanges) {
        this.notify();
      }
    } catch (err) {
      console.warn('Supabase remote sync bypassed:', err);
    }
  }

  // Activity & Auto-Logout (15 mins)
  private setupInactivityListener() {
    const resetTimer = () => {
      this.lastActivityTimestamp = Date.now();
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('mousemove', resetTimer);
      window.addEventListener('keydown', resetTimer);
      window.addEventListener('click', resetTimer);
      window.addEventListener('scroll', resetTimer);

      this.inactivityTimer = setInterval(() => {
        if (this.currentAdmin) {
          const elapsed = Date.now() - this.lastActivityTimestamp;
          // 15 minutes = 900,000 ms
          if (elapsed > 15 * 60 * 1000) {
            console.log('Inactivity timeout reached, logging out admin');
            this.logoutAdmin();
          }
        }
      }, 30000);
    }
  }

  // --- Getters ---
  public getCategories() { return this.categories; }
  public getMenuItems() { return this.menuItems; }
  public getWeeklySpecials() { return this.weeklySpecials; }
  public getDeals() { return this.deals; }
  public getOffers() { return this.offers; }
  public getChefs() { return this.chefs; }
  public getGallery() { return this.gallery; }
  public getTestimonials() { return this.testimonials; }
  public getSiteSettings() { return this.siteSettings; }
  public getOrders() { return this.orders; }
  public getReservations() { return this.reservations; }
  public getMessages() { return this.messages; }
  public getNewsletterSubscribers() { return this.newsletterSubscribers; }
  public getCart() { return this.cart; }
  public getAppliedPromoCode() { return this.appliedPromoCode; }
  public getCurrentAdmin() { return this.currentAdmin; }
  public getActiveOrderCode() { return this.activeOrderCode; }

  // --- Cart Operations ---
  public addToCart(item: MenuItem, variantName?: string, quantity: number = 1) {
    const selectedVariant = item.size_variants?.find((v) => v.name === variantName);
    const unitPrice = selectedVariant ? selectedVariant.price : item.price;

    const existingIndex = this.cart.findIndex(
      (c) => c.item.id === item.id && c.selectedVariant?.name === selectedVariant?.name
    );

    if (existingIndex > -1) {
      this.cart[existingIndex].quantity += quantity;
    } else {
      this.cart.push({
        item,
        selectedVariant,
        quantity,
        unitPrice
      });
    }

    this.notify();
  }

  public updateCartQuantity(index: number, quantity: number) {
    if (quantity <= 0) {
      this.cart.splice(index, 1);
    } else {
      this.cart[index].quantity = quantity;
    }
    this.notify();
  }

  public removeFromCart(index: number) {
    this.cart.splice(index, 1);
    this.notify();
  }

  public clearCart() {
    this.cart = [];
    this.appliedPromoCode = null;
    this.notify();
  }

  public applyPromoCode(code: string): { success: boolean; message: string; discountPercent?: number } {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      this.appliedPromoCode = null;
      this.notify();
      return { success: false, message: 'Promo code cleared' };
    }

    if (cleanCode === 'FIRST20') {
      this.appliedPromoCode = 'FIRST20';
      this.notify();
      return { success: true, message: '20% First Order discount applied!', discountPercent: 20 };
    }

    const matchedOffer = this.offers.find((o) => o.code?.toUpperCase() === cleanCode && o.is_active);
    if (matchedOffer) {
      this.appliedPromoCode = matchedOffer.code!;
      this.notify();
      return {
        success: true,
        message: `${matchedOffer.discount_value}% discount applied!`,
        discountPercent: matchedOffer.discount_value
      };
    }

    return { success: false, message: 'Invalid or expired coupon code' };
  }

  public getCartCalculations() {
    let subtotal = 0;
    this.cart.forEach((c) => {
      // Check item-level or category-level discount
      let effectiveUnit = c.unitPrice;
      if (c.item.discount_percent && c.item.discount_percent > 0) {
        effectiveUnit = effectiveUnit * (1 - c.item.discount_percent / 100);
      } else if (c.item.category_id === 'desserts') {
        // -10% on desserts
        effectiveUnit = effectiveUnit * 0.9;
      }
      subtotal += Math.round(effectiveUnit) * c.quantity;
    });

    let discount = 0;
    if (this.appliedPromoCode === 'FIRST20') {
      discount = Math.round(subtotal * 0.2);
    }

    const freeDeliveryThreshold = this.siteSettings.free_delivery_minimum || 2000;
    const isFreeDelivery = subtotal >= freeDeliveryThreshold;
    const deliveryFee = subtotal > 0 ? (isFreeDelivery ? 0 : 200) : 0;
    const totalAmount = Math.max(0, subtotal - discount + deliveryFee);

    return {
      subtotal,
      discount,
      deliveryFee,
      isFreeDelivery,
      freeDeliveryThreshold,
      totalAmount,
      totalItemsCount: this.cart.reduce((sum, item) => sum + item.quantity, 0)
    };
  }

  // --- Order Placement ---
  public async placeOrder(customerData: {
    name: string;
    phone: string;
    address: string;
    notes?: string;
    lat?: number;
    lng?: number;
    locationAccuracy?: number;
  }): Promise<{ success: boolean; orderNumber: string; order: Order }> {
    const calculations = this.getCartCalculations();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `RT-${randomSuffix}`;

    const newOrder: Order = {
      id: `ord_${Date.now()}_${randomSuffix}`,
      order_number: orderNumber,
      created_at: new Date().toISOString(),
      customer: customerData,
      items: this.cart.map((c) => ({
        item_id: c.item.id,
        item_name: c.item.name,
        variant_name: c.selectedVariant?.name,
        price: c.unitPrice,
        quantity: c.quantity,
        total: c.unitPrice * c.quantity
      })),
      subtotal: calculations.subtotal,
      discount: calculations.discount,
      delivery_fee: calculations.deliveryFee,
      total_amount: calculations.totalAmount,
      status: 'Pending',
      payment_method: 'Cash on Delivery',
      promo_code: this.appliedPromoCode || undefined,
      estimated_delivery_time: '35 - 45 Minutes'
    };

    this.orders.unshift(newOrder);
    this.activeOrderCode = orderNumber;
    this.clearCart();
    this.notify();

    // Sync to Supabase if connected
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('orders').insert([
          {
            id: newOrder.id,
            order_number: newOrder.order_number,
            customer_name: newOrder.customer.name,
            customer_phone: newOrder.customer.phone,
            customer_address: newOrder.customer.address,
            customer_notes: newOrder.customer.notes,
            customer_lat: newOrder.customer.lat,
            customer_lng: newOrder.customer.lng,
            location_accuracy: newOrder.customer.locationAccuracy,
            items: newOrder.items,
            subtotal: newOrder.subtotal,
            discount: newOrder.discount,
            delivery_fee: newOrder.delivery_fee,
            total_amount: newOrder.total_amount,
            status: newOrder.status,
            payment_method: newOrder.payment_method,
            promo_code: newOrder.promo_code,
            estimated_delivery_time: newOrder.estimated_delivery_time
          }
        ]);
      } catch (err) {
        console.warn('Order could not be pushed to Supabase remote table', err);
      }
    }

    return { success: true, orderNumber, order: newOrder };
  }

  public getOrderByCode(code: string): Order | undefined {
    const cleanCode = code.trim().toUpperCase();
    return this.orders.find((o) => o.order_number.toUpperCase() === cleanCode);
  }

  public updateOrderStatus(orderId: string, status: OrderStatus) {
    const order = this.orders.find((o) => o.id === orderId || o.order_number === orderId);
    if (order) {
      order.status = status;
      this.notify();

      const client = getSupabaseClient();
      if (client) {
        client.from('orders').update({ status }).eq('id', order.id).then();
      }
    }
  }

  // --- Table Reservations ---
  public async makeReservation(data: {
    name: string;
    phone: string;
    email?: string;
    date: string;
    time: string;
    guests: number;
    special_request?: string;
  }): Promise<{ success: boolean; bookingId: string }> {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const bookingId = `RES-${randomSuffix}`;

    const newRes: Reservation = {
      id: `res_${Date.now()}_${randomSuffix}`,
      booking_id: bookingId,
      name: data.name,
      phone: data.phone,
      email: data.email,
      date: data.date,
      time: data.time,
      guests: Number(data.guests),
      special_request: data.special_request,
      status: 'Confirmed',
      created_at: new Date().toISOString()
    };

    this.reservations.unshift(newRes);
    this.notify();

    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('reservations').insert([newRes]);
      } catch (e) {
        console.warn('Supabase reservation insert skipped', e);
      }
    }

    return { success: true, bookingId };
  }

  public updateReservationStatus(reservationId: string, status: 'Confirmed' | 'Pending' | 'Cancelled') {
    const reservation = this.reservations.find((r) => r.id === reservationId);
    if (reservation) {
      reservation.status = status;
      this.notify();

      const client = getSupabaseClient();
      if (client) {
        client.from('reservations').update({ status }).eq('id', reservation.id).then();
      }
    }
  }

  // --- Contact Messages ---
  public async submitMessage(data: {
    name: string;
    email: string;
    phone: string;
    subject: string;
    message: string;
  }): Promise<{ success: boolean }> {
    const newMsg: ContactMessage = {
      id: `msg_${Date.now()}`,
      name: data.name,
      email: data.email,
      phone: data.phone,
      subject: data.subject,
      message: data.message,
      created_at: new Date().toISOString(),
      read: false
    };

    this.messages.unshift(newMsg);
    this.notify();

    const client = getSupabaseClient();
    if (client) {
      try {
        await client.from('contact_messages').insert([newMsg]);
      } catch (e) {
        console.warn('Supabase message insert error', e);
      }
    }

    return { success: true };
  }

  public markMessageAsRead(id: string) {
    const msg = this.messages.find((m) => m.id === id);
    if (msg) {
      msg.read = true;
      this.notify();
    }
  }

  // --- Newsletter ---
  public subscribeNewsletter(email: string): { success: boolean; message: string } {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, message: 'Please enter a valid email address.' };
    }

    if (this.newsletterSubscribers.includes(cleanEmail)) {
      return { success: true, message: 'You are already subscribed to Royal Taste updates!' };
    }

    this.newsletterSubscribers.push(cleanEmail);
    this.notify();

    const client = getSupabaseClient();
    if (client) {
      client.from('newsletter_subscribers').insert([{ email: cleanEmail }]).then();
    }

    return { success: true, message: 'Thank you for subscribing to our Royal Gazette!' };
  }

  // --- Admin CRUD Operations ---
  public addMenuItem(item: Omit<MenuItem, 'id'>) {
    const id = `item-${Date.now()}`;
    const newItem: MenuItem = { ...item, id };
    this.menuItems.unshift(newItem);
    this.notify();

    const client = getSupabaseClient();
    if (client) {
      client.from('menu_items').insert([newItem]).then();
    }
    return newItem;
  }

  public updateMenuItem(id: string, updates: Partial<MenuItem>) {
    const index = this.menuItems.findIndex((item) => item.id === id);
    if (index > -1) {
      this.menuItems[index] = { ...this.menuItems[index], ...updates };
      this.notify();

      const client = getSupabaseClient();
      if (client) {
        client.from('menu_items').update(updates).eq('id', id).then();
      }
    }
  }

  public deleteMenuItem(id: string) {
    this.menuItems = this.menuItems.filter((item) => item.id !== id);
    this.notify();

    const client = getSupabaseClient();
    if (client) {
      client.from('menu_items').delete().eq('id', id).then();
    }
  }

  public updateWeeklySpecial(id: string, updates: Partial<WeeklySpecial>) {
    const index = this.weeklySpecials.findIndex((w) => w.id === id);
    if (index > -1) {
      this.weeklySpecials[index] = { ...this.weeklySpecials[index], ...updates };
      this.notify();
    }
  }

  public addDeal(deal: Omit<Deal, 'id'>) {
    const id = `deal-${Date.now()}`;
    const newDeal: Deal = { ...deal, id };
    this.deals.push(newDeal);
    this.notify();
  }

  public updateDeal(id: string, updates: Partial<Deal>) {
    const index = this.deals.findIndex((d) => d.id === id);
    if (index > -1) {
      this.deals[index] = { ...this.deals[index], ...updates };
      this.notify();
    }
  }

  public deleteDeal(id: string) {
    this.deals = this.deals.filter((d) => d.id !== id);
    this.notify();
  }

  public updateOffer(id: string, updates: Partial<Offer>) {
    const index = this.offers.findIndex((o) => o.id === id);
    if (index > -1) {
      this.offers[index] = { ...this.offers[index], ...updates };
      this.notify();
    }
  }

  public updateChef(id: string, updates: Partial<Chef>) {
    const index = this.chefs.findIndex((c) => c.id === id);
    if (index > -1) {
      this.chefs[index] = { ...this.chefs[index], ...updates };
      this.notify();
    }
  }

  public addGalleryItem(item: Omit<GalleryItem, 'id'>) {
    const newItem: GalleryItem = { ...item, id: `gal-${Date.now()}` };
    this.gallery.push(newItem);
    this.notify();
  }

  public deleteGalleryItem(id: string) {
    this.gallery = this.gallery.filter((g) => g.id !== id);
    this.notify();
  }

  public updateSiteSettings(settings: Partial<SiteSettings>) {
    this.siteSettings = { ...this.siteSettings, ...settings };
    this.notify();

    const client = getSupabaseClient();
    if (client) {
      client.from('site_settings').update(this.siteSettings).eq('id', 1).then();
    }
  }

  // --- Real Admin Authentication ---
  // No demo or hardcoded credentials anywhere.
  // Works with real Supabase Auth when credentials are provided,
  // or initiates an explicit admin user setup in secure browser storage on first setup.
  public async adminLogin(email: string, password: string): Promise<{ success: boolean; message: string }> {
    this.lastActivityTimestamp = Date.now();
    const cleanEmail = email.trim().toLowerCase();

    // 1. If Supabase is configured, use real Supabase Auth
    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client.auth.signInWithPassword({
          email: cleanEmail,
          password
        });

        if (error || !data.user) {
          return { success: false, message: error?.message || 'Invalid email or password.' };
        }

        // Verify admin role in profiles
        const { data: profile } = await client
          .from('profiles')
          .select('role, full_name')
          .eq('id', data.user.id)
          .single();

        if (!profile || profile.role !== 'admin') {
          await client.auth.signOut();
          return { success: false, message: 'Access Denied: Only users with the admin role can enter.' };
        }

        this.currentAdmin = {
          id: data.user.id,
          email: data.user.email || cleanEmail,
          role: 'admin',
          name: profile.full_name || 'Admin Manager',
          created_at: data.user.created_at
        };
        this.notify();
        return { success: true, message: 'Welcome back, Administrator.' };
      } catch (err: any) {
        return { success: false, message: err.message || 'Authentication error.' };
      }
    }

    // 2. Standalone / Initial Admin Mode
    // Check if an admin credential has been configured
    const storedAdminCreds = localStorage.getItem('rt_admin_credentials');
    if (!storedAdminCreds) {
      // First-time setup required: prompt user to register their admin credentials
      return {
        success: false,
        message: 'INITIAL_SETUP_REQUIRED'
      };
    }

    try {
      const { email: savedEmail, hash: savedHash, name: savedName } = JSON.parse(storedAdminCreds);
      if (cleanEmail === savedEmail && btoa(password) === savedHash) {
        this.currentAdmin = {
          id: 'admin_local_primary',
          email: savedEmail,
          role: 'admin',
          name: savedName || 'Executive Admin',
          created_at: new Date().toISOString()
        };
        this.notify();
        return { success: true, message: 'Login successful.' };
      } else {
        return { success: false, message: 'Invalid admin email or password.' };
      }
    } catch (e) {
      return { success: false, message: 'Authentication processing error.' };
    }
  }

  public async registerInitialAdmin(email: string, password: string, name: string): Promise<{ success: boolean; message: string }> {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || password.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters long.' };
    }

    const client = getSupabaseClient();
    if (client) {
      try {
        const { data, error } = await client.auth.signUp({
          email: cleanEmail,
          password,
          options: {
            data: { full_name: name }
          }
        });

        if (error || !data.user) {
          return { success: false, message: error?.message || 'Could not register user.' };
        }

        // Set role to admin in profiles table
        await client.from('profiles').upsert([
          {
            id: data.user.id,
            email: cleanEmail,
            full_name: name,
            role: 'admin'
          }
        ]);

        this.currentAdmin = {
          id: data.user.id,
          email: cleanEmail,
          role: 'admin',
          name,
          created_at: new Date().toISOString()
        };
        this.notify();
        return { success: true, message: 'Admin account created successfully on Supabase Auth.' };
      } catch (err: any) {
        return { success: false, message: err.message || 'Registration failed.' };
      }
    }

    // Local standalone initialization
    localStorage.setItem(
      'rt_admin_credentials',
      JSON.stringify({
        email: cleanEmail,
        hash: btoa(password),
        name: name || 'General Manager'
      })
    );

    this.currentAdmin = {
      id: 'admin_local_primary',
      email: cleanEmail,
      role: 'admin',
      name: name || 'General Manager',
      created_at: new Date().toISOString()
    };
    this.notify();
    return { success: true, message: 'Administrator initialized successfully.' };
  }

  public async changeAdminPassword(oldPass: string, newPass: string): Promise<{ success: boolean; message: string }> {
    if (!this.currentAdmin) {
      return { success: false, message: 'Not authenticated.' };
    }
    if (newPass.length < 6) {
      return { success: false, message: 'New password must be at least 6 characters.' };
    }

    const client = getSupabaseClient();
    if (client) {
      try {
        const { error } = await client.auth.updateUser({ password: newPass });
        if (error) return { success: false, message: error.message };
        return { success: true, message: 'Password updated successfully.' };
      } catch (err: any) {
        return { success: false, message: err.message };
      }
    }

    const storedAdminCreds = localStorage.getItem('rt_admin_credentials');
    if (storedAdminCreds) {
      const parsed = JSON.parse(storedAdminCreds);
      if (btoa(oldPass) !== parsed.hash) {
        return { success: false, message: 'Current password does not match.' };
      }
      parsed.hash = btoa(newPass);
      localStorage.setItem('rt_admin_credentials', JSON.stringify(parsed));
      return { success: true, message: 'Password updated successfully.' };
    }

    return { success: false, message: 'Error updating password.' };
  }

  public async sendPasswordResetEmail(email: string): Promise<{ success: boolean; message: string }> {
    const cleanEmail = email.trim().toLowerCase();
    const client = getSupabaseClient();
    if (client) {
      try {
        const { error } = await client.auth.resetPasswordForEmail(cleanEmail, {
          redirectTo: window.location.origin + '/admin'
        });
        if (error) return { success: false, message: error.message };
        return { success: true, message: `Password reset email dispatched to ${cleanEmail}.` };
      } catch (err: any) {
        return { success: false, message: err.message };
      }
    }

    // In local standalone mode, verify email
    const stored = localStorage.getItem('rt_admin_credentials');
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.email === cleanEmail) {
        return {
          success: true,
          message: `In standalone mode: A password reset token was simulated for ${cleanEmail}. Please use your registered email to reset.`
        };
      }
    }

    return { success: false, message: 'No registered admin found with that email address.' };
  }

  public async logoutAdmin() {
    const client = getSupabaseClient();
    if (client) {
      try {
        await client.auth.signOut();
      } catch (e) {
        // ignore
      }
    }
    this.currentAdmin = null;
    this.notify();
  }
}

export const royalStore = new RoyalTasteStore();
