import React, { useState, useEffect } from 'react';
import { useRoyalStore } from './hooks/useRoyalStore';
import { TopBar } from './components/layout/TopBar';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { FloatingWhatsApp } from './components/layout/FloatingWhatsApp';
import { BackToTop } from './components/layout/BackToTop';

import { Hero } from './components/home/Hero';
import { CategoryCircles } from './components/home/CategoryCircles';
import { ChefRecommendations } from './components/home/ChefRecommendations';
import { OfferBanner } from './components/home/OfferBanner';
import { WeeklySpecialsSection } from './components/home/WeeklySpecialsSection';
import { DealsSection } from './components/home/DealsSection';
import { FeaturesStrip } from './components/home/FeaturesStrip';
import { AboutSection } from './components/home/AboutSection';
import { MeetChefsSection } from './components/home/MeetChefsSection';
import { PhotoGallerySection } from './components/home/PhotoGallerySection';
import { ReservationSection } from './components/home/ReservationSection';
import { TestimonialsSlider } from './components/home/TestimonialsSlider';
import { NewsletterSection } from './components/home/NewsletterSection';
import { ContactSection } from './components/home/ContactSection';

import { FullMenuPage } from './components/menu/FullMenuPage';
import { DishDetailModal } from './components/menu/DishDetailModal';
import { CartDrawer } from './components/cart/CartDrawer';
import { CheckoutModal } from './components/cart/CheckoutModal';
import { OrderTrackingPage } from './components/order/OrderTrackingPage';
import { SearchModal } from './components/common/SearchModal';

import { AdminLayout } from './components/admin/AdminLayout';
import { AdminLogin } from './components/admin/AdminLogin';
import { MenuItem, Deal, WeeklySpecial, Order } from './types';

export default function App() {
  const { currentAdmin, store } = useRoyalStore();

  // Navigation View State
  const [currentView, setCurrentView] = useState<'home' | 'menu' | 'tracking' | 'admin'>('home');
  const [selectedMenuCategory, setSelectedMenuCategory] = useState<string>('all');
  const [trackingOrderCode, setTrackingOrderCode] = useState<string | null>(null);

  // Modals
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedDishDetail, setSelectedDishDetail] = useState<MenuItem | null>(null);
  const [orderCelebration, setOrderCelebration] = useState<Order | null>(null);

  // Route parser for initial URL hash (e.g. /#admin or direct links)
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash === 'admin') setCurrentView('admin');
      else if (hash === 'menu') setCurrentView('menu');
      else if (hash === 'tracking') setCurrentView('tracking');
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleNavigate = (view: 'home' | 'menu' | 'tracking' | 'admin', sectionId?: string) => {
    setCurrentView(view);
    if (view === 'home' && sectionId) {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 80);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSelectCategoryFromHome = (categoryId: string) => {
    setSelectedMenuCategory(categoryId);
    setCurrentView('menu');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderSpecial = (special: WeeklySpecial) => {
    // Look up or construct dish
    const matchingDish = store.getMenuItems().find((i) => i.name.toLowerCase().includes(special.dish_name.toLowerCase())) || {
      id: `special-${special.id}`,
      category_id: 'pakistani-desi',
      name: special.dish_name,
      description: special.description,
      price: special.special_price,
      image_url: special.image_url,
      veg_nonveg: 'non-veg' as const,
      rating: 5.0,
      is_available: true,
      badge: special.badge
    };
    store.addToCart(matchingDish);
    setCartOpen(true);
  };

  const handleAddDealToCart = (deal: Deal) => {
    const dealAsItem: MenuItem = {
      id: `deal-${deal.id}`,
      category_id: 'pakistani-desi',
      name: deal.title,
      description: `${deal.subtitle} • Includes: ${deal.items.join(', ')}`,
      price: deal.price,
      image_url: deal.image_url,
      veg_nonveg: 'non-veg',
      rating: 5.0,
      is_available: true,
      badge: deal.badge
    };
    store.addToCart(dealAsItem);
    setCartOpen(true);
  };

  const handleOrderSuccess = (order: Order) => {
    setCheckoutOpen(false);
    setCartOpen(false);
    setOrderCelebration(order);
    setTrackingOrderCode(order.order_number);
    setCurrentView('tracking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // If in Admin view
  if (currentView === 'admin') {
    if (!currentAdmin) {
      return (
        <AdminLogin
          onSuccess={() => {
            // Re-render occurs automatically via store subscription
          }}
          onBackToSite={() => handleNavigate('home')}
        />
      );
    }
    return <AdminLayout onBackToSite={() => handleNavigate('home')} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF5EC] text-neutral-900 font-sans selection:bg-[#B8782A] selection:text-white">
      {/* 1. Top Bar */}
      <TopBar />

      {/* 2. Sticky Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenCart={() => setCartOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            {/* 3. Hero Section */}
            <Hero
              onExploreMenu={() => handleNavigate('menu')}
              onBookTable={() => handleNavigate('home', 'reservation')}
            />

            {/* 4. Menu Categories (round images) */}
            <CategoryCircles onSelectCategory={handleSelectCategoryFromHome} />

            {/* 5. Chef's Recommendations */}
            <ChefRecommendations
              onSelectDish={(dish) => setSelectedDishDetail(dish)}
            />

            {/* 6. Offer Banner (20% Off) */}
            <OfferBanner onOrderNow={() => handleNavigate('menu')} />

            {/* 7. This Week's Specials (Mon-Sun tabs, today auto-highlighted) */}
            <WeeklySpecialsSection onOrderSpecial={handleOrderSpecial} />

            {/* 8. Deals Section (Family, Student, Lunch) */}
            <DealsSection onAddDealToCart={handleAddDealToCart} />

            {/* 9. Features Strip */}
            <FeaturesStrip />

            {/* 10. About Us with stats */}
            <AboutSection onExploreMenu={() => handleNavigate('menu')} />

            {/* 11. Meet Our Chefs */}
            <MeetChefsSection />

            {/* 12. Photo Gallery (8 images, lightbox) */}
            <PhotoGallerySection />

            {/* 13. Reservation Form */}
            <ReservationSection />

            {/* 14. Testimonials Slider */}
            <TestimonialsSlider />

            {/* 15. Newsletter Signup */}
            <NewsletterSection />

            {/* 16. Contact & Live Embedded Map */}
            <ContactSection />
          </>
        )}

        {currentView === 'menu' && (
          <FullMenuPage
            initialCategoryId={selectedMenuCategory}
            onOpenCart={() => setCartOpen(true)}
          />
        )}

        {currentView === 'tracking' && (
          <OrderTrackingPage
            initialOrderCode={trackingOrderCode}
            onExploreMenu={() => handleNavigate('menu')}
          />
        )}
      </main>

      {/* 17. Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* 18. Floating WhatsApp Button & Back to Top */}
      <FloatingWhatsApp />
      <BackToTop />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        onProceedToCheckout={() => {
          setCartOpen(false);
          setCheckoutOpen(true);
        }}
        onExploreMenu={() => {
          setCartOpen(false);
          handleNavigate('menu');
        }}
      />

      {/* Checkout Modal with Geolocation */}
      {checkoutOpen && (
        <CheckoutModal
          onClose={() => setCheckoutOpen(false)}
          onOrderSuccess={handleOrderSuccess}
        />
      )}

      {/* Dish Detail Modal */}
      {selectedDishDetail && (
        <DishDetailModal
          dish={selectedDishDetail}
          onClose={() => setSelectedDishDetail(null)}
          onAddToCart={(dish, variant, qty) => {
            store.addToCart(dish, variant, qty);
          }}
        />
      )}

      {/* Instant Search Across All 100 Dishes */}
      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectDish={(dish) => setSelectedDishDetail(dish)}
      />

      {/* Order Placement Toast / Banner Notification */}
      {orderCelebration && (
        <div className="fixed top-20 right-4 sm:right-8 z-50 bg-[#1c160f] text-white p-5 rounded-2xl shadow-2xl border border-amber-500/40 max-w-sm animate-bounce">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block">
                Royal Order Placed!
              </span>
              <p className="font-serif font-bold text-base mt-0.5">
                Order #{orderCelebration.order_number}
              </p>
              <p className="text-xs text-neutral-300 mt-1">
                Your order is in the royal kitchen. Live tracking enabled.
              </p>
            </div>
            <button
              onClick={() => setOrderCelebration(null)}
              className="text-neutral-400 hover:text-white text-xs"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
