export type VegNonVeg = 'veg' | 'non-veg';

export interface SizeVariant {
  name: string; // e.g., 'Half', 'Full', 'Small', 'Medium', 'Large', 'Leg', 'Chest'
  price: number; // in Pakistani Rupees (Rs)
}

export interface MenuItem {
  id: string;
  category_id: string;
  name: string;
  description: string;
  price: number; // base price or starting price in Rs
  size_variants?: SizeVariant[];
  image_url: string;
  badge?: string; // 'Chef's Special', 'Bestseller', 'Popular', 'Spicy', etc.
  veg_nonveg: VegNonVeg;
  rating: number; // 4.0 - 5.0
  is_available: boolean;
  discount_percent?: number; // optional active discount
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image_url: string;
  description?: string;
  display_order: number;
}

export interface WeeklySpecial {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  title: string;
  dish_name: string;
  description: string;
  original_price: number;
  special_price: number;
  image_url: string;
  badge?: string;
}

export interface Deal {
  id: string;
  title: string;
  subtitle: string;
  price: number;
  original_value?: number;
  description: string;
  items: string[];
  serves: string;
  image_url: string;
  badge?: string;
  is_active: boolean;
}

export interface Offer {
  id: string;
  title: string;
  code?: string;
  discount_type: 'percent' | 'fixed';
  discount_value: number; // e.g. 20 for 20%
  applies_to: 'whole_order' | 'category' | 'item';
  target_id?: string; // category id or item id
  description: string;
  start_date?: string;
  end_date?: string;
  is_active: boolean;
}

export interface Chef {
  id: string;
  name: string;
  role: string;
  experience: string;
  bio: string;
  image_url: string;
  specialty: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image_url: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  rating: number;
  comment: string;
  date: string;
  avatar_url?: string;
}

export interface CartItem {
  item: MenuItem;
  selectedVariant?: SizeVariant;
  quantity: number;
  unitPrice: number;
  notes?: string;
}

export type OrderStatus = 'Pending' | 'Preparing' | 'On the way' | 'Delivered' | 'Cancelled';

export interface OrderCustomer {
  name: string;
  phone: string;
  address: string;
  notes?: string;
  lat?: number;
  lng?: number;
  locationAccuracy?: number;
}

export interface Order {
  id: string;
  order_number: string;
  created_at: string;
  customer: OrderCustomer;
  items: {
    item_id: string;
    item_name: string;
    variant_name?: string;
    price: number;
    quantity: number;
    total: number;
  }[];
  subtotal: number;
  discount: number;
  delivery_fee: number;
  total_amount: number;
  status: OrderStatus;
  payment_method: 'Cash on Delivery';
  promo_code?: string;
  estimated_delivery_time?: string;
}

export interface Reservation {
  id: string;
  booking_id: string;
  name: string;
  phone: string;
  email?: string;
  date: string;
  time: string;
  guests: number;
  special_request?: string;
  status: 'Confirmed' | 'Pending' | 'Cancelled';
  created_at: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  created_at: string;
  read: boolean;
}

export interface SiteSettings {
  restaurant_name: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  manager_name: string;
  manager_number: string;
  email: string;
  address: string;
  hours: string;
  lat: number;
  lng: number;
  google_maps_embed_url: string;
  free_delivery_minimum: number;
  announcement_banner: string;
  social_facebook: string;
  social_instagram: string;
  social_youtube: string;
  social_tiktok: string;
}

export interface AdminUser {
  id: string;
  email: string;
  role: 'admin';
  name: string;
  created_at: string;
}
