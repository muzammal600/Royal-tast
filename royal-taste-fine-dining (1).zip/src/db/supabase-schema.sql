-- =========================================================================
-- ROYAL TASTE – Fine Dining: Complete Supabase PostgreSQL Schema & RLS
-- =========================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Profiles & Roles table (linked to auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'customer' CHECK (role IN ('admin', 'manager', 'customer')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Categories
CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  image_url TEXT,
  description TEXT,
  display_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Menu Items (100 Authentic Items)
CREATE TABLE IF NOT EXISTS public.menu_items (
  id TEXT PRIMARY KEY,
  category_id TEXT REFERENCES public.categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price NUMERIC NOT NULL,
  size_variants JSONB DEFAULT '[]'::jsonb,
  image_url TEXT NOT NULL,
  badge TEXT,
  veg_nonveg TEXT NOT NULL CHECK (veg_nonveg IN ('veg', 'non-veg')),
  rating NUMERIC DEFAULT 4.8,
  is_available BOOLEAN DEFAULT TRUE,
  discount_percent INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Weekly Menu (Monday to Sunday)
CREATE TABLE IF NOT EXISTS public.weekly_menu (
  id TEXT PRIMARY KEY,
  day TEXT NOT NULL UNIQUE CHECK (day IN ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')),
  title TEXT NOT NULL,
  dish_name TEXT NOT NULL,
  description TEXT NOT NULL,
  original_price NUMERIC NOT NULL,
  special_price NUMERIC NOT NULL,
  image_url TEXT NOT NULL,
  badge TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Offers & Promotions
CREATE TABLE IF NOT EXISTS public.offers (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  code TEXT,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percent', 'fixed')),
  discount_value NUMERIC NOT NULL,
  applies_to TEXT NOT NULL CHECK (applies_to IN ('whole_order', 'category', 'item')),
  target_id TEXT,
  description TEXT NOT NULL,
  start_date TIMESTAMPTZ,
  end_date TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Deals (Family, Student, Lunch)
CREATE TABLE IF NOT EXISTS public.deals (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL,
  price NUMERIC NOT NULL,
  original_value NUMERIC,
  description TEXT NOT NULL,
  items JSONB NOT NULL,
  serves TEXT NOT NULL,
  image_url TEXT NOT NULL,
  badge TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Orders (with Customer Geolocation coordinates)
CREATE TABLE IF NOT EXISTS public.orders (
  id TEXT PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_address TEXT NOT NULL,
  customer_notes TEXT,
  customer_lat NUMERIC,
  customer_lng NUMERIC,
  location_accuracy NUMERIC,
  items JSONB NOT NULL,
  subtotal NUMERIC NOT NULL,
  discount NUMERIC DEFAULT 0,
  delivery_fee NUMERIC DEFAULT 0,
  total_amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'Pending' CHECK (status IN ('Pending', 'Preparing', 'On the way', 'Delivered', 'Cancelled')),
  payment_method TEXT DEFAULT 'Cash on Delivery',
  promo_code TEXT,
  estimated_delivery_time TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Table Reservations
CREATE TABLE IF NOT EXISTS public.reservations (
  id TEXT PRIMARY KEY,
  booking_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  date DATE NOT NULL,
  time TEXT NOT NULL,
  guests INT NOT NULL CHECK (guests > 0),
  special_request TEXT,
  status TEXT DEFAULT 'Pending' CHECK (status IN ('Confirmed', 'Pending', 'Cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Chefs
CREATE TABLE IF NOT EXISTS public.chefs (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  experience TEXT NOT NULL,
  specialty TEXT NOT NULL,
  bio TEXT NOT NULL,
  image_url TEXT NOT NULL
);

-- 10. Photo Gallery
CREATE TABLE IF NOT EXISTS public.gallery (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  image_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Testimonials
CREATE TABLE IF NOT EXISTS public.testimonials (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  date TEXT NOT NULL,
  avatar_url TEXT
);

-- 12. Newsletter Subscribers
CREATE TABLE IF NOT EXISTS public.newsletter_subscribers (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. Contact Messages
CREATE TABLE IF NOT EXISTS public.contact_messages (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. Site Settings (Single Row Store)
CREATE TABLE IF NOT EXISTS public.site_settings (
  id INT PRIMARY KEY DEFAULT 1,
  restaurant_name TEXT NOT NULL,
  tagline TEXT,
  phone TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  manager_name TEXT NOT NULL,
  manager_number TEXT NOT NULL,
  email TEXT NOT NULL,
  address TEXT NOT NULL,
  hours TEXT NOT NULL,
  lat NUMERIC NOT NULL,
  lng NUMERIC NOT NULL,
  google_maps_embed_url TEXT,
  free_delivery_minimum NUMERIC DEFAULT 2000,
  announcement_banner TEXT,
  social_facebook TEXT,
  social_instagram TEXT,
  social_youtube TEXT,
  social_tiktok TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =========================================================================
-- Enable Row Level Security (RLS)
-- =========================================================================
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.weekly_menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chefs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Helper function: check if current user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Public READ policies for storefront
CREATE POLICY "Public Read Categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Public Read Menu Items" ON public.menu_items FOR SELECT USING (true);
CREATE POLICY "Public Read Weekly Menu" ON public.weekly_menu FOR SELECT USING (true);
CREATE POLICY "Public Read Offers" ON public.offers FOR SELECT USING (true);
CREATE POLICY "Public Read Deals" ON public.deals FOR SELECT USING (true);
CREATE POLICY "Public Read Chefs" ON public.chefs FOR SELECT USING (true);
CREATE POLICY "Public Read Gallery" ON public.gallery FOR SELECT USING (true);
CREATE POLICY "Public Read Testimonials" ON public.testimonials FOR SELECT USING (true);
CREATE POLICY "Public Read Settings" ON public.site_settings FOR SELECT USING (true);

-- Public INSERT policies for customers placing orders, reservations, messages & newsletter
CREATE POLICY "Public Insert Orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Read Specific Order" ON public.orders FOR SELECT USING (true);
CREATE POLICY "Public Insert Reservations" ON public.reservations FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Insert Messages" ON public.contact_messages FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Insert Newsletter" ON public.newsletter_subscribers FOR INSERT WITH CHECK (true);

-- Admin WRITE policies (Only users with role = 'admin' can insert/update/delete)
CREATE POLICY "Admin All Categories" ON public.categories FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Menu Items" ON public.menu_items FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Weekly Menu" ON public.weekly_menu FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Offers" ON public.offers FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Deals" ON public.deals FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Orders" ON public.orders FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Reservations" ON public.reservations FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Chefs" ON public.chefs FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Gallery" ON public.gallery FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Testimonials" ON public.testimonials FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Newsletter" ON public.newsletter_subscribers FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Messages" ON public.contact_messages FOR ALL USING (public.is_admin());
CREATE POLICY "Admin All Settings" ON public.site_settings FOR ALL USING (public.is_admin());

-- Enable Realtime for live order tracking and instant admin updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.reservations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.menu_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.site_settings;
