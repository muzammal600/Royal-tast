import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { MenuItem } from '../../types';
import { Search, X, Star, Plus, Check } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDish: (dish: MenuItem) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectDish
}) => {
  const { menuItems, store } = useRoyalStore();
  const [query, setQuery] = useState('');
  const [addedIds, setAddedIds] = useState<{ [id: string]: boolean }>({});

  if (!isOpen) return null;

  const results = query.trim()
    ? menuItems
        .filter(
          (i) =>
            i.name.toLowerCase().includes(query.toLowerCase()) ||
            i.description.toLowerCase().includes(query.toLowerCase()) ||
            i.category_id.toLowerCase().includes(query.toLowerCase())
        )
        .slice(0, 10)
    : menuItems.slice(0, 6);

  const handleQuickAdd = (e: React.MouseEvent, dish: MenuItem) => {
    e.stopPropagation();
    store.addToCart(dish);
    setAddedIds((prev) => ({ ...prev, [dish.id]: true }));
    setTimeout(() => {
      setAddedIds((prev) => ({ ...prev, [dish.id]: false }));
    }, 1500);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-start justify-center p-4 sm:p-6 pt-16 sm:pt-24 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-neutral-200 space-y-4"
      >
        <div className="flex items-center gap-3 border-b border-neutral-200 pb-3">
          <Search size={20} className="text-[#B8782A]" />
          <input
            type="text"
            autoFocus
            placeholder="Search all 100 dishes (e.g. Karahi, Biryani, Naan, Pizza)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-base text-neutral-900 focus:outline-none"
          />
          <button onClick={onClose} className="p-1 rounded-full hover:bg-neutral-100">
            <X size={18} />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto divide-y divide-neutral-100 space-y-1">
          {results.length === 0 ? (
            <p className="text-center py-8 text-xs text-neutral-400">
              No dishes found matching "{query}".
            </p>
          ) : (
            results.map((dish) => {
              const isAdded = addedIds[dish.id];
              return (
                <div
                  key={dish.id}
                  onClick={() => {
                    onSelectDish(dish);
                    onClose();
                  }}
                  className="py-3 px-2 flex items-center justify-between gap-4 hover:bg-neutral-50 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={dish.image_url}
                      alt={dish.name}
                      className="w-12 h-12 rounded-xl object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-serif font-bold text-sm text-neutral-900 truncate">
                          {dish.name}
                        </h4>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                            dish.veg_nonveg === 'veg'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {dish.veg_nonveg.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-500 truncate">{dish.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-serif font-bold text-sm text-neutral-900">
                      Rs {dish.price.toLocaleString()}
                    </span>
                    <button
                      onClick={(e) => handleQuickAdd(e, dish)}
                      className={`p-2 rounded-full transition-colors ${
                        isAdded
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[#B8782A] text-white hover:bg-[#9c631e]'
                      }`}
                      aria-label="Add to cart"
                    >
                      {isAdded ? <Check size={14} /> : <Plus size={14} />}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
