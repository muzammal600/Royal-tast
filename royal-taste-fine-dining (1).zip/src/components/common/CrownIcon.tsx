import React from 'react';

interface CrownIconProps {
  className?: string;
  size?: number;
  color?: string;
}

export const CrownIcon: React.FC<CrownIconProps> = ({
  className = '',
  size = 24,
  color = '#B8782A'
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path
        d="M2.5 19.5H21.5C21.7761 19.5 22 19.2761 22 19V18C22 17.7239 21.7761 17.5 21.5 17.5H2.5C2.22386 17.5 2 17.7239 2 18V19C2 19.2761 2.22386 19.5 2.5 19.5Z"
        fill={color}
      />
      <path
        d="M3.5 16.5L4.8 6.5L9.5 11L12 3.5L14.5 11L19.2 6.5L20.5 16.5H3.5Z"
        fill={color}
        fillOpacity="0.25"
      />
      <circle cx="4.8" cy="5.5" r="1.2" fill={color} />
      <circle cx="12" cy="2.5" r="1.4" fill={color} />
      <circle cx="19.2" cy="5.5" r="1.2" fill={color} />
      <circle cx="9.5" cy="10" r="0.8" fill={color} />
      <circle cx="14.5" cy="10" r="0.8" fill={color} />
    </svg>
  );
};
