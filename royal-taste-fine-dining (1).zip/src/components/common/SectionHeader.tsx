import React from 'react';
import { CrownIcon } from './CrownIcon';

interface SectionHeaderProps {
  subtitle?: string;
  title: string;
  description?: string;
  align?: 'center' | 'left' | 'right';
  light?: boolean;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  subtitle,
  title,
  description,
  align = 'center',
  light = false
}) => {
  const alignmentClass =
    align === 'center'
      ? 'text-center items-center'
      : align === 'right'
      ? 'text-right items-end'
      : 'text-left items-start';

  return (
    <div className={`flex flex-col ${alignmentClass} mb-12 sm:mb-16`}>
      {subtitle && (
        <div className="flex items-center gap-2 mb-2.5">
          <span className="h-px w-6 bg-[#B8782A]/50"></span>
          <span className="text-xs sm:text-sm font-semibold uppercase tracking-[0.25em] text-[#B8782A]">
            {subtitle}
          </span>
          <span className="h-px w-6 bg-[#B8782A]/50"></span>
        </div>
      )}

      <h2
        className={`font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight ${
          light ? 'text-white' : 'text-neutral-900'
        }`}
      >
        {title}
      </h2>

      {/* Royal Crown Section Divider */}
      <div className="flex items-center justify-center gap-3 my-4">
        <div className="h-[1.5px] w-12 sm:w-20 bg-gradient-to-r from-transparent to-[#B8782A]"></div>
        <CrownIcon size={18} color="#B8782A" />
        <div className="h-[1.5px] w-12 sm:w-20 bg-gradient-to-l from-transparent to-[#B8782A]"></div>
      </div>

      {description && (
        <p
          className={`max-w-2xl text-sm sm:text-base leading-relaxed ${
            light ? 'text-neutral-300' : 'text-neutral-600'
          }`}
        >
          {description}
        </p>
      )}
    </div>
  );
};
