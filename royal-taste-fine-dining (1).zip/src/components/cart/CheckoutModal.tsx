import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { X, MapPin, Phone, User, FileText, CheckCircle, Navigation, AlertCircle } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';
import { Order } from '../../types';

interface CheckoutModalProps {
  onClose: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  onClose,
  onOrderSuccess
}) => {
  const { cart, cartCalculations, store, appliedPromoCode } = useRoyalStore();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  // Geolocation state
  const [lat, setLat] = useState<number | undefined>(undefined);
  const [lng, setLng] = useState<number | undefined>(undefined);
  const [accuracy, setAccuracy] = useState<number | undefined>(undefined);
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [geoSuccess, setGeoSuccess] = useState(false);

  const [submitting, setSubmitting] = useState(false);

  // Browser Geolocation sharing
  const handleShareLocation = () => {
    if (!navigator.geolocation) {
      setGeoError('Geolocation is not supported by your browser.');
      return;
    }

    setGeoLoading(true);
    setGeoError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLat(position.coords.latitude);
        setLng(position.coords.longitude);
        setAccuracy(Math.round(position.coords.accuracy));
        setGeoLoading(false);
        setGeoSuccess(true);
      },
      (err) => {
        setGeoLoading(false);
        setGeoError(err.message || 'Unable to retrieve location.');
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !address.trim()) {
      setGeoError('Please fill in your name, phone number, and delivery address.');
      return;
    }

    setSubmitting(true);
    try {
      const result = await store.placeOrder({
        name: name.trim(),
        phone: phone.trim(),
        address: address.trim(),
        notes: notes.trim() || undefined,
        lat,
        lng,
        locationAccuracy: accuracy
      });

      if (result.success) {
        onOrderSuccess(result.order);
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl border border-amber-900/15 relative flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-[#FAF5EC] border-b border-amber-900/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <CrownIcon size={20} color="#B8782A" />
            <div>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-neutral-900">
                Royal Taste Checkout
              </h3>
              <p className="text-xs text-neutral-500">
                Cash on Delivery (COD) • Free delivery above Rs 2,000
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-neutral-200 text-neutral-600 transition-colors"
            aria-label="Close checkout"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handlePlaceOrder} className="p-6 overflow-y-auto space-y-5">
          {/* Order Summary Snapshot */}
          <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-200/80 space-y-1.5 text-xs text-neutral-600">
            <div className="flex justify-between">
              <span>Items in Order:</span>
              <span className="font-bold text-neutral-800">{cartCalculations.totalItemsCount} dishes</span>
            </div>
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-semibold text-neutral-800">Rs {cartCalculations.subtotal.toLocaleString()}</span>
            </div>
            {cartCalculations.discount > 0 && (
              <div className="flex justify-between text-emerald-600 font-semibold">
                <span>Discount ({appliedPromoCode || 'Promo'}):</span>
                <span>- Rs {cartCalculations.discount.toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Delivery Fee:</span>
              <span className="font-semibold text-neutral-800">
                {cartCalculations.isFreeDelivery ? 'FREE (Above Rs 2,000)' : 'Rs 200'}
              </span>
            </div>
            <div className="flex justify-between text-sm font-bold text-neutral-900 pt-1.5 border-t border-neutral-200">
              <span>Total Payable Amount:</span>
              <span className="font-serif text-lg text-[#B8782A]">
                Rs {cartCalculations.totalAmount.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Customer Name */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5">
              Full Name *
            </label>
            <div className="relative">
              <User size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
              <input
                type="text"
                required
                placeholder="e.g. Farooq Ahmad"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
              />
            </div>
          </div>

          {/* Customer Phone */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5">
              Phone / WhatsApp Number *
            </label>
            <div className="relative">
              <Phone size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
              <input
                type="tel"
                required
                placeholder="+92 300 1234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
              />
            </div>
            <p className="text-[11px] text-neutral-400 mt-1">Our delivery captain will call you upon arrival.</p>
          </div>

          {/* Delivery Address */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5">
              Complete Delivery Address *
            </label>
            <div className="relative">
              <MapPin size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
              <textarea
                rows={2}
                required
                placeholder="House / Flat No., Street, Block, Phase, Area, Lahore..."
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
              />
            </div>
          </div>

          {/* Browser Geolocation Button ("Share my location") */}
          <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/80">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-bold text-neutral-900 flex items-center gap-1.5">
                  <Navigation size={14} className="text-[#B8782A]" />
                  <span>Pinpoint Delivery GPS Location</span>
                </p>
                <p className="text-[11px] text-neutral-600 mt-0.5">
                  Ensures fast, exact delivery rider dispatch to your doorstep.
                </p>
              </div>

              <button
                type="button"
                onClick={handleShareLocation}
                disabled={geoLoading}
                className="px-3.5 py-2 rounded-xl bg-white border border-[#B8782A] text-[#B8782A] text-xs font-bold hover:bg-[#B8782A] hover:text-white transition-all shadow-sm shrink-0 flex items-center gap-1.5"
              >
                <Navigation size={13} />
                <span>{geoLoading ? 'Detecting...' : geoSuccess ? 'Location Saved' : 'Share My Location'}</span>
              </button>
            </div>

            {geoSuccess && lat && lng && (
              <div className="mt-2.5 text-xs text-emerald-800 bg-emerald-50 p-2 rounded-lg border border-emerald-200 flex items-center gap-2">
                <CheckCircle size={14} className="text-emerald-600 shrink-0" />
                <span>
                  GPS Coordinates pinned: {lat.toFixed(5)}, {lng.toFixed(5)} (±{accuracy}m)
                </span>
              </div>
            )}

            {geoError && (
              <div className="mt-2 text-xs text-rose-700 bg-rose-50 p-2 rounded-lg flex items-center gap-1.5">
                <AlertCircle size={14} />
                <span>{geoError} (You can still enter manual address)</span>
              </div>
            )}
          </div>

          {/* Order Notes */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5">
              Special Delivery Instructions (Optional)
            </label>
            <div className="relative">
              <FileText size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
              <input
                type="text"
                placeholder="e.g. Ring the bell, leave at reception, extra mint raita..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
              />
            </div>
          </div>

          {/* Payment Method Banner: Cash on Delivery */}
          <div className="p-3.5 bg-neutral-100 rounded-2xl flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-neutral-800 block">Payment Method</span>
              <span className="text-neutral-500">Pay cash to delivery rider when food arrives.</span>
            </div>
            <span className="bg-[#B8782A] text-white px-2.5 py-1 rounded-md font-bold uppercase tracking-wider text-[10px]">
              Cash on Delivery
            </span>
          </div>

          {/* Submit Action */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-4 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white font-bold uppercase tracking-wider text-sm transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <CrownIcon size={18} color="#FFFFFF" />
              <span>{submitting ? 'Placing Order...' : `Confirm & Place Order (Rs ${cartCalculations.totalAmount.toLocaleString()})`}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
