import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, Tag, Sparkles } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToCheckout: () => void;
  onExploreMenu: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  onProceedToCheckout,
  onExploreMenu
}) => {
  const { cart, cartCalculations, appliedPromoCode, store } = useRoyalStore();
  const [promoInput, setPromoInput] = useState('');
  const [promoFeedback, setPromoFeedback] = useState<{ message: string; success: boolean } | null>(null);

  if (!isOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    const res = store.applyPromoCode(promoInput);
    setPromoFeedback({ message: res.message, success: res.success });
    setTimeout(() => setPromoFeedback(null), 3500);
  };

  const amountNeededForFreeDelivery = Math.max(
    0,
    cartCalculations.freeDeliveryThreshold - cartCalculations.subtotal
  );
  const freeDeliveryPercent = Math.min(
    100,
    Math.round((cartCalculations.subtotal / cartCalculations.freeDeliveryThreshold) * 100)
  );

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
      ></div>

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-5 sm:p-6 bg-[#FAF5EC] border-b border-amber-900/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CrownIcon size={20} color="#B8782A" />
              <h2 className="font-serif text-xl font-bold text-neutral-900">
                Your Royal Cart
              </h2>
              <span className="text-xs bg-[#B8782A]/10 text-[#B8782A] font-bold px-2 py-0.5 rounded-full">
                {cartCalculations.totalItemsCount}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-neutral-200 text-neutral-500 hover:text-neutral-800 transition-colors"
              aria-label="Close cart"
            >
              <X size={20} />
            </button>
          </div>

          {/* Free Delivery Tracker */}
          <div className="bg-amber-50/80 px-6 py-3 border-b border-amber-200/60">
            <div className="flex items-center justify-between text-xs mb-1.5 font-medium text-neutral-700">
              <span className="flex items-center gap-1.5 text-amber-900">
                <Sparkles size={13} className="text-[#B8782A]" />
                {cartCalculations.isFreeDelivery ? (
                  <strong className="text-emerald-700">Congratulations! You unlocked Free Delivery.</strong>
                ) : (
                  <span>
                    Add <strong>Rs {amountNeededForFreeDelivery.toLocaleString()}</strong> more for Free Delivery
                  </span>
                )}
              </span>
              <span className="text-[11px] font-bold text-[#B8782A]">{freeDeliveryPercent}%</span>
            </div>
            <div className="w-full bg-amber-200/50 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  cartCalculations.isFreeDelivery ? 'bg-emerald-600' : 'bg-[#B8782A]'
                }`}
                style={{ width: `${freeDeliveryPercent}%` }}
              ></div>
            </div>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="h-16 w-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto text-neutral-400">
                  <ShoppingBag size={28} />
                </div>
                <h3 className="font-serif text-lg font-bold text-neutral-900">
                  Your cart is empty
                </h3>
                <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                  Explore our authentic 100-dish Pakistani menu and treat yourself to a royal dining feast.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => {
                      onClose();
                      onExploreMenu();
                    }}
                    className="px-6 py-2.5 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e] transition-colors"
                  >
                    Explore Menu (100 Dishes)
                  </button>
                </div>
              </div>
            ) : (
              cart.map((cartItem, idx) => {
                const itemTotal = cartItem.unitPrice * cartItem.quantity;
                return (
                  <div
                    key={`${cartItem.item.id}-${cartItem.selectedVariant?.name || 'base'}-${idx}`}
                    className="flex items-center gap-3.5 p-3 rounded-2xl bg-neutral-50 border border-neutral-200/60"
                  >
                    <img
                      src={cartItem.item.image_url}
                      alt={cartItem.item.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-serif text-sm font-bold text-neutral-900 truncate">
                        {cartItem.item.name}
                      </h4>
                      {cartItem.selectedVariant && (
                        <span className="text-[11px] text-[#B8782A] font-semibold block">
                          Size: {cartItem.selectedVariant.name}
                        </span>
                      )}
                      <span className="text-xs font-semibold text-neutral-600 block mt-0.5">
                        Rs {cartItem.unitPrice.toLocaleString()} each
                      </span>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => store.updateCartQuantity(idx, cartItem.quantity - 1)}
                          className="p-1 rounded-md bg-white border border-neutral-200 hover:bg-neutral-100 transition-colors"
                          aria-label="Decrease quantity"
                        >
                          <Minus size={13} />
                        </button>
                        <span className="text-xs font-bold text-neutral-900 min-w-[16px] text-center">
                          {cartItem.quantity}
                        </span>
                        <button
                          onClick={() => store.updateCartQuantity(idx, cartItem.quantity + 1)}
                          className="p-1 rounded-md bg-white border border-neutral-200 hover:bg-neutral-100 transition-colors"
                          aria-label="Increase quantity"
                        >
                          <Plus size={13} />
                        </button>

                        <button
                          onClick={() => store.removeFromCart(idx)}
                          className="ml-auto text-neutral-400 hover:text-rose-600 p-1 transition-colors"
                          aria-label="Remove item"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-serif font-bold text-sm text-neutral-900">
                        Rs {itemTotal.toLocaleString()}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Calculations & Actions */}
          {cart.length > 0 && (
            <div className="p-6 bg-neutral-50 border-t border-neutral-200 space-y-4">
              {/* Promo Code Form */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag size={15} className="absolute left-3 top-3 text-neutral-400" />
                  <input
                    type="text"
                    placeholder="Enter Coupon (e.g. FIRST20)"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs uppercase tracking-wider font-semibold focus:outline-none focus:border-[#B8782A]"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-neutral-900 text-white text-xs font-bold uppercase tracking-wider hover:bg-neutral-800 transition-colors"
                >
                  Apply
                </button>
              </form>

              {promoFeedback && (
                <p
                  className={`text-xs font-medium ${
                    promoFeedback.success ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {promoFeedback.message}
                </p>
              )}

              {/* Price Breakdown */}
              <div className="space-y-2 text-xs text-neutral-600 pt-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-neutral-900">
                    Rs {cartCalculations.subtotal.toLocaleString()}
                  </span>
                </div>

                {cartCalculations.discount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Discount Applied ({appliedPromoCode}):</span>
                    <span>- Rs {cartCalculations.discount.toLocaleString()}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Delivery Charges:</span>
                  <span className="font-semibold text-neutral-900">
                    {cartCalculations.isFreeDelivery ? 'FREE' : 'Rs 200'}
                  </span>
                </div>

                <div className="flex justify-between text-base font-bold text-neutral-900 pt-2 border-t border-neutral-200">
                  <span>Grand Total:</span>
                  <span className="font-serif text-xl text-[#B8782A]">
                    Rs {cartCalculations.totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Proceed to Checkout CTA */}
              <button
                onClick={onProceedToCheckout}
                className="w-full py-4 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white font-bold uppercase tracking-wider text-xs sm:text-sm transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 group"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
