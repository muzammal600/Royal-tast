import React, { useState, useMemo } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { MenuItem, VegNonVeg } from '../../types';
import { Search, Filter, Star, Plus, Check, ShoppingBag, X } from 'lucide-react';
import { DishDetailModal } from './DishDetailModal';
import { CrownIcon } from '../common/CrownIcon';

interface FullMenuPageProps {
  initialCategoryId?: string;
  onOpenCart: () => void;
}

export const FullMenuPage: React.FC<FullMenuPageProps> = ({
  initialCategoryId = 'all',
  onOpenCart
}) => {
  const { categories, menuItems, store } = useRoyalStore();
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategoryId);
  const [searchQuery, setSearchQuery] = useState('');
  const [vegFilter, setVegFilter] = useState<'all' | 'veg' | 'non-veg'>('all');
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);
  const [quickAddedId, setQuickAddedId] = useState<string | null>(null);

  // Filtered menu items
  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all' && item.category_id !== selectedCategory) {
        return false;
      }
      // Veg/Non-veg filter
      if (vegFilter !== 'all' && item.veg_nonveg !== vegFilter) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        const matchesBadge = item.badge?.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesBadge) {
          return false;
        }
      }
      return true;
    });
  }, [menuItems, selectedCategory, vegFilter, searchQuery]);

  const handleQuickAdd = (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    // If it has multiple variants, open detail modal so user picks size
    if (item.size_variants && item.size_variants.length > 0) {
      setSelectedDish(item);
      return;
    }
    store.addToCart(item);
    setQuickAddedId(item.id);
    setTimeout(() => setQuickAddedId(null), 1400);
  };

  const currentCategoryObj = categories.find((c) => c.id === selectedCategory);

  return (
    <div className="bg-[#FAF5EC] min-h-screen py-10 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#B8782A]/10 border border-[#B8782A]/30 text-xs font-semibold text-[#B8782A] mb-3">
            <CrownIcon size={16} color="#B8782A" />
            <span>Complete 100-Dish Authentic Menu</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl font-black text-neutral-900 tracking-tight">
            The Royal Pakistani Feast
          </h1>

          <p className="text-sm sm:text-base text-neutral-600 mt-3 leading-relaxed">
            Every dish prepared to order using pure dairy butter, fresh halal meats, and aged basmati.
            Select your favorites or choose customized portion sizes.
          </p>
        </div>

        {/* Search Bar & Veg/Non-Veg Filters */}
        <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-md border border-neutral-200/80 mb-8 space-y-4">
          <div className="flex flex-col md:flex-row items-center gap-4">
            {/* Search Input */}
            <div className="relative w-full flex-1">
              <Search size={18} className="absolute left-4 top-3.5 text-neutral-400" />
              <input
                type="text"
                placeholder="Search across all 100 dishes (e.g. Karahi, Nihari, Tikka, Pizza, Shake)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-10 py-3 bg-[#FAF5EC]/50 border border-neutral-200 rounded-2xl text-sm focus:outline-none focus:border-[#B8782A] focus:bg-white"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-3.5 text-neutral-400 hover:text-neutral-600"
                >
                  <X size={16} />
                </button>
              )}
            </div>

            {/* Diet Filter Buttons */}
            <div className="flex items-center gap-2 w-full md:w-auto shrink-0 justify-center">
              <button
                onClick={() => setVegFilter('all')}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  vegFilter === 'all'
                    ? 'bg-neutral-900 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                All Diet
              </button>
              <button
                onClick={() => setVegFilter('veg')}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  vegFilter === 'veg'
                    ? 'bg-emerald-700 text-white shadow-sm'
                    : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                <span>Vegetarian</span>
              </button>
              <button
                onClick={() => setVegFilter('non-veg')}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  vegFilter === 'non-veg'
                    ? 'bg-rose-700 text-white shadow-sm'
                    : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-rose-500"></span>
                <span>Non-Veg</span>
              </button>
            </div>
          </div>

          {/* Category Tabs Scroll Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none pt-2 border-t border-neutral-100">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider shrink-0 transition-all ${
                selectedCategory === 'all'
                  ? 'bg-[#B8782A] text-white shadow'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              All 100 Dishes ({menuItems.length})
            </button>

            {categories.map((cat) => {
              const catCount = menuItems.filter((i) => i.category_id === cat.id).length;
              const isSelected = selectedCategory === cat.id;

              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold shrink-0 transition-all ${
                    isSelected
                      ? 'bg-[#B8782A] text-white shadow'
                      : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                  }`}
                >
                  {cat.name} ({catCount})
                </button>
              );
            })}
          </div>
        </div>

        {/* Current Active Category Description */}
        {currentCategoryObj && selectedCategory !== 'all' && (
          <div className="mb-8 p-4 sm:p-5 rounded-2xl bg-white border border-amber-900/10 flex items-center justify-between">
            <div>
              <h2 className="font-serif text-xl font-bold text-neutral-900">
                {currentCategoryObj.name}
              </h2>
              <p className="text-xs sm:text-sm text-neutral-600 mt-0.5">
                {currentCategoryObj.description}
              </p>
            </div>
            <span className="text-xs text-[#B8782A] font-bold bg-[#B8782A]/10 px-3 py-1 rounded-full shrink-0">
              {filteredItems.length} Dishes
            </span>
          </div>
        )}

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center max-w-md mx-auto shadow-sm">
            <p className="font-serif text-xl font-bold text-neutral-900">No dishes found</p>
            <p className="text-xs sm:text-sm text-neutral-500 mt-2">
              Try adjusting your search keywords or dietary filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setVegFilter('all');
                setSelectedCategory('all');
              }}
              className="mt-4 px-5 py-2 rounded-full bg-[#B8782A] text-white text-xs font-semibold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) => {
              const isAdded = quickAddedId === item.id;
              const hasVariants = item.size_variants && item.size_variants.length > 0;
              const basePrice = item.price;
              const hasDiscount = item.discount_percent && item.discount_percent > 0;
              const finalPrice = hasDiscount
                ? Math.round(basePrice * (1 - item.discount_percent! / 100))
                : basePrice;

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedDish(item)}
                  className="group bg-white rounded-2xl overflow-hidden border border-neutral-200/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer hover:-translate-y-1.5"
                >
                  <div>
                    {/* Item Image */}
                    <div className="relative h-48 w-full overflow-hidden bg-neutral-100">
                      <img
                        src={item.image_url}
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        loading="lazy"
                      />

                      {/* Offer Discount Badge or General Badge */}
                      {hasDiscount ? (
                        <span className="absolute top-3 left-3 bg-rose-600 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow">
                          -{item.discount_percent}% OFF
                        </span>
                      ) : item.badge ? (
                        <span className="absolute top-3 left-3 bg-[#B8782A] text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow">
                          {item.badge}
                        </span>
                      ) : null}

                      {/* Veg / Non-Veg Indicator */}
                      <span
                        className={`absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded border bg-white/95 shadow-sm flex items-center gap-1 ${
                          item.veg_nonveg === 'veg'
                            ? 'border-emerald-600 text-emerald-700'
                            : 'border-rose-600 text-rose-700'
                        }`}
                      >
                        <span
                          className={`h-1.5 w-1.5 rounded-full ${
                            item.veg_nonveg === 'veg' ? 'bg-emerald-600' : 'bg-rose-600'
                          }`}
                        ></span>
                        {item.veg_nonveg === 'veg' ? 'VEG' : 'NON-VEG'}
                      </span>
                    </div>

                    {/* Content */}
                    <div className="p-4 sm:p-5">
                      <div className="flex items-center justify-between text-xs text-neutral-500 mb-1">
                        <div className="flex items-center gap-1 text-[#B8782A] font-semibold">
                          <Star size={13} className="fill-current text-[#B8782A]" />
                          <span>{item.rating.toFixed(1)}</span>
                        </div>
                        {hasVariants && (
                          <span className="text-[11px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded font-medium">
                            {item.size_variants?.length} Options
                          </span>
                        )}
                      </div>

                      <h3 className="font-serif text-lg font-bold text-neutral-900 group-hover:text-[#B8782A] transition-colors leading-snug line-clamp-1">
                        {item.name}
                      </h3>

                      <p className="text-xs text-neutral-600 mt-1 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  {/* Card Footer with Price and Add Button */}
                  <div className="p-4 sm:p-5 pt-0 border-t border-neutral-100 mt-2 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-neutral-400 uppercase tracking-wider block font-medium">
                        {hasVariants ? 'Portions from' : 'Price'}
                      </span>
                      <div className="flex items-baseline gap-1.5">
                        {hasDiscount ? (
                          <>
                            <span className="font-serif text-lg font-black text-[#B8782A]">
                              Rs {finalPrice.toLocaleString()}
                            </span>
                            <span className="text-xs text-neutral-400 line-through">
                              Rs {basePrice.toLocaleString()}
                            </span>
                          </>
                        ) : (
                          <span className="font-serif text-lg font-bold text-neutral-900">
                            Rs {basePrice.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={(e) => handleQuickAdd(e, item)}
                      className={`inline-flex items-center justify-center p-2.5 rounded-full transition-all duration-300 shadow-sm ${
                        isAdded
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[#B8782A] text-white hover:bg-[#9c631e] hover:scale-105 active:scale-95'
                      }`}
                      title={hasVariants ? 'Choose Portion Size' : 'Add to Cart'}
                      aria-label="Add dish to cart"
                    >
                      {isAdded ? <Check size={16} /> : <Plus size={16} />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Dish Detail Modal for Size Variants & Add */}
      {selectedDish && (
        <DishDetailModal
          dish={selectedDish}
          onClose={() => setSelectedDish(null)}
          onAddToCart={(dish, variant, qty) => {
            store.addToCart(dish, variant, qty);
          }}
        />
      )}
    </div>
  );
};
