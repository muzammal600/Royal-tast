import React, { useState } from 'react';
import { MenuItem, SizeVariant } from '../../types';
import { X, Star, Plus, Minus, ShoppingBag, Check } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';

interface DishDetailModalProps {
  dish: MenuItem | null;
  onClose: () => void;
  onAddToCart: (dish: MenuItem, variantName?: string, quantity?: number) => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({
  dish,
  onClose,
  onAddToCart
}) => {
  if (!dish) return null;

  const [selectedVariant, setSelectedVariant] = useState<SizeVariant | undefined>(
    dish.size_variants && dish.size_variants.length > 0 ? dish.size_variants[0] : undefined
  );
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const basePrice = selectedVariant ? selectedVariant.price : dish.price;
  const hasDiscount = dish.discount_percent && dish.discount_percent > 0;
  const finalPrice = hasDiscount
    ? Math.round(basePrice * (1 - dish.discount_percent! / 100))
    : basePrice;

  const handleAdd = () => {
    onAddToCart(dish, selectedVariant?.name, quantity);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 900);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-amber-900/15 relative flex flex-col max-h-[90vh]"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/50 hover:bg-black/75 text-white transition-colors"
          aria-label="Close dish details"
        >
          <X size={18} />
        </button>

        {/* Dish Image */}
        <div className="relative h-56 sm:h-64 w-full bg-neutral-100 shrink-0">
          <img
            src={dish.image_url}
            alt={dish.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

          {/* Badges on Image */}
          <div className="absolute bottom-3 left-4 flex flex-wrap items-center gap-2">
            {dish.badge && (
              <span className="bg-[#B8782A] text-white text-xs font-bold px-3 py-0.5 rounded-full shadow">
                {dish.badge}
              </span>
            )}
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded bg-white shadow-sm flex items-center gap-1 ${
                dish.veg_nonveg === 'veg' ? 'text-emerald-700' : 'text-rose-700'
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  dish.veg_nonveg === 'veg' ? 'bg-emerald-600' : 'bg-rose-600'
                }`}
              ></span>
              {dish.veg_nonveg === 'veg' ? 'VEG' : 'NON-VEG'}
            </span>
          </div>
        </div>

        {/* Dish Details Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-1 text-[#B8782A] text-xs font-semibold mb-1">
                <Star size={14} className="fill-current text-[#B8782A]" />
                <span>{dish.rating.toFixed(1)}</span>
                <span className="text-neutral-400 font-normal">/ 5.0 (Customer Rated)</span>
              </div>
              <h3 className="font-serif text-2xl font-bold text-neutral-900 leading-snug">
                {dish.name}
              </h3>
            </div>

            <div className="text-right shrink-0">
              {hasDiscount ? (
                <>
                  <span className="font-serif text-2xl font-black text-[#B8782A] block">
                    Rs {finalPrice.toLocaleString()}
                  </span>
                  <span className="text-xs text-neutral-400 line-through">
                    Rs {basePrice.toLocaleString()}
                  </span>
                </>
              ) : (
                <span className="font-serif text-2xl font-black text-neutral-900 block">
                  Rs {basePrice.toLocaleString()}
                </span>
              )}
            </div>
          </div>

          <p className="text-neutral-600 text-sm leading-relaxed">
            {dish.description}
          </p>

          {/* Size Variants (e.g. Half / Full, S / M / L, Leg / Chest) */}
          {dish.size_variants && dish.size_variants.length > 0 && (
            <div className="pt-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-2">
                Choose Size / Portion Option:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {dish.size_variants.map((variant) => {
                  const isSelected = selectedVariant?.name === variant.name;
                  return (
                    <button
                      key={variant.name}
                      onClick={() => setSelectedVariant(variant)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        isSelected
                          ? 'border-[#B8782A] bg-amber-50/70 text-neutral-900 ring-1 ring-[#B8782A]'
                          : 'border-neutral-200 hover:border-neutral-300 text-neutral-700'
                      }`}
                    >
                      <p className="text-xs font-bold">{variant.name}</p>
                      <p className="text-xs text-[#B8782A] font-semibold mt-0.5">
                        Rs {variant.price.toLocaleString()}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quantity selector */}
          <div className="pt-2 flex items-center justify-between border-t border-neutral-100">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-700">
              Quantity
            </span>
            <div className="flex items-center gap-3 bg-neutral-100 rounded-full px-3 py-1">
              <button
                onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                className="p-1 hover:text-[#B8782A] transition-colors"
                aria-label="Decrease quantity"
              >
                <Minus size={15} />
              </button>
              <span className="font-bold text-sm min-w-[20px] text-center">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((prev) => prev + 1)}
                className="p-1 hover:text-[#B8782A] transition-colors"
                aria-label="Increase quantity"
              >
                <Plus size={15} />
              </button>
            </div>
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="p-4 sm:p-6 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-neutral-400 uppercase tracking-wider block font-medium">
              Total Amount
            </span>
            <span className="font-serif text-xl font-bold text-neutral-900">
              Rs {(finalPrice * quantity).toLocaleString()}
            </span>
          </div>

          <button
            onClick={handleAdd}
            className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-7 py-3 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 shadow-md ${
              added
                ? 'bg-emerald-600 text-white'
                : 'bg-[#B8782A] text-white hover:bg-[#9c631e]'
            }`}
          >
            {added ? (
              <>
                <Check size={16} />
                <span>Added to Cart</span>
              </>
            ) : (
              <>
                <ShoppingBag size={16} />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
