import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Order, OrderStatus } from '../../types';
import { Search, Clock, CheckCircle, Truck, Utensils, AlertCircle, Phone, MapPin, Navigation, ShoppingBag } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';

interface OrderTrackingPageProps {
  initialOrderCode?: string | null;
  onExploreMenu: () => void;
}

const STAGES: { status: OrderStatus; label: string; desc: string; icon: any }[] = [
  {
    status: 'Pending',
    label: 'Order Received',
    desc: 'Kitchen has received your order and is verifying items.',
    icon: Clock
  },
  {
    status: 'Preparing',
    label: 'In Royal Kitchen',
    desc: 'Master chefs are wok-cooking and grilling your meal fresh.',
    icon: Utensils
  },
  {
    status: 'On the way',
    label: 'Out for Delivery',
    desc: 'Rider is en route to your address in thermal insulated box.',
    icon: Truck
  },
  {
    status: 'Delivered',
    label: 'Feast Delivered',
    desc: 'Delivered to your doorstep. Bon appétit!',
    icon: CheckCircle
  }
];

export const OrderTrackingPage: React.FC<OrderTrackingPageProps> = ({
  initialOrderCode,
  onExploreMenu
}) => {
  const { store, activeOrderCode, siteSettings } = useRoyalStore();
  const [searchInput, setSearchInput] = useState(initialOrderCode || activeOrderCode || '');
  const [queriedCode, setQueriedCode] = useState(initialOrderCode || activeOrderCode || '');

  const order = queriedCode ? store.getOrderByCode(queriedCode) : undefined;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    setQueriedCode(searchInput.trim());
  };

  const getStageIndex = (status: OrderStatus) => {
    if (status === 'Cancelled') return -1;
    return STAGES.findIndex((s) => s.status === status);
  };

  const currentStageIndex = order ? getStageIndex(order.status) : 0;

  return (
    <div className="bg-[#FAF5EC] min-h-screen py-10 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#B8782A]/10 border border-[#B8782A]/30 text-xs font-semibold text-[#B8782A] mb-3">
            <CrownIcon size={16} color="#B8782A" />
            <span>Live Dispatch Telemetry</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-neutral-900">
            Track Your Royal Feast
          </h1>
          <p className="text-sm text-neutral-600 mt-2">
            Watch the live progress of your order from our kitchen to your dining table.
          </p>

          {/* Search Order Number Form */}
          <form onSubmit={handleSearch} className="mt-6 max-w-md mx-auto flex gap-2">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-4 top-3.5 text-neutral-400" />
              <input
                type="text"
                placeholder="Enter Order Code (e.g. RT-8492)..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-white border border-neutral-300 rounded-2xl text-sm uppercase tracking-wider font-semibold focus:outline-none focus:border-[#B8782A]"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-2xl bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e] transition-colors shadow"
            >
              Track
            </button>
          </form>
        </div>

        {/* Order Details View */}
        {order ? (
          <div className="bg-white rounded-3xl overflow-hidden shadow-xl border border-neutral-200/80 p-6 sm:p-10 space-y-8">
            {/* Order Top Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-100">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#B8782A] font-bold">
                  Order Tracking ID
                </span>
                <h2 className="font-serif text-2xl sm:text-3xl font-black text-neutral-900 mt-0.5">
                  {order.order_number}
                </h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Placed on {new Date(order.created_at).toLocaleDateString()} at{' '}
                  {new Date(order.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>

              <div className="flex flex-col sm:items-end">
                <span className="text-xs text-neutral-500 font-medium">Estimated Arrival</span>
                <span className="font-serif text-lg font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 mt-1">
                  {order.estimated_delivery_time || '35 - 45 Minutes'}
                </span>
              </div>
            </div>

            {/* Stepper Visualization */}
            {order.status === 'Cancelled' ? (
              <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 flex items-center gap-3">
                <AlertCircle size={24} className="shrink-0" />
                <div>
                  <h4 className="font-bold text-sm">Order Cancelled</h4>
                  <p className="text-xs mt-0.5">
                    This order was cancelled. If you believe this is an error, please contact Manager {siteSettings.manager_name} at {siteSettings.manager_number}.
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 relative">
                  {STAGES.map((stage, idx) => {
                    const isCompleted = idx <= currentStageIndex;
                    const isCurrent = idx === currentStageIndex;
                    const Icon = stage.icon;

                    return (
                      <div
                        key={stage.status}
                        className={`p-4 rounded-2xl border transition-all ${
                          isCurrent
                            ? 'bg-amber-50/80 border-[#B8782A] ring-2 ring-[#B8782A]/30 shadow-md'
                            : isCompleted
                            ? 'bg-emerald-50/50 border-emerald-200'
                            : 'bg-neutral-50 border-neutral-200 opacity-60'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div
                            className={`h-10 w-10 rounded-full flex items-center justify-center ${
                              isCurrent
                                ? 'bg-[#B8782A] text-white animate-pulse'
                                : isCompleted
                                ? 'bg-emerald-600 text-white'
                                : 'bg-neutral-200 text-neutral-500'
                            }`}
                          >
                            <Icon size={20} />
                          </div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                            Step 0{idx + 1}
                          </span>
                        </div>

                        <h4 className="font-serif text-sm font-bold text-neutral-900">
                          {stage.label}
                        </h4>
                        <p className="text-[11px] text-neutral-600 mt-1 leading-snug">
                          {stage.desc}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Customer Details & Geolocation Coordinate Tag */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-neutral-50 p-6 rounded-2xl border border-neutral-200/80 text-xs">
              <div className="space-y-2">
                <span className="font-bold text-neutral-800 uppercase tracking-wider block">
                  Delivery Destination
                </span>
                <p className="font-medium text-neutral-900 text-sm">{order.customer.name}</p>
                <p className="text-neutral-600">{order.customer.phone}</p>
                <p className="text-neutral-700 leading-relaxed">{order.customer.address}</p>
                {order.customer.notes && (
                  <p className="text-amber-900 bg-amber-100/60 p-2 rounded-lg italic">
                    Note: "{order.customer.notes}"
                  </p>
                )}
              </div>

              <div className="space-y-2 border-t md:border-t-0 md:border-l border-neutral-200 pt-4 md:pt-0 md:pl-6">
                <span className="font-bold text-neutral-800 uppercase tracking-wider block">
                  GPS Geolocation Coordinates
                </span>
                {order.customer.lat && order.customer.lng ? (
                  <div className="space-y-2">
                    <p className="text-emerald-700 font-mono flex items-center gap-1.5">
                      <MapPin size={14} className="text-emerald-600" />
                      <span>{order.customer.lat.toFixed(6)}, {order.customer.lng.toFixed(6)}</span>
                    </p>
                    <a
                      href={`https://www.google.com/maps?q=${order.customer.lat},${order.customer.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 text-white font-semibold text-[11px] hover:bg-neutral-800"
                    >
                      <Navigation size={12} className="text-[#B8782A]" />
                      <span>View Live Rider Route on Google Maps</span>
                    </a>
                  </div>
                ) : (
                  <p className="text-neutral-500">
                    Standard address dispatch without manual GPS coordinates.
                  </p>
                )}

                <div className="pt-2">
                  <span className="font-semibold text-neutral-700 block">Payment Method:</span>
                  <span className="text-[#B8782A] font-bold">Cash on Delivery (COD)</span>
                </div>
              </div>
            </div>

            {/* Items Summary */}
            <div className="space-y-3">
              <h3 className="font-serif text-lg font-bold text-neutral-900">
                Ordered Dishes ({order.items.length})
              </h3>
              <div className="divide-y divide-neutral-100">
                {order.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between text-xs sm:text-sm">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#B8782A]">{item.quantity}x</span>
                      <span className="font-medium text-neutral-900">{item.item_name}</span>
                      {item.variant_name && (
                        <span className="text-xs text-neutral-500">({item.variant_name})</span>
                      )}
                    </div>
                    <span className="font-semibold text-neutral-800">
                      Rs {item.total.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              {/* Total Summary */}
              <div className="pt-4 border-t border-neutral-200 space-y-1.5 text-xs text-neutral-600">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>Rs {order.subtotal.toLocaleString()}</span>
                </div>
                {order.discount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Discount:</span>
                    <span>- Rs {order.discount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Delivery Charges:</span>
                  <span>{order.delivery_fee === 0 ? 'FREE' : `Rs ${order.delivery_fee}`}</span>
                </div>
                <div className="flex justify-between text-base font-bold text-neutral-900 pt-2 border-t border-neutral-200">
                  <span>Total Amount Paid / Payable:</span>
                  <span className="font-serif text-xl text-[#B8782A]">
                    Rs {order.total_amount.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* Need Help Footer */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-neutral-100 text-xs text-neutral-500">
              <span>Having any issue with your delivery?</span>
              <a
                href={`tel:${siteSettings.manager_number.replace(/\s+/g, '')}`}
                className="inline-flex items-center gap-1.5 text-[#B8782A] font-bold hover:underline"
              >
                <Phone size={13} />
                <span>Call Restaurant Manager ({siteSettings.manager_number})</span>
              </a>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-12 text-center shadow-md max-w-md mx-auto space-y-4">
            <div className="h-14 w-14 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
              <ShoppingBag size={26} />
            </div>
            <h3 className="font-serif text-xl font-bold text-neutral-900">
              No Order Found
            </h3>
            <p className="text-xs sm:text-sm text-neutral-500">
              Please enter your order tracking number (e.g. RT-8492) sent to you when placing an order.
            </p>
            <div className="pt-2">
              <button
                onClick={onExploreMenu}
                className="px-6 py-2.5 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e] transition-colors"
              >
                Explore Menu & Order
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
