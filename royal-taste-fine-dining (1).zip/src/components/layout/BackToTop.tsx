import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export const BackToTop: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!visible) return null;

  return (
    <button
      onClick={scrollToTop}
      aria-label="Scroll back to top"
      className="fixed bottom-6 left-6 z-40 h-11 w-11 rounded-full bg-white/90 hover:bg-[#FAF5EC] text-neutral-800 hover:text-[#B8782A] border border-[#B8782A]/30 shadow-lg backdrop-blur flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95"
    >
      <ArrowUp size={18} />
    </button>
  );
};
