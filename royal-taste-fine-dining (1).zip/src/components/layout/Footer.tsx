import React from 'react';
import { CrownIcon } from '../common/CrownIcon';
import { Phone, Mail, MapPin, Clock, ArrowRight, Shield } from 'lucide-react';
import { useRoyalStore } from '../../hooks/useRoyalStore';

interface FooterProps {
  onNavigate: (view: 'home' | 'menu' | 'tracking' | 'admin', sectionId?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { siteSettings } = useRoyalStore();

  return (
    <footer className="bg-[#19140e] text-neutral-300 pt-16 pb-8 border-t border-amber-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-neutral-800">
          {/* Column 1: Brand & Bio */}
          <div className="space-y-4">
            <div className="flex flex-col items-start">
              <CrownIcon size={24} color="#B8782A" className="mb-1" />
              <span className="font-serif text-2xl font-black tracking-[0.16em] text-white">
                ROYAL TASTE
              </span>
              <span className="text-[10px] tracking-[0.3em] uppercase text-[#B8782A] font-semibold">
                Fine Dining
              </span>
            </div>

            <p className="text-sm text-neutral-400 leading-relaxed">
              Experience the pinnacle of royal Pakistani culinary heritage. Handcrafted Mughlai karahis,
              aromatic dum biryanis, live charcoal grills, and exquisite desserts prepared by master chefs.
            </p>

            <div className="pt-2">
              <span className="inline-block text-xs uppercase tracking-widest text-[#B8782A] font-semibold bg-[#B8782A]/10 px-3 py-1 rounded-full border border-[#B8782A]/30">
                100% Halal Certified Cuisine
              </span>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="font-serif text-lg font-bold text-white mb-4 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-[#B8782A]"></span>
              Quick Exploration
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight size={13} className="text-[#B8782A]" />
                  <span>Home & Atmosphere</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('menu')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5 font-medium text-amber-200"
                >
                  <ArrowRight size={13} className="text-[#B8782A]" />
                  <span>Full 100-Item Menu</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('home', 'specials')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight size={13} className="text-[#B8782A]" />
                  <span>This Week's Specials</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('home', 'deals')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight size={13} className="text-[#B8782A]" />
                  <span>Family & Student Deals</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('home', 'reservation')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight size={13} className="text-[#B8782A]" />
                  <span>Reserve a Table</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('tracking')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5"
                >
                  <ArrowRight size={13} className="text-[#B8782A]" />
                  <span>Live Order Tracking</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin')}
                  className="hover:text-[#B8782A] transition-colors flex items-center gap-1.5 text-amber-300 font-semibold"
                >
                  <Shield size={13} className="text-[#B8782A]" />
                  <span>Admin Management Portal</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Hours & Manager Details */}
          <div>
            <h3 className="font-serif text-lg font-bold text-white mb-4 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-[#B8782A]"></span>
              Operating Hours & Manager
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2.5">
                <Clock size={16} className="text-[#B8782A] mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium text-white">Dining & Delivery Hours:</p>
                  <p className="text-neutral-400 text-xs sm:text-sm mt-0.5">{siteSettings.hours}</p>
                </div>
              </div>

              <div className="pt-2 border-t border-neutral-800">
                <p className="text-xs uppercase tracking-wider text-[#B8782A] font-semibold">
                  General Manager
                </p>
                <p className="text-white font-medium mt-0.5">{siteSettings.manager_name}</p>
                <a
                  href={`tel:${siteSettings.manager_number.replace(/\s+/g, '')}`}
                  className="text-xs sm:text-sm text-amber-200/90 hover:text-[#B8782A] flex items-center gap-1.5 mt-1"
                >
                  <Phone size={13} className="text-[#B8782A]" />
                  <span>{siteSettings.manager_number}</span>
                </a>
              </div>
            </div>
          </div>

          {/* Column 4: Contact & Location */}
          <div>
            <h3 className="font-serif text-lg font-bold text-white mb-4 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-[#B8782A]"></span>
              Reach Out
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2.5">
                <MapPin size={16} className="text-[#B8782A] mt-0.5 shrink-0" />
                <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed">
                  {siteSettings.address}
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone size={16} className="text-[#B8782A] shrink-0" />
                <a
                  href={`tel:${siteSettings.phone.replace(/\s+/g, '')}`}
                  className="hover:text-[#B8782A] transition-colors"
                >
                  {siteSettings.phone}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail size={16} className="text-[#B8782A] shrink-0" />
                <a
                  href={`mailto:${siteSettings.email}`}
                  className="hover:text-[#B8782A] transition-colors text-xs sm:text-sm"
                >
                  {siteSettings.email}
                </a>
              </div>

              {/* Social Icons */}
              <div className="pt-3">
                <p className="text-xs text-neutral-400 mb-2 font-medium">Follow Royal Taste:</p>
                <div className="flex items-center gap-3">
                  <a
                    href={siteSettings.social_facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-8 w-8 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-300 hover:bg-[#B8782A] hover:text-white transition-colors"
                    aria-label="Facebook"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95C18.05 21.45 22 17.19 22 12z" />
                    </svg>
                  </a>
                  <a
                    href={siteSettings.social_instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-8 w-8 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-300 hover:bg-[#B8782A] hover:text-white transition-colors"
                    aria-label="Instagram"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                    </svg>
                  </a>
                  <a
                    href={siteSettings.social_youtube}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-8 w-8 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-300 hover:bg-[#B8782A] hover:text-white transition-colors"
                    aria-label="YouTube"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Credits & Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-4">
          <p>© {new Date().getFullYear()} ROYAL TASTE – Fine Dining. All Rights Reserved. Lahore, Pakistan.</p>
          <div className="flex items-center gap-6">
            <span>Prices listed in Pakistani Rupees (Rs / PKR)</span>
            <span>All Taxes Included</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
