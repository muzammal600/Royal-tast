import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, User, Menu as MenuIcon, X, Calendar, Tag, ShieldCheck } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';
import { useRoyalStore } from '../../hooks/useRoyalStore';

interface NavbarProps {
  currentView: 'home' | 'menu' | 'tracking' | 'admin';
  onNavigate: (view: 'home' | 'menu' | 'tracking' | 'admin', sectionId?: string) => void;
  onOpenCart: () => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenCart,
  onOpenSearch
}) => {
  const { cartCalculations, currentAdmin } = useRoyalStore();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (view: 'home' | 'menu' | 'tracking' | 'admin', sectionId?: string) => {
    setMobileMenuOpen(false);
    onNavigate(view, sectionId);
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF5EC]/95 backdrop-blur-md shadow-md py-2.5 border-b border-[#B8782A]/20'
          : 'bg-[#FAF5EC] py-3.5 border-b border-neutral-200'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Left Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-7 text-sm font-medium tracking-wide">
            <button
              onClick={() => handleLinkClick('home')}
              className={`transition-colors hover:text-[#B8782A] ${
                currentView === 'home' ? 'text-[#B8782A] font-semibold' : 'text-neutral-800'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleLinkClick('menu')}
              className={`transition-colors hover:text-[#B8782A] ${
                currentView === 'menu' ? 'text-[#B8782A] font-semibold' : 'text-neutral-800'
              }`}
            >
              Menu (100 Dishes)
            </button>
            <button
              onClick={() => handleLinkClick('home', 'specials')}
              className="text-neutral-800 hover:text-[#B8782A] transition-colors"
            >
              Weekly Specials
            </button>
            <button
              onClick={() => handleLinkClick('home', 'about')}
              className="text-neutral-800 hover:text-[#B8782A] transition-colors"
            >
              About
            </button>
          </nav>

          {/* Mobile Hamburger Button */}
          <div className="flex lg:hidden items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-neutral-800 hover:text-[#B8782A] hover:bg-[#B8782A]/10 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <MenuIcon size={24} />}
            </button>
          </div>

          {/* CENTERED LOGO: "ROYAL TASTE" with gold crown above */}
          <button
            onClick={() => handleLinkClick('home')}
            className="flex flex-col items-center group cursor-pointer focus:outline-none"
          >
            <CrownIcon
              size={20}
              color="#B8782A"
              className="transition-transform duration-300 group-hover:scale-110 drop-shadow-sm mb-0.5"
            />
            <span className="font-serif text-xl sm:text-2xl font-black tracking-[0.18em] text-neutral-900 leading-none">
              ROYAL TASTE
            </span>
            <span className="text-[9px] tracking-[0.35em] uppercase text-[#B8782A] font-medium mt-0.5">
              Fine Dining
            </span>
          </button>

          {/* Right Action Links & Icons */}
          <div className="flex items-center space-x-2 sm:space-x-5">
            <button
              onClick={() => handleLinkClick('home', 'reservation')}
              className="hidden md:flex items-center gap-1.5 text-xs sm:text-sm font-medium text-neutral-800 hover:text-[#B8782A] transition-colors"
            >
              <Calendar size={15} className="text-[#B8782A]" />
              <span>Reservation</span>
            </button>

            <button
              onClick={() => handleLinkClick('home', 'offers')}
              className="hidden sm:flex items-center gap-1.5 text-xs sm:text-sm font-medium text-neutral-800 hover:text-[#B8782A] transition-colors"
            >
              <Tag size={15} className="text-[#B8782A]" />
              <span>Offers</span>
            </button>

            {/* Search Button */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-neutral-800 hover:text-[#B8782A] transition-colors rounded-full hover:bg-neutral-100"
              aria-label="Search dishes"
              title="Search 100 Menu Dishes"
            >
              <Search size={19} />
            </button>

            {/* Cart Icon with badge */}
            <button
              onClick={onOpenCart}
              className="relative p-2 text-neutral-800 hover:text-[#B8782A] transition-colors rounded-full hover:bg-neutral-100"
              aria-label="View Cart"
            >
              <ShoppingBag size={20} />
              {cartCalculations.totalItemsCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-[#B8782A] text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center shadow">
                  {cartCalculations.totalItemsCount}
                </span>
              )}
            </button>

            {/* Admin / User Icon */}
            <button
              onClick={() => handleLinkClick('admin')}
              className={`p-2 rounded-full transition-colors ${
                currentAdmin
                  ? 'bg-amber-100 text-[#B8782A] border border-[#B8782A]/30'
                  : 'text-neutral-800 hover:text-[#B8782A] hover:bg-neutral-100'
              }`}
              title={currentAdmin ? `Logged in as Admin: ${currentAdmin.email}` : 'Admin Portal Login'}
            >
              {currentAdmin ? <ShieldCheck size={19} /> : <User size={19} />}
            </button>

            {/* Book A Table Primary Button */}
            <button
              onClick={() => handleLinkClick('home', 'reservation')}
              className="hidden lg:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#B8782A] hover:bg-[#9c631e] rounded-full shadow-sm hover:shadow transition-all"
            >
              Book Table
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 pt-3 border-t border-neutral-200 pb-2 space-y-2">
            <div className="grid grid-cols-2 gap-2 text-sm font-medium">
              <button
                onClick={() => handleLinkClick('home')}
                className="text-left py-2 px-3 rounded-lg bg-neutral-100 text-neutral-900"
              >
                Home
              </button>
              <button
                onClick={() => handleLinkClick('menu')}
                className="text-left py-2 px-3 rounded-lg bg-[#B8782A]/10 text-[#B8782A] font-semibold"
              >
                Full Menu (100)
              </button>
              <button
                onClick={() => handleLinkClick('home', 'specials')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-100 text-neutral-800"
              >
                Weekly Specials
              </button>
              <button
                onClick={() => handleLinkClick('home', 'deals')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-100 text-neutral-800"
              >
                Deals
              </button>
              <button
                onClick={() => handleLinkClick('home', 'reservation')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-100 text-neutral-800"
              >
                Reservation
              </button>
              <button
                onClick={() => handleLinkClick('home', 'about')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-100 text-neutral-800"
              >
                About Us
              </button>
              <button
                onClick={() => handleLinkClick('tracking')}
                className="text-left py-2 px-3 rounded-lg hover:bg-neutral-100 text-neutral-800"
              >
                Track Order
              </button>
              <button
                onClick={() => handleLinkClick('admin')}
                className="text-left py-2 px-3 rounded-lg bg-neutral-900 text-amber-200"
              >
                Admin Panel
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
