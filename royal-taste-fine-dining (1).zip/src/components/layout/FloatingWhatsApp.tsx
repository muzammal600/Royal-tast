import React, { useState, useEffect } from 'react';
import { MessageCircle, X, Sparkles, Copy, Check, ArrowRight, ShieldCheck, MapPin, Users, Clock, Flame, ChevronRight, UserCheck } from 'lucide-react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { analyzeInquiryKeywords, KeywordAnalysisResult } from '../../utils/aiResponseTemplates';
import { CrownIcon } from '../common/CrownIcon';

const PRESET_TOPICS = [
  { label: 'Table for 6 Tonight', query: 'I would like to reserve a family table for 6 guests tonight around 8:30 PM on MM Alam Road.' },
  { label: 'Hot Delivery to DHA', query: 'Do you deliver to DHA Phase 5? How long will hot delivery take and what is the delivery fee?' },
  { label: 'Shinwari Mutton Karahi', query: 'We want to order your fresh Shinwari Mutton Karahi and Roghni Naans cooked in pure dairy desi ghee.' },
  { label: 'Charcoal BBQ Platter', query: 'Is the BBQ Platter for 2 and Malai Boti available for takeaway right now?' },
  { label: 'Banquet Catering (50 Pax)', query: 'We need catering details, live BBQ tandoor setup, and rates for an executive event of 50 people.' },
  { label: '20% Off Deal (FIRST20)', query: 'How can I apply the 20% discount FIRST20 promo code for our family dinner order today?' }
];

type TemplateTab = 'regal' | 'concise' | 'vip' | 'managerPreview';

export const FloatingWhatsApp: React.FC = () => {
  const { siteSettings } = useRoyalStore();
  const [isOpen, setIsOpen] = useState(false);
  const [inquiryText, setInquiryText] = useState('');
  const [activeTab, setActiveTab] = useState<TemplateTab>('regal');
  const [analysis, setAnalysis] = useState<KeywordAnalysisResult | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [customDraftOverride, setCustomDraftOverride] = useState<string | null>(null);

  // Clean WhatsApp phone number from admin siteSettings
  const cleanNumber = siteSettings.whatsapp.replace(/\D/g, '');

  // Perform live keyword analysis whenever inquiryText changes
  useEffect(() => {
    const rawText = inquiryText.trim() || 'Assalam-o-Alaikum! I would like to inquire about fine dining, reservations, and delivery at Royal Taste.';
    const result = analyzeInquiryKeywords(rawText);
    setAnalysis(result);
    setCustomDraftOverride(null);
  }, [inquiryText]);

  // Compute the current active message based on tab
  const getActiveMessageText = (): string => {
    if (customDraftOverride) return customDraftOverride;
    if (!analysis) return '';

    if (activeTab === 'regal') {
      return analysis.templates.customer.regal;
    }
    if (activeTab === 'concise') {
      return analysis.templates.customer.concise;
    }
    if (activeTab === 'vip') {
      return analysis.templates.customer.vip;
    }
    if (activeTab === 'managerPreview') {
      return analysis.templates.manager.instantConfirmation;
    }
    return analysis.suggestedCustomerDraft;
  };

  // Request enhanced AI draft from server-side Gemini 3.8 Flash
  const handleEnhanceWithAi = async () => {
    if (!inquiryText.trim()) return;

    setIsAiLoading(true);
    try {
      const res = await fetch('/api/ai/draft-response', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: inquiryText,
          perspective: activeTab === 'managerPreview' ? 'manager' : 'customer',
          templateStyle: activeTab === 'managerPreview' ? 'instantConfirmation' : activeTab
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.draft) {
          setCustomDraftOverride(data.draft);
        }
      }
    } catch (err) {
      console.warn('Gemini AI draft request failed, maintaining rule template:', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleCopy = () => {
    const textToCopy = getActiveMessageText();
    navigator.clipboard?.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const activeDraft = getActiveMessageText();
  const whatsappUrl = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(activeDraft)}`;

  return (
    <>
      {/* Floating Trigger Button */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2 group">
        <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none bg-neutral-900 text-amber-100 text-xs font-medium py-1.5 px-3 rounded-lg shadow-xl whitespace-nowrap mb-1 flex items-center gap-1.5 border border-amber-900/20">
          <CrownIcon size={12} color="#B8782A" />
          <span>Chat with General Manager (AI Concierge)</span>
        </span>

        <button
          onClick={() => setIsOpen(true)}
          aria-label="Open AI WhatsApp Assistant"
          className="h-14 w-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 relative focus:outline-none ring-4 ring-white/80"
        >
          <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-25"></span>
          <MessageCircle size={28} className="relative z-10 fill-current" />
          <span className="absolute -top-1 -right-1 bg-amber-400 text-neutral-900 p-1 rounded-full ring-2 ring-white shadow">
            <Sparkles size={11} className="fill-current text-amber-950" />
          </span>
        </button>
      </div>

      {/* AI-Driven WhatsApp Inquiry Drafter Modal */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-3 sm:p-5 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl border border-amber-900/15 flex flex-col max-h-[92vh]"
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-gradient-to-r from-[#1a140d] via-[#2a1e12] to-[#1c150e] text-white flex items-center justify-between border-b border-amber-900/20">
              <div className="flex items-center gap-3">
                <div className="h-11 w-11 rounded-2xl bg-[#25D366] text-white flex items-center justify-center shadow-lg shrink-0">
                  <MessageCircle size={22} className="fill-current" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <CrownIcon size={14} color="#DDA853" />
                    <h3 className="font-serif font-bold text-base text-white tracking-wide">
                      Royal WhatsApp Concierge
                    </h3>
                  </div>
                  <p className="text-[11px] text-amber-200/90 flex items-center gap-1.5 mt-0.5">
                    <span>Direct line to Manager {siteSettings.manager_name}</span>
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="text-emerald-300 font-medium">Online</span>
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
                aria-label="Close assistant"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
              {/* Quick Preset Topics */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                  Choose a Quick Inquiry Topic:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {PRESET_TOPICS.map((topic, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setInquiryText(topic.query);
                        setCustomDraftOverride(null);
                      }}
                      className="px-2.5 py-1.5 rounded-full bg-[#FAF5EC] hover:bg-amber-100 text-neutral-800 border border-amber-900/15 text-[11px] font-medium transition-colors"
                    >
                      {topic.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Inquiry Input Area */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-700 mb-1.5">
                  Describe what you need (or type your request):
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Table for 8 people tonight around 9 PM on MM Alam Road, or inquire about DHA delivery..."
                  value={inquiryText}
                  onChange={(e) => {
                    setInquiryText(e.target.value);
                    setCustomDraftOverride(null);
                  }}
                  className="w-full p-3 bg-neutral-50 border border-neutral-200 rounded-xl text-xs focus:outline-none focus:border-[#B8782A] focus:bg-white transition-colors"
                />
              </div>

              {/* Real-time Keyword & Context Entity Intelligence */}
              {analysis && (
                <div className="bg-[#FAF5EC] p-3 rounded-2xl border border-amber-900/15 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-neutral-700 text-[11px]">Detected Intent:</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-[#B8782A] text-white text-[10px] font-bold uppercase tracking-wider shadow-xs">
                        {analysis.matchedCategory}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-[10px] text-neutral-500">
                      <span>Keywords:</span>
                      <span className="font-semibold text-neutral-800 bg-white px-2 py-0.5 rounded-md border border-amber-200">
                        {analysis.matchedKeywords.slice(0, 4).join(', ') || 'Fine Dining'}
                      </span>
                    </div>
                  </div>

                  {/* Extracted Context Entities Badges */}
                  {(analysis.entities.guestCount || analysis.entities.timeOrDate || analysis.entities.locationArea || analysis.entities.dishesMentioned.length > 0) && (
                    <div className="pt-2 border-t border-amber-900/10 flex flex-wrap items-center gap-1.5 text-[10px]">
                      <span className="text-neutral-500 font-medium">Context Extracted:</span>
                      {analysis.entities.guestCount && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-950 font-bold">
                          <Users size={11} className="text-[#B8782A]" />
                          <span>{analysis.entities.guestCount} Guests</span>
                        </span>
                      )}
                      {analysis.entities.timeOrDate && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-950 font-bold">
                          <Clock size={11} className="text-[#B8782A]" />
                          <span>{analysis.entities.timeOrDate}</span>
                        </span>
                      )}
                      {analysis.entities.locationArea && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100 text-amber-950 font-bold">
                          <MapPin size={11} className="text-[#B8782A]" />
                          <span>{analysis.entities.locationArea}</span>
                        </span>
                      )}
                      {analysis.entities.dishesMentioned.map((dish, i) => (
                        <span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-950 font-bold">
                          <Flame size={11} className="text-emerald-700" />
                          <span>{dish}</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Template Style Selector Tabs */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-700">
                    Select Response Draft Style:
                  </span>

                  <button
                    onClick={handleEnhanceWithAi}
                    disabled={isAiLoading || !inquiryText.trim()}
                    className="text-[11px] text-[#B8782A] hover:text-[#9c631e] font-bold flex items-center gap-1 disabled:opacity-40 transition-colors"
                    title="Enhance with Gemini 3.8 Flash AI"
                  >
                    <Sparkles size={11} className={isAiLoading ? 'animate-spin' : ''} />
                    <span>{isAiLoading ? 'Crafting AI Draft...' : '✨ Enhance with Gemini'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-neutral-100 rounded-xl">
                  <button
                    onClick={() => {
                      setActiveTab('regal');
                      setCustomDraftOverride(null);
                    }}
                    className={`py-1.5 px-2 rounded-lg font-bold text-[11px] transition-all ${
                      activeTab === 'regal'
                        ? 'bg-white text-neutral-900 shadow-sm'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    👑 Regal & Courteous
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('concise');
                      setCustomDraftOverride(null);
                    }}
                    className={`py-1.5 px-2 rounded-lg font-bold text-[11px] transition-all ${
                      activeTab === 'concise'
                        ? 'bg-white text-neutral-900 shadow-sm'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    ⚡ Fast & Direct
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('vip');
                      setCustomDraftOverride(null);
                    }}
                    className={`py-1.5 px-2 rounded-lg font-bold text-[11px] transition-all ${
                      activeTab === 'vip'
                        ? 'bg-white text-neutral-900 shadow-sm'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    🌟 VIP Concierge
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('managerPreview');
                      setCustomDraftOverride(null);
                    }}
                    className={`py-1.5 px-2 rounded-lg font-bold text-[11px] transition-all ${
                      activeTab === 'managerPreview'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-emerald-800 hover:text-emerald-950'
                    }`}
                  >
                    👀 Manager Auto-Reply
                  </button>
                </div>
              </div>

              {/* Formatted WhatsApp Draft Preview */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                    {activeTab === 'managerPreview' ? (
                      <>
                        <UserCheck size={13} className="text-emerald-600" />
                        <span>Simulated Manager Response from Muhammad Rizwan:</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={12} className="text-[#B8782A]" />
                        <span>Drafted Message to Send on WhatsApp:</span>
                      </>
                    )}
                  </span>
                </div>

                {/* WhatsApp Chat Preview Bubble */}
                <div
                  className={`p-3.5 rounded-2xl border text-neutral-800 shadow-sm relative transition-colors ${
                    activeTab === 'managerPreview'
                      ? 'bg-emerald-50/90 border-emerald-300 rounded-tl-sm'
                      : 'bg-[#E7FFDB] border-emerald-200 rounded-tr-sm'
                  }`}
                >
                  <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed text-neutral-800">
                    {activeDraft}
                  </pre>
                  <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-emerald-200/50 text-[9px] text-neutral-500">
                    <span>
                      {activeTab === 'managerPreview'
                        ? 'Automated response generated based on your inquiry keywords'
                        : 'Pre-formatted for WhatsApp with Pakistani royal etiquette'}
                    </span>
                    <span className="font-mono text-emerald-800 font-semibold">100% Halal • Pure Desi Ghee</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 flex flex-col sm:flex-row items-center justify-between gap-2.5">
              <button
                onClick={handleCopy}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-neutral-200 hover:bg-neutral-100 text-neutral-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                {copied ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                <span>{copied ? 'Copied Message' : 'Copy Text'}</span>
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsOpen(false)}
                className="w-full sm:w-auto flex-1 py-3 px-6 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
              >
                <MessageCircle size={16} className="fill-current" />
                <span>Launch WhatsApp with Draft</span>
                <ArrowRight size={14} />
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
