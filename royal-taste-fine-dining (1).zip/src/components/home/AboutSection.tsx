import React from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { CrownIcon } from '../common/CrownIcon';
import { Award, Clock, Heart, Users } from 'lucide-react';

interface AboutSectionProps {
  onExploreMenu: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onExploreMenu }) => {
  return (
    <section id="about" className="py-16 sm:py-24 bg-[#FAF5EC] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left: Atmospheric Image Collage */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80"
                alt="Royal Taste Dining Ambience"
                className="w-full h-[400px] sm:h-[480px] object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex flex-col justify-end p-8 text-white">
                <span className="text-xs uppercase tracking-widest text-amber-300 font-semibold mb-1">
                  Est. Lahore, Pakistan
                </span>
                <h3 className="font-serif text-2xl font-bold">
                  A Royal Journey Through Flavor
                </h3>
              </div>
            </div>

            {/* Overlapping Floating Plate */}
            <div className="hidden sm:block absolute -bottom-8 -right-8 w-48 h-48 rounded-2xl overflow-hidden border-4 border-white shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=400&q=80"
                alt="Signature Karahi"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Right: Heritage Story & Stats */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2">
              <span className="h-px w-6 bg-[#B8782A]"></span>
              <span className="text-xs sm:text-sm font-semibold uppercase tracking-[0.25em] text-[#B8782A]">
                Our Royal Heritage
              </span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-neutral-900 tracking-tight leading-tight">
              Honoring Century-Old Pakistani Culinary Traditions
            </h2>

            <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
              Founded with the vision to celebrate the majestic richness of Subcontinental Mughlai and
              Shinwari gastronomy, <strong>ROYAL TASTE</strong> provides a haven for discerning food connoisseurs.
              From slow-simmered bone marrow Niharis to sizzling Shinwari Karahis cooked in pure desi ghee,
              every single dish is a testament to uncompromised craftsmanship.
            </p>

            <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
              We carefully hand-select each ingredient, grind our royal spice blends in-house daily,
              and prepare meat over authentic red-hot acacia coal for unmatched smokiness.
            </p>

            {/* Stats: 15+ years, 100+ dishes, 10k+ happy guests */}
            <div className="pt-4 grid grid-cols-3 gap-4 border-t border-b border-neutral-300/80 py-6">
              <div className="text-center sm:text-left">
                <span className="font-serif text-3xl sm:text-4xl font-black text-[#B8782A] block">
                  15+
                </span>
                <span className="text-xs sm:text-sm font-medium text-neutral-600 mt-0.5 block">
                  Years of Royalty
                </span>
              </div>

              <div className="text-center sm:text-left border-x border-neutral-300/60 px-3">
                <span className="font-serif text-3xl sm:text-4xl font-black text-[#B8782A] block">
                  100+
                </span>
                <span className="text-xs sm:text-sm font-medium text-neutral-600 mt-0.5 block">
                  Authentic Dishes
                </span>
              </div>

              <div className="text-center sm:text-left">
                <span className="font-serif text-3xl sm:text-4xl font-black text-[#B8782A] block">
                  10k+
                </span>
                <span className="text-xs sm:text-sm font-medium text-neutral-600 mt-0.5 block">
                  Happy Guests
                </span>
              </div>
            </div>

            {/* Read Menu CTA */}
            <div className="pt-2">
              <button
                onClick={onExploreMenu}
                className="inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-semibold uppercase tracking-wider text-white bg-[#B8782A] hover:bg-[#9c631e] rounded-full shadow transition-all duration-300"
              >
                <span>Discover Our Complete 100-Dish Menu</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
