import React, { useState } from 'react';
import { CrownIcon } from '../common/CrownIcon';
import { Tag, ArrowRight, Check, Copy } from 'lucide-react';
import { useRoyalStore } from '../../hooks/useRoyalStore';

interface OfferBannerProps {
  onOrderNow: () => void;
}

export const OfferBanner: React.FC<OfferBannerProps> = ({ onOrderNow }) => {
  const { store } = useRoyalStore();
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    store.applyPromoCode('FIRST20');
    navigator.clipboard?.writeText('FIRST20');
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section className="py-12 bg-[#FAF5EC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#1c160f] via-[#2a2014] to-[#1c160f] text-white p-8 sm:p-12 lg:p-14 shadow-2xl border border-amber-900/50">
          {/* Decorative Background Elements */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-[#B8782A]/20 blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-1/3 -mb-16 w-60 h-60 rounded-full bg-amber-500/10 blur-2xl pointer-events-none"></div>

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Offer Details */}
            <div className="lg:col-span-8 space-y-4 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#B8782A]/30 border border-[#B8782A]/50 text-amber-300 text-xs uppercase tracking-widest font-semibold">
                <Tag size={13} />
                <span>Special Welcome Privilege</span>
              </div>

              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                Get <span className="text-[#B8782A]">20% Off</span> On Your First Order
              </h2>

              <p className="text-sm sm:text-base text-neutral-300 max-w-xl mx-auto lg:mx-0 leading-relaxed font-light">
                Indulge in authentic royal Pakistani recipes from the comfort of your home.
                Use voucher code at checkout to unlock your exclusive 20% fine dining welcome discount.
              </p>

              {/* Promo Code Box */}
              <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-3">
                <div className="inline-flex items-center gap-3 bg-black/40 border border-amber-500/40 px-4 py-2 rounded-xl backdrop-blur">
                  <span className="text-xs text-neutral-400">Promo Code:</span>
                  <span className="font-mono text-base font-bold text-amber-300 tracking-wider">
                    FIRST20
                  </span>
                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 hover:bg-white/10 rounded text-neutral-300 hover:text-white transition-colors"
                    title="Copy & Apply Promo Code"
                  >
                    {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                  </button>
                </div>

                {copied && (
                  <span className="text-xs text-emerald-400 font-medium">
                    Code applied to cart!
                  </span>
                )}
              </div>
            </div>

            {/* Right Column: Order Now CTA */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center space-y-4">
              <div className="text-center">
                <span className="text-xs uppercase tracking-widest text-amber-200/80 font-medium block">
                  Limited Time Privilege
                </span>
                <span className="text-2xl font-serif font-bold text-white block mt-1">
                  Valid On Entire Menu
                </span>
              </div>

              <button
                onClick={onOrderNow}
                className="inline-flex items-center justify-center gap-2.5 px-8 py-4 text-sm font-bold uppercase tracking-wider text-neutral-900 bg-[#FAF5EC] hover:bg-white rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 group"
              >
                <span>Order Now</span>
                <ArrowRight size={17} className="text-[#B8782A] transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
