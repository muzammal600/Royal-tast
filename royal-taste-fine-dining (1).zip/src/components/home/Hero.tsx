import React, { useState, useEffect } from 'react';
import { CrownIcon } from '../common/CrownIcon';
import { Utensils, Calendar, ChevronRight, Star, Award, Flame } from 'lucide-react';

interface HeroProps {
  onExploreMenu: () => void;
  onBookTable: () => void;
}

const HERO_SLIDES = [
  {
    id: 1,
    title: 'Royal Chicken Karahi in Pure Desi Ghee',
    subtitle: 'Simmered with ginger juliennes and whole black peppercorn',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=1200&q=85',
    tag: 'Signature Mughlai'
  },
  {
    id: 2,
    title: 'Aromatic Shahi Dum Biryani',
    subtitle: 'Layered with saffron, dried plums, and tender farm chicken',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1200&q=85',
    tag: 'All-Time Favorite'
  },
  {
    id: 3,
    title: 'Live Charcoal BBQ Platter',
    subtitle: 'Reshmi kebabs, malai boti, and charred chicken tikka skewers',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1200&q=85',
    tag: 'Smoked Perfection'
  },
  {
    id: 4,
    title: 'Prime Aged Ribeye Steak',
    subtitle: 'Grilled over flame with rosemary herb butter & roasted veggies',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=85',
    tag: 'Continental Masterpiece'
  }
];

export const Hero: React.FC<HeroProps> = ({ onExploreMenu, onBookTable }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, []);

  const slide = HERO_SLIDES[currentSlide];

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#FAF5EC] via-[#f7f0e3] to-[#FAF5EC] pt-8 pb-16 lg:pt-14 lg:pb-24">
      {/* Subtle royal background decorations */}
      <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-[#B8782A]/5 blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 rounded-full bg-[#B8782A]/5 blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#B8782A]/10 border border-[#B8782A]/30 text-xs sm:text-sm font-medium text-[#B8782A]">
              <CrownIcon size={16} color="#B8782A" />
              <span>Authentic Pakistani Fine Dining</span>
            </div>

            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-black text-neutral-900 tracking-tight leading-[1.15]">
              Delicious Food,{' '}
              <span className="text-[#B8782A] italic font-serif">Moments</span>
            </h1>

            <p className="text-base sm:text-lg text-neutral-700 max-w-xl mx-auto lg:mx-0 leading-relaxed font-normal">
              Immerse yourself in regal hospitality with our 100-dish curated Pakistani menu.
              Slow-cooked in pure desi ghee, charcoal-smoked on live embers, and crafted with
              century-old royal recipes.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onBookTable}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-semibold uppercase tracking-wider text-white bg-[#B8782A] hover:bg-[#9c631e] rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0"
              >
                <Calendar size={17} />
                <span>Book a Table</span>
              </button>

              <button
                onClick={onExploreMenu}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-semibold uppercase tracking-wider text-neutral-900 bg-white hover:bg-neutral-50 rounded-full border border-[#B8782A]/40 shadow-sm hover:shadow transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0"
              >
                <Utensils size={17} className="text-[#B8782A]" />
                <span>Explore Menu (100 Dishes)</span>
              </button>
            </div>

            {/* Mini Trust Highlights */}
            <div className="pt-6 grid grid-cols-3 gap-4 border-t border-neutral-300/60 max-w-lg mx-auto lg:mx-0">
              <div className="flex flex-col items-center lg:items-start">
                <div className="flex items-center gap-1 text-[#B8782A]">
                  <Star size={16} className="fill-current" />
                  <span className="font-bold text-neutral-900 text-sm">4.9 / 5</span>
                </div>
                <span className="text-xs text-neutral-500 mt-0.5">10k+ Happy Guests</span>
              </div>

              <div className="flex flex-col items-center lg:items-start">
                <div className="flex items-center gap-1 text-[#B8782A]">
                  <Flame size={16} />
                  <span className="font-bold text-neutral-900 text-sm">Pure Ghee</span>
                </div>
                <span className="text-xs text-neutral-500 mt-0.5">Authentic Shinwari</span>
              </div>

              <div className="flex flex-col items-center lg:items-start">
                <div className="flex items-center gap-1 text-[#B8782A]">
                  <Award size={16} />
                  <span className="font-bold text-neutral-900 text-sm">100 Dishes</span>
                </div>
                <span className="text-xs text-neutral-500 mt-0.5">10 Categories</span>
              </div>
            </div>
          </div>

          {/* Right Column: Big Plate Image with Carousel & Floating Badges */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center relative">
            {/* Glowing Golden Ring Background */}
            <div className="relative w-full max-w-[420px] sm:max-w-[480px] aspect-square flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-2 border-dashed border-[#B8782A]/40 animate-[spin_60s_linear_infinite]"></div>
              <div className="absolute inset-4 rounded-full bg-gradient-to-tr from-[#B8782A]/20 via-[#B8782A]/5 to-transparent blur-xl"></div>

              {/* The Big Plate Container */}
              <div className="relative w-[85%] h-[85%] rounded-full overflow-hidden shadow-2xl border-4 border-white/90 group">
                <img
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover transition-all duration-700 ease-out group-hover:scale-105"
                />

                {/* Overlay Gradient on Image */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex flex-col justify-end p-6 text-white text-center sm:text-left">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-300 bg-amber-900/60 backdrop-blur-sm self-center sm:self-start px-2.5 py-0.5 rounded-full mb-1">
                    {slide.tag}
                  </span>
                  <h3 className="font-serif text-lg sm:text-xl font-bold leading-snug">
                    {slide.title}
                  </h3>
                  <p className="text-xs text-neutral-200 mt-0.5 hidden sm:block line-clamp-1">
                    {slide.subtitle}
                  </p>
                </div>
              </div>

              {/* Floating Highlight Badge 1 */}
              <div className="absolute -top-2 right-4 bg-white/95 backdrop-blur shadow-lg rounded-2xl py-2 px-3.5 border border-[#B8782A]/20 flex items-center gap-2 animate-bounce">
                <CrownIcon size={18} color="#B8782A" />
                <div>
                  <p className="text-[10px] text-neutral-500 font-medium">Fine Dining Standard</p>
                  <p className="text-xs font-bold text-neutral-900">100% Royal Quality</p>
                </div>
              </div>

              {/* Floating Highlight Badge 2 */}
              <div className="absolute -bottom-3 left-4 bg-white/95 backdrop-blur shadow-lg rounded-2xl py-2.5 px-4 border border-[#B8782A]/20 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-[#B8782A]/10 flex items-center justify-center text-[#B8782A] font-bold text-sm">
                  Rs
                </div>
                <div>
                  <p className="text-[10px] text-neutral-500 font-medium">Delivery Guarantee</p>
                  <p className="text-xs font-bold text-neutral-900">Free Above Rs 2000</p>
                </div>
              </div>
            </div>

            {/* Slider Navigation Dots */}
            <div className="flex items-center gap-2.5 mt-8">
              {HERO_SLIDES.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => setCurrentSlide(idx)}
                  className={`transition-all duration-300 rounded-full ${
                    currentSlide === idx
                      ? 'w-8 h-2.5 bg-[#B8782A]'
                      : 'w-2.5 h-2.5 bg-neutral-300 hover:bg-neutral-400'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
