import React, { useState } from 'react';
import { Mail, Send, CheckCircle, Sparkles } from 'lucide-react';
import { useRoyalStore } from '../../hooks/useRoyalStore';

export const NewsletterSection: React.FC = () => {
  const { store } = useRoyalStore();
  const [email, setEmail] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = store.subscribeNewsletter(email);
    setStatusMessage(result.message);
    setIsSuccess(result.success);
    if (result.success) {
      setEmail('');
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  return (
    <section className="py-16 bg-[#1f1912] text-white relative overflow-hidden border-t border-amber-900/30">
      <div className="absolute -left-12 -bottom-12 w-64 h-64 rounded-full bg-[#B8782A]/10 blur-3xl pointer-events-none"></div>
      <div className="absolute -right-12 -top-12 w-64 h-64 rounded-full bg-[#B8782A]/10 blur-3xl pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#B8782A]/20 border border-[#B8782A]/40 text-amber-300 text-xs uppercase tracking-widest font-semibold mb-4">
          <Sparkles size={13} />
          <span>The Royal Gazette</span>
        </div>

        <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight">
          Subscribe for Secret Off-Menu Deals & Privileges
        </h2>

        <p className="text-sm sm:text-base text-neutral-300 max-w-xl mx-auto mt-3 font-light leading-relaxed">
          Be the first to receive invitation-only seasonal tasting menus, chef masterclasses,
          and exclusive weekly promo discount codes.
        </p>

        <form onSubmit={handleSubmit} className="mt-8 max-w-md mx-auto">
          <div className="flex flex-col sm:flex-row items-center gap-2 bg-white/10 p-1.5 rounded-2xl sm:rounded-full border border-amber-900/50 backdrop-blur-sm">
            <div className="relative w-full flex items-center">
              <Mail size={18} className="text-neutral-400 absolute left-4" />
              <input
                type="email"
                required
                placeholder="Enter your email address..."
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-transparent text-white placeholder-neutral-400 text-sm focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full sm:w-auto shrink-0 px-6 py-3 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white text-xs uppercase tracking-wider font-bold flex items-center justify-center gap-2 transition-colors shadow"
            >
              <span>Subscribe</span>
              <Send size={13} />
            </button>
          </div>

          {statusMessage && (
            <div
              className={`mt-4 text-xs font-medium flex items-center justify-center gap-1.5 ${
                isSuccess ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {isSuccess && <CheckCircle size={14} />}
              <span>{statusMessage}</span>
            </div>
          )}
        </form>
      </div>
    </section>
  );
};
