import React, { useState } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { MenuItem } from '../../types';
import { Star, Plus, Check } from 'lucide-react';

interface ChefRecommendationsProps {
  onSelectDish: (dish: MenuItem) => void;
}

export const ChefRecommendations: React.FC<ChefRecommendationsProps> = ({ onSelectDish }) => {
  const { menuItems, store } = useRoyalStore();
  const [activeTab, setActiveTab] = useState<'all' | 'pakistani' | 'bbq' | 'steaks' | 'special'>('all');
  const [addedItemIds, setAddedItemIds] = useState<{ [id: string]: boolean }>({});

  // Filter 8 cards based on tab
  const getFilteredItems = (): MenuItem[] => {
    let pool = menuItems.filter((i) => i.is_available);
    if (activeTab === 'pakistani') {
      pool = pool.filter((i) => i.category_id === 'pakistani-desi');
    } else if (activeTab === 'bbq') {
      pool = pool.filter((i) => i.category_id === 'bbq');
    } else if (activeTab === 'steaks') {
      pool = pool.filter((i) => i.category_id === 'steaks-continental');
    } else if (activeTab === 'special') {
      pool = pool.filter((i) => i.badge && (i.badge.includes('Special') || i.badge.includes('Royal') || i.badge.includes('Signature')));
    }
    // Pick top 8 items
    return pool.slice(0, 8);
  };

  const filteredItems = getFilteredItems();

  const handleAddToCart = (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    store.addToCart(item);
    setAddedItemIds((prev) => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedItemIds((prev) => ({ ...prev, [item.id]: false }));
    }, 1500);
  };

  return (
    <section className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Handcrafted Perfection"
          title="Chef's Royal Recommendations"
          description="Personally curated by our master culinary artisans. The finest cuts, richest gravies, and exquisite flavors."
        />

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
          {[
            { id: 'all', label: 'All Highlights' },
            { id: 'pakistani', label: 'Pakistani / Desi' },
            { id: 'bbq', label: 'BBQ Charcoal' },
            { id: 'steaks', label: 'Steaks & Gourmet' },
            { id: 'special', label: "Chef's Specials" }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-5 py-2 text-xs sm:text-sm font-semibold rounded-full transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-[#B8782A] text-white shadow-md'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* 8 Recommendation Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {filteredItems.map((item) => {
            const isAdded = addedItemIds[item.id];
            const hasVariants = item.size_variants && item.size_variants.length > 0;
            const displayPrice = item.price;
            const hasDiscount = item.discount_percent && item.discount_percent > 0;
            const discountedPrice = hasDiscount
              ? Math.round(displayPrice * (1 - item.discount_percent! / 100))
              : displayPrice;

            return (
              <div
                key={item.id}
                onClick={() => onSelectDish(item)}
                className="group bg-white rounded-2xl overflow-hidden border border-neutral-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer hover:-translate-y-1.5"
              >
                <div>
                  {/* Image container */}
                  <div className="relative h-48 w-full overflow-hidden bg-neutral-100">
                    <img
                      src={item.image_url}
                      alt={item.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />

                    {/* Badge */}
                    {item.badge && (
                      <span className="absolute top-3 left-3 bg-[#B8782A] text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-sm">
                        {item.badge}
                      </span>
                    )}

                    {/* Veg / Non-Veg Indicator */}
                    <span
                      className={`absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded border flex items-center gap-1 bg-white/95 shadow-sm ${
                        item.veg_nonveg === 'veg'
                          ? 'border-emerald-600 text-emerald-700'
                          : 'border-rose-600 text-rose-700'
                      }`}
                    >
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          item.veg_nonveg === 'veg' ? 'bg-emerald-600' : 'bg-rose-600'
                        }`}
                      ></span>
                      {item.veg_nonveg === 'veg' ? 'VEG' : 'NON-VEG'}
                    </span>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 sm:p-5">
                    {/* Rating */}
                    <div className="flex items-center gap-1 text-[#B8782A] text-xs font-semibold mb-1.5">
                      <Star size={14} className="fill-current text-[#B8782A]" />
                      <span>{item.rating.toFixed(1)}</span>
                      <span className="text-neutral-400 font-normal">/ 5.0</span>
                    </div>

                    <h3 className="font-serif text-lg font-bold text-neutral-900 group-hover:text-[#B8782A] transition-colors leading-snug line-clamp-1">
                      {item.name}
                    </h3>

                    <p className="text-xs sm:text-sm text-neutral-600 mt-1.5 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Footer with Price and Action */}
                <div className="p-4 sm:p-5 pt-0 border-t border-neutral-100 mt-2 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider block font-medium">
                      {hasVariants ? 'Starting From' : 'Price'}
                    </span>
                    <div className="flex items-baseline gap-1.5">
                      {hasDiscount ? (
                        <>
                          <span className="font-bold text-base sm:text-lg text-[#B8782A]">
                            Rs {discountedPrice.toLocaleString()}
                          </span>
                          <span className="text-xs text-neutral-400 line-through">
                            Rs {displayPrice.toLocaleString()}
                          </span>
                        </>
                      ) : (
                        <span className="font-bold text-base sm:text-lg text-neutral-900">
                          Rs {displayPrice.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={(e) => handleAddToCart(e, item)}
                    className={`inline-flex items-center justify-center p-2.5 rounded-full transition-all duration-300 shadow-sm ${
                      isAdded
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#B8782A] text-white hover:bg-[#9c631e] hover:scale-105 active:scale-95'
                    }`}
                    title={hasVariants ? 'Select Variant & Add' : 'Add to Cart'}
                    aria-label="Add to cart"
                  >
                    {isAdded ? <Check size={16} /> : <Plus size={16} />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
