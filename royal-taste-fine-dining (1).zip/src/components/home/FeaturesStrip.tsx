import React from 'react';
import { Leaf, Award, Armchair, Truck, Crown } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';

const FEATURES = [
  {
    icon: Leaf,
    title: 'Fresh Ingredients',
    description: 'Farm-fresh organic vegetables, daily butchered tender halal cuts, and authentic desi ghee.'
  },
  {
    icon: Award,
    title: 'Expert Chefs',
    description: 'Master Ustads preserving generations of Mughlai, Shinwari, and authentic royal spice recipes.'
  },
  {
    icon: Armchair,
    title: 'Cozy Ambience',
    description: 'Regal dining halls, private family lounges, and soothing cultural hospitality.'
  },
  {
    icon: Truck,
    title: 'Fast Delivery',
    description: 'Piping hot delivery in insulated carriers with live GPS tracking directly to your door.'
  }
];

export const FeaturesStrip: React.FC = () => {
  return (
    <section className="py-12 bg-white border-y border-neutral-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {FEATURES.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="flex items-start gap-4 p-4 rounded-2xl hover:bg-[#FAF5EC]/70 transition-colors"
              >
                <div className="h-12 w-12 rounded-2xl bg-[#B8782A]/10 border border-[#B8782A]/20 flex items-center justify-center text-[#B8782A] shrink-0">
                  <Icon size={24} />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-neutral-900 leading-snug">
                    {feat.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-600 mt-1 leading-relaxed">
                    {feat.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
