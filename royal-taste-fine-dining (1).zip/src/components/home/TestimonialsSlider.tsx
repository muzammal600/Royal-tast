import React, { useState } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';

export const TestimonialsSlider: React.FC = () => {
  const { testimonials } = useRoyalStore();
  const [currentIndex, setCurrentIndex] = useState(0);

  const prev = () => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : testimonials.length - 1));
  };

  const next = () => {
    setCurrentIndex((prev) => (prev < testimonials.length - 1 ? prev + 1 : 0));
  };

  const current = testimonials[currentIndex] || testimonials[0];

  return (
    <section className="py-16 sm:py-24 bg-[#FAF5EC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Honored Words"
          title="Guest Experiences"
          description="Read genuine impressions from connoisseurs who have savored the Royal Taste standard."
        />

        <div className="max-w-3xl mx-auto relative">
          <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-xl border border-amber-900/10 text-center relative">
            <Quote
              size={48}
              className="text-[#B8782A]/15 absolute top-6 left-6 pointer-events-none"
            />

            {/* Stars */}
            <div className="flex items-center justify-center gap-1 text-[#B8782A] mb-6">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={20}
                  className={i < current.rating ? 'fill-current text-[#B8782A]' : 'text-neutral-300'}
                />
              ))}
            </div>

            {/* Comment */}
            <p className="font-serif text-lg sm:text-xl lg:text-2xl text-neutral-800 leading-relaxed italic">
              "{current.comment}"
            </p>

            {/* Author */}
            <div className="mt-8 flex flex-col items-center">
              {current.avatar_url && (
                <img
                  src={current.avatar_url}
                  alt={current.name}
                  className="w-14 h-14 rounded-full object-cover border-2 border-[#B8782A] shadow-md mb-2"
                />
              )}
              <h4 className="font-serif font-bold text-lg text-neutral-900">
                {current.name}
              </h4>
              <span className="text-xs uppercase tracking-wider text-[#B8782A] font-semibold mt-0.5">
                {current.role} • {current.date}
              </span>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prev}
              className="p-3 rounded-full bg-white text-neutral-800 hover:text-[#B8782A] shadow border border-neutral-200 hover:border-[#B8782A] transition-all"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={20} />
            </button>

            <div className="flex items-center gap-2">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    currentIndex === idx ? 'w-6 bg-[#B8782A]' : 'w-2 bg-neutral-300'
                  }`}
                  aria-label={`Go to review ${idx + 1}`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="p-3 rounded-full bg-white text-neutral-800 hover:text-[#B8782A] shadow border border-neutral-200 hover:border-[#B8782A] transition-all"
              aria-label="Next testimonial"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
