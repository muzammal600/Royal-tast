import React, { useState, useEffect } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { WeeklySpecial } from '../../types';
import { Calendar, Tag, ArrowRight, Sparkles, Check, ShoppingBag } from 'lucide-react';

interface WeeklySpecialsSectionProps {
  onOrderSpecial: (special: WeeklySpecial) => void;
}

const DAYS_OF_WEEK: ('Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday')[] = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday'
];

export const WeeklySpecialsSection: React.FC<WeeklySpecialsSectionProps> = ({ onOrderSpecial }) => {
  const { weeklySpecials } = useRoyalStore();
  const [selectedDay, setSelectedDay] = useState<string>('Monday');
  const [todayDayName, setTodayDayName] = useState<string>('Monday');

  useEffect(() => {
    // Determine current day of week
    const dayIndex = new Date().getDay(); // 0 is Sunday, 1 is Monday...
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const currentName = dayNames[dayIndex];
    setTodayDayName(currentName);
    setSelectedDay(currentName);
  }, []);

  const activeSpecial =
    weeklySpecials.find((s) => s.day === selectedDay) || weeklySpecials[0];

  return (
    <section id="specials" className="py-16 sm:py-24 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Daily Culinary Celebrations"
          title="This Week's Specials"
          description="Every day brings a unique royal feast at an exclusive celebratory price. Discover what our chefs have prepared for today."
        />

        {/* Monday to Sunday Tabs (Today is auto-highlighted) */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-4 gap-2 sm:gap-3 scrollbar-none mb-10">
          {DAYS_OF_WEEK.map((day) => {
            const isToday = day === todayDayName;
            const isSelected = day === selectedDay;

            return (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`relative px-4 sm:px-6 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-300 shrink-0 flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#B8782A] text-white shadow-md'
                    : 'bg-[#FAF5EC] text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                <span>{day}</span>
                {isToday && (
                  <span
                    className={`text-[9px] uppercase tracking-wider font-extrabold px-1.5 py-0.5 rounded-full ${
                      isSelected ? 'bg-amber-100 text-[#B8782A]' : 'bg-[#B8782A] text-white'
                    }`}
                  >
                    Today
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Featured Special Card for Selected Day */}
        {activeSpecial && (
          <div className="bg-[#FAF5EC] rounded-3xl overflow-hidden border border-amber-900/10 shadow-lg p-6 sm:p-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Image side */}
              <div className="lg:col-span-6 relative h-64 sm:h-80 lg:h-96 rounded-2xl overflow-hidden shadow-md">
                <img
                  src={activeSpecial.image_url}
                  alt={activeSpecial.dish_name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-[#B8782A] text-white text-xs font-bold px-3 py-1 rounded-full shadow">
                  {activeSpecial.day}'s Royal Special
                </div>
                {activeSpecial.badge && (
                  <div className="absolute bottom-4 left-4 bg-black/75 backdrop-blur text-amber-300 text-xs font-semibold px-3 py-1 rounded-full border border-amber-500/40">
                    {activeSpecial.badge}
                  </div>
                )}
              </div>

              {/* Details side */}
              <div className="lg:col-span-6 space-y-5 text-center lg:text-left">
                <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#B8782A]">
                  <Sparkles size={15} />
                  <span>{activeSpecial.title}</span>
                </div>

                <h3 className="font-serif text-3xl sm:text-4xl font-bold text-neutral-900 leading-tight">
                  {activeSpecial.dish_name}
                </h3>

                <p className="text-neutral-600 text-sm sm:text-base leading-relaxed">
                  {activeSpecial.description}
                </p>

                {/* Pricing comparison */}
                <div className="pt-2 flex items-baseline justify-center lg:justify-start gap-4">
                  <div>
                    <span className="text-[11px] text-neutral-500 block uppercase font-medium">
                      Special Daily Price
                    </span>
                    <span className="font-serif text-3xl sm:text-4xl font-black text-[#B8782A]">
                      Rs {activeSpecial.special_price.toLocaleString()}
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-neutral-400 block uppercase font-medium">
                      Original Value
                    </span>
                    <span className="text-lg text-neutral-400 line-through">
                      Rs {activeSpecial.original_price.toLocaleString()}
                    </span>
                  </div>

                  <div className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-md self-end mb-1">
                    Save Rs {(activeSpecial.original_price - activeSpecial.special_price).toLocaleString()}
                  </div>
                </div>

                {/* Action button */}
                <div className="pt-4">
                  <button
                    onClick={() => onOrderSpecial(activeSpecial)}
                    className="inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-sm font-bold uppercase tracking-wider text-white bg-[#B8782A] hover:bg-[#9c631e] rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
                  >
                    <ShoppingBag size={17} />
                    <span>Order Special Dish</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
