import React from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Award, ChefHat, Sparkles } from 'lucide-react';

export const MeetChefsSection: React.FC = () => {
  const { chefs } = useRoyalStore();

  return (
    <section className="py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Masters of the Royal Kitchen"
          title="Meet Our Master Chefs"
          description="Decades of seasoned mastery, passion for authentic Subcontinental flavors, and obsessive devotion to excellence."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {chefs.map((chef) => (
            <div
              key={chef.id}
              className="group bg-[#FAF5EC] rounded-3xl overflow-hidden border border-amber-900/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1.5"
            >
              <div>
                {/* Chef Photo */}
                <div className="relative h-72 w-full overflow-hidden bg-neutral-200">
                  <img
                    src={chef.image_url}
                    alt={chef.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute top-4 left-4 bg-[#B8782A] text-white text-[11px] font-bold px-3 py-1 rounded-full shadow">
                    {chef.experience}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#B8782A] block">
                    {chef.role}
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-neutral-900 mt-1">
                    {chef.name}
                  </h3>

                  <div className="mt-3 inline-flex items-center gap-1.5 text-xs text-amber-900/80 bg-amber-100/60 px-2.5 py-1 rounded-md border border-amber-200/50">
                    <Sparkles size={13} className="text-[#B8782A]" />
                    <span className="font-medium">{chef.specialty}</span>
                  </div>

                  <p className="text-xs sm:text-sm text-neutral-600 mt-4 leading-relaxed">
                    {chef.bio}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 border-t border-amber-900/10 mt-2 flex items-center justify-between text-xs text-neutral-500 font-medium">
                <span>Royal Culinary Guild</span>
                <span className="text-[#B8782A] font-semibold">Lahore Chapter</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
