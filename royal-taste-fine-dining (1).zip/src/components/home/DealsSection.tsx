import React, { useState } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Deal } from '../../types';
import { Check, Users, Sparkles, Plus, ShoppingBag } from 'lucide-react';

interface DealsSectionProps {
  onAddDealToCart: (deal: Deal) => void;
}

export const DealsSection: React.FC<DealsSectionProps> = ({ onAddDealToCart }) => {
  const { deals } = useRoyalStore();
  const [addedDealId, setAddedDealId] = useState<string | null>(null);

  const handleAdd = (deal: Deal) => {
    onAddDealToCart(deal);
    setAddedDealId(deal.id);
    setTimeout(() => setAddedDealId(null), 1600);
  };

  return (
    <section id="deals" className="py-16 sm:py-24 bg-[#FAF5EC] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Unbeatable Feasts"
          title="Royal Deals & Combos"
          description="Curated culinary packages designed for family feasts, student gatherings, and executive mid-day lunches."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {deals.map((deal) => {
            const isAdded = addedDealId === deal.id;
            const savings = deal.original_value ? deal.original_value - deal.price : null;

            return (
              <div
                key={deal.id}
                className="bg-white rounded-3xl overflow-hidden border border-amber-900/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1.5"
              >
                <div>
                  {/* Deal Image */}
                  <div className="relative h-52 w-full overflow-hidden">
                    <img
                      src={deal.image_url}
                      alt={deal.title}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                    {deal.badge && (
                      <span className="absolute top-3 left-3 bg-[#B8782A] text-white text-xs font-bold px-3 py-1 rounded-full shadow">
                        {deal.badge}
                      </span>
                    )}
                    <span className="absolute bottom-3 right-3 bg-black/75 backdrop-blur text-white text-xs px-2.5 py-1 rounded-full flex items-center gap-1.5">
                      <Users size={13} className="text-[#B8782A]" />
                      <span>{deal.serves}</span>
                    </span>
                  </div>

                  {/* Body Content */}
                  <div className="p-6">
                    <span className="text-xs uppercase tracking-widest text-[#B8782A] font-semibold">
                      {deal.subtitle}
                    </span>
                    <h3 className="font-serif text-2xl font-bold text-neutral-900 mt-1">
                      {deal.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-neutral-600 mt-2">
                      {deal.description}
                    </p>

                    {/* Items Included Checklist */}
                    <div className="mt-5 space-y-2.5 border-t border-neutral-100 pt-4">
                      <p className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                        Package Includes:
                      </p>
                      {deal.items.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-700">
                          <Check size={16} className="text-[#B8782A] shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Pricing & Add to Cart button */}
                <div className="p-6 pt-0 border-t border-neutral-100 mt-4 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-neutral-400 uppercase tracking-wider block font-medium">
                      Combo Price
                    </span>
                    <div className="flex items-baseline gap-2">
                      <span className="font-serif text-2xl font-black text-[#B8782A]">
                        Rs {deal.price.toLocaleString()}
                      </span>
                      {deal.original_value && (
                        <span className="text-xs text-neutral-400 line-through">
                          Rs {deal.original_value.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleAdd(deal)}
                    className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 shadow-sm ${
                      isAdded
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#B8782A] text-white hover:bg-[#9c631e] hover:shadow'
                    }`}
                  >
                    {isAdded ? (
                      <>
                        <Check size={15} />
                        <span>Added</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag size={15} />
                        <span>Add Deal</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
