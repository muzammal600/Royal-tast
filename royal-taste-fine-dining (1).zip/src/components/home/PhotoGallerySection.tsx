import React, { useState } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { GalleryItem } from '../../types';
import { Maximize2, X, ChevronLeft, ChevronRight } from 'lucide-react';

export const PhotoGallerySection: React.FC = () => {
  const { gallery } = useRoyalStore();
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setSelectedPhotoIndex(index);
  };

  const closeLightbox = () => {
    setSelectedPhotoIndex(null);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedPhotoIndex !== null) {
      setSelectedPhotoIndex((prev) => (prev! > 0 ? prev! - 1 : gallery.length - 1));
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedPhotoIndex !== null) {
      setSelectedPhotoIndex((prev) => (prev! < gallery.length - 1 ? prev! + 1 : 0));
    }
  };

  return (
    <section className="py-16 sm:py-24 bg-[#FAF5EC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Visual Feast"
          title="The Royal Gallery"
          description="Take a visual tour through our ambient dining chambers, live charcoal pits, and culinary presentations."
        />

        {/* 8 Images Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {gallery.slice(0, 8).map((item, idx) => (
            <div
              key={item.id}
              onClick={() => openLightbox(idx)}
              className="group relative h-56 sm:h-64 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer border border-amber-900/10"
            >
              <img
                src={item.image_url}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                loading="lazy"
              />

              {/* Overlay with Category & Title */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4 text-white">
                <span className="text-[10px] uppercase tracking-widest text-[#B8782A] font-bold">
                  {item.category}
                </span>
                <h4 className="font-serif text-sm sm:text-base font-bold leading-snug">
                  {item.title}
                </h4>
                <div className="mt-2 inline-flex items-center gap-1 text-[11px] text-amber-200">
                  <Maximize2 size={12} />
                  <span>Click to expand</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Lightbox Modal */}
      {selectedPhotoIndex !== null && (
        <div
          onClick={closeLightbox}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-fadeIn"
        >
          {/* Close button */}
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-50"
            aria-label="Close image viewer"
          >
            <X size={24} />
          </button>

          {/* Previous image */}
          <button
            onClick={handlePrev}
            className="absolute left-4 sm:left-8 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-50"
            aria-label="Previous image"
          >
            <ChevronLeft size={28} />
          </button>

          {/* Current Image Container */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl max-h-[85vh] flex flex-col items-center"
          >
            <img
              src={gallery[selectedPhotoIndex].image_url}
              alt={gallery[selectedPhotoIndex].title}
              className="max-h-[75vh] w-auto max-w-full rounded-2xl shadow-2xl object-contain border border-white/10"
            />
            <div className="mt-4 text-center text-white">
              <span className="text-xs uppercase tracking-widest text-[#B8782A] font-semibold">
                {gallery[selectedPhotoIndex].category} • {selectedPhotoIndex + 1} of {gallery.length}
              </span>
              <h3 className="font-serif text-xl sm:text-2xl font-bold mt-1">
                {gallery[selectedPhotoIndex].title}
              </h3>
            </div>
          </div>

          {/* Next image */}
          <button
            onClick={handleNext}
            className="absolute right-4 sm:right-8 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-50"
            aria-label="Next image"
          >
            <ChevronRight size={28} />
          </button>
        </div>
      )}
    </section>
  );
};
