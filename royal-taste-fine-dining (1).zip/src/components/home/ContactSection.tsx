import React, { useState } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Phone, MessageCircle, MapPin, Clock, Navigation, Send, User, Mail, CheckCircle, Sparkles, ArrowRight, Zap } from 'lucide-react';
import { analyzeInquiryKeywords } from '../../utils/aiResponseTemplates';
import { CrownIcon } from '../common/CrownIcon';

export const ContactSection: React.FC = () => {
  const { siteSettings, store } = useRoyalStore();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);

  const cleanWhatsAppNumber = siteSettings.whatsapp.replace(/\D/g, '');

  // Live keyword analysis on the typed inquiry message
  const inquiryAnalysis = analyzeInquiryKeywords(formData.message || formData.subject || 'Table and food inquiry', formData.name);

  const getWhatsAppInquiryUrl = () => {
    const textToSend = `Assalam-o-Alaikum Royal Taste Management! 👑\nI am contacting you from the website inquiry form.\nName: ${formData.name || 'Guest'}\nPhone: ${formData.phone || 'Not provided'}\nEmail: ${formData.email || 'Not provided'}\nTopic: ${formData.subject || inquiryAnalysis.matchedCategory}\n\nMessage: "${formData.message.trim() || 'Could you please assist me with dining and delivery?'}"`;
    return `https://wa.me/${cleanWhatsAppNumber}?text=${encodeURIComponent(textToSend)}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    try {
      const res = await store.submitMessage(formData);
      if (res.success) {
        setSent(true);
        setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
        setTimeout(() => setSent(false), 5000);
      }
    } finally {
      setSending(false);
    }
  };

  const getDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${siteSettings.lat},${siteSettings.lng}`;

  return (
    <section id="contact" className="py-16 sm:py-24 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Location & Inquiries"
          title="Visit Royal Taste"
          description="Nestled in the prestigious culinary heart of MM Alam Road, Gulberg, Lahore. We look forward to hosting you."
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Manager Info, Address, Hours & Interactive Map */}
          <div className="lg:col-span-7 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Address card */}
              <div className="bg-[#FAF5EC] p-5 rounded-2xl border border-amber-900/10">
                <div className="flex items-center gap-2.5 text-[#B8782A] font-semibold text-xs uppercase tracking-wider mb-2">
                  <MapPin size={16} />
                  <span>Restaurant Address</span>
                </div>
                <p className="text-sm font-medium text-neutral-800 leading-snug">
                  {siteSettings.address}
                </p>
                <div className="mt-3">
                  <a
                    href={getDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#B8782A] hover:text-[#9c631e] uppercase tracking-wider"
                  >
                    <Navigation size={13} />
                    <span>Get Directions</span>
                  </a>
                </div>
              </div>

              {/* Operating Hours card */}
              <div className="bg-[#FAF5EC] p-5 rounded-2xl border border-amber-900/10">
                <div className="flex items-center gap-2.5 text-[#B8782A] font-semibold text-xs uppercase tracking-wider mb-2">
                  <Clock size={16} />
                  <span>Dining & Delivery Hours</span>
                </div>
                <p className="text-sm font-medium text-neutral-800 leading-snug">
                  {siteSettings.hours}
                </p>
                <p className="text-xs text-neutral-500 mt-2">
                  Valet parking available for all guests.
                </p>
              </div>

              {/* General Manager card */}
              <div className="bg-[#FAF5EC] p-5 rounded-2xl border border-amber-900/10 sm:col-span-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#B8782A]">
                      General Manager In-Charge
                    </span>
                    <h4 className="font-serif text-lg font-bold text-neutral-900 mt-0.5">
                      {siteSettings.manager_name}
                    </h4>
                    <p className="text-xs text-neutral-600 mt-1">
                      Direct contact for corporate bookings, banquets, and customized catering.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <a
                      href={`tel:${siteSettings.manager_number.replace(/\s+/g, '')}`}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-neutral-200 text-xs font-semibold text-neutral-800 hover:border-[#B8782A] hover:text-[#B8782A] transition-colors"
                    >
                      <Phone size={14} className="text-[#B8782A]" />
                      <span>{siteSettings.manager_number}</span>
                    </a>

                    <a
                      href={`https://wa.me/${cleanWhatsAppNumber}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#25D366] text-white text-xs font-semibold hover:bg-[#20ba59] transition-colors shadow-sm"
                    >
                      <MessageCircle size={14} />
                      <span>WhatsApp Manager</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Embedded Live Google Map */}
            <div className="relative rounded-2xl overflow-hidden border border-neutral-200 shadow-md h-72 sm:h-80 bg-neutral-100">
              <iframe
                title="Royal Taste Location Map"
                src={siteSettings.google_maps_embed_url}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>

              <div className="absolute bottom-3 right-3">
                <a
                  href={getDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-neutral-900/90 text-white text-xs font-semibold hover:bg-neutral-900 shadow-lg backdrop-blur"
                >
                  <Navigation size={14} className="text-[#B8782A]" />
                  <span>Get Directions on Google Maps</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Send Inquiry Form */}
          <div className="lg:col-span-5 bg-[#FAF5EC] rounded-3xl p-6 sm:p-8 border border-amber-900/10 shadow-lg">
            <h3 className="font-serif text-2xl font-bold text-neutral-900 mb-1">
              Send an Inquiry
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 mb-6">
              Our hospitality team will respond to your message promptly.
            </p>

            {sent ? (
              <div className="p-6 text-center space-y-3 bg-white rounded-2xl border border-emerald-200">
                <CheckCircle size={36} className="text-emerald-500 mx-auto" />
                <h4 className="font-serif text-lg font-bold text-neutral-900">
                  Message Sent Successfully
                </h4>
                <p className="text-xs text-neutral-600">
                  Thank you for reaching out. Manager Muhammad Rizwan will be in touch with you shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Asad Rauf"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+92 300..."
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="name@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-1.5">
                    Subject
                  </label>
                  <input
                    type="text"
                    placeholder="Catering, Private Event, Feedback..."
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-1.5">
                    Your Message *
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="How may our royal staff assist you today? (e.g. Table for 6 tonight, DHA delivery, or banquet catering...)"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  ></textarea>
                </div>

                {/* Live AI Keyword Intent Pill & Direct WhatsApp Launcher */}
                {formData.message.trim().length > 3 && (
                  <div className="p-3 bg-amber-50/80 rounded-2xl border border-amber-200/80 space-y-2 animate-fadeIn">
                    <div className="flex items-center justify-between gap-2 text-[11px]">
                      <div className="flex items-center gap-1.5">
                        <Sparkles size={13} className="text-[#B8782A]" />
                        <span className="font-bold text-neutral-700">Detected Topic:</span>
                        <span className="px-2 py-0.5 rounded-full bg-[#B8782A] text-white text-[10px] font-bold">
                          {inquiryAnalysis.matchedCategory}
                        </span>
                      </div>
                      <span className="text-[10px] text-neutral-500 font-mono">
                        AI Formatted
                      </span>
                    </div>

                    <a
                      href={getWhatsAppInquiryUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition-all"
                    >
                      <MessageCircle size={15} className="fill-current" />
                      <span>Send Instantly via WhatsApp to Manager</span>
                      <ArrowRight size={13} />
                    </a>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={sending}
                  className="w-full py-3.5 px-6 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white text-xs uppercase tracking-wider font-bold transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Send size={14} />
                  <span>{sending ? 'Sending...' : 'Transmit Message (Email & Database)'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
