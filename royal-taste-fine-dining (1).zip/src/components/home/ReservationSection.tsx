import React, { useState } from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Calendar, Clock, Users, Phone, User, MessageSquare, CheckCircle, Mail } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';

export const ReservationSection: React.FC = () => {
  const { store, siteSettings } = useRoyalStore();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    time: '20:00',
    guests: 4,
    special_request: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmedBookingId, setConfirmedBookingId] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.date) {
      setFormError('Please fill out your name, phone number, and reservation date.');
      return;
    }
    setFormError(null);

    setIsSubmitting(true);
    try {
      const res = await store.makeReservation(formData);
      if (res.success) {
        setConfirmedBookingId(res.bookingId);
        setFormData({
          name: '',
          phone: '',
          email: '',
          date: '',
          time: '20:00',
          guests: 4,
          special_request: ''
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Get tomorrow's date formatted as minimum selectable date
  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <section id="reservation" className="py-16 sm:py-24 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Exclusive Dining Experience"
          title="Reserve Your Royal Table"
          description="Whether an intimate anniversary dinner or a celebratory family feast, let us prepare an unforgettable reception for you."
        />

        <div className="max-w-4xl mx-auto bg-[#FAF5EC] rounded-3xl overflow-hidden border border-amber-900/15 shadow-xl p-8 sm:p-12 relative">
          {confirmedBookingId ? (
            <div className="text-center py-12 space-y-4">
              <div className="h-16 w-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle size={36} />
              </div>
              <CrownIcon size={24} color="#B8782A" className="mx-auto" />
              <h3 className="font-serif text-3xl font-bold text-neutral-900">
                Reservation Confirmed!
              </h3>
              <p className="text-sm sm:text-base text-neutral-600 max-w-md mx-auto">
                Thank you for choosing Royal Taste. Your booking reference number is{' '}
                <strong className="text-[#B8782A] font-mono text-lg">{confirmedBookingId}</strong>.
                Our reservation manager has received your booking.
              </p>
              <div className="pt-4">
                <button
                  onClick={() => setConfirmedBookingId(null)}
                  className="px-6 py-2.5 rounded-full bg-[#B8782A] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#9c631e] transition-colors"
                >
                  Make Another Reservation
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
                  {formError}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Tariq Mehmood"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                    />
                  </div>
                </div>

                {/* Phone Number */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                    Phone Number (WhatsApp) *
                  </label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                    <input
                      type="tel"
                      required
                      placeholder="+92 300 1234567"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                    />
                  </div>
                </div>

                {/* Email Address */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                    Email Address (Optional)
                  </label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                    <input
                      type="email"
                      placeholder="tariq@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                    />
                  </div>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                    Reservation Date *
                  </label>
                  <div className="relative">
                    <Calendar size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                    <input
                      type="date"
                      required
                      min={todayStr}
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                    />
                  </div>
                </div>

                {/* Time */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                    Dining Time *
                  </label>
                  <div className="relative">
                    <Clock size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                    <select
                      value={formData.time}
                      onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                    >
                      <option value="12:30">12:30 PM (Lunch)</option>
                      <option value="13:30">01:30 PM (Lunch)</option>
                      <option value="14:30">02:30 PM (Lunch)</option>
                      <option value="19:00">07:00 PM (Dinner)</option>
                      <option value="20:00">08:00 PM (Dinner)</option>
                      <option value="21:00">09:00 PM (Dinner)</option>
                      <option value="22:00">10:00 PM (Dinner)</option>
                      <option value="23:00">11:00 PM (Late Night)</option>
                    </select>
                  </div>
                </div>

                {/* Number of Guests */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                    Number of Guests *
                  </label>
                  <div className="relative">
                    <Users size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                    <select
                      value={formData.guests}
                      onChange={(e) => setFormData({ ...formData, guests: Number(e.target.value) })}
                      className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                    >
                      <option value="1">1 Person</option>
                      <option value="2">2 Persons (Couple Table)</option>
                      <option value="4">4 Persons (Family Table)</option>
                      <option value="6">6 Persons (Large Family)</option>
                      <option value="8">8 Persons (Party)</option>
                      <option value="12">10 - 15 Persons (Private Lounge)</option>
                      <option value="20">20+ Persons (Corporate Hall)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Special Requests */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-700 mb-2">
                  Special Requests (Optional)
                </label>
                <div className="relative">
                  <MessageSquare size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                  <textarea
                    rows={3}
                    placeholder="e.g. Birthday anniversary decor, quiet corner table, high chair for infant..."
                    value={formData.special_request}
                    onChange={(e) => setFormData({ ...formData, special_request: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 bg-white border border-neutral-200 rounded-xl text-sm focus:outline-none focus:border-[#B8782A] focus:ring-1 focus:ring-[#B8782A]"
                  />
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2 text-center">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-10 py-4 text-sm font-bold uppercase tracking-wider text-white bg-[#B8782A] hover:bg-[#9c631e] rounded-full shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50"
                >
                  <CrownIcon size={16} color="#FFFFFF" />
                  <span>{isSubmitting ? 'Confirming Reservation...' : 'Confirm Table Reservation'}</span>
                </button>
                <p className="text-xs text-neutral-500 mt-2">
                  Immediate confirmation. For urgent reservations call{' '}
                  <a href={`tel:${siteSettings.phone.replace(/\s+/g, '')}`} className="text-[#B8782A] font-medium underline">
                    {siteSettings.phone}
                  </a>
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
