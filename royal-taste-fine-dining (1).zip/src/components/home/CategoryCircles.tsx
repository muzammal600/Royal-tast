import React from 'react';
import { SectionHeader } from '../common/SectionHeader';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { ChevronRight } from 'lucide-react';

interface CategoryCirclesProps {
  onSelectCategory: (categoryId: string) => void;
}

export const CategoryCircles: React.FC<CategoryCirclesProps> = ({ onSelectCategory }) => {
  const { categories, menuItems } = useRoyalStore();

  return (
    <section className="py-16 sm:py-20 bg-[#FAF5EC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          subtitle="Explore By Royal Category"
          title="Culinary Delights"
          description="From fragrant Pakistani curries and live charcoal grills to stone-baked pizzas and royal desserts."
        />

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6 sm:gap-8">
          {categories.map((cat) => {
            const count = menuItems.filter((i) => i.category_id === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className="group flex flex-col items-center text-center focus:outline-none transition-transform duration-300 hover:-translate-y-1"
              >
                {/* Round Image Container */}
                <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full overflow-hidden p-1 border-2 border-[#B8782A]/30 group-hover:border-[#B8782A] transition-all duration-300 shadow-md group-hover:shadow-xl bg-white">
                  <div className="w-full h-full rounded-full overflow-hidden">
                    <img
                      src={cat.image_url}
                      alt={cat.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-115"
                      loading="lazy"
                    />
                  </div>
                  {/* Subtle hover overlay */}
                  <div className="absolute inset-0 rounded-full bg-black/15 group-hover:bg-transparent transition-colors"></div>
                </div>

                {/* Category Title & Dish Count */}
                <span className="font-serif font-bold text-sm sm:text-base text-neutral-900 group-hover:text-[#B8782A] transition-colors mt-3">
                  {cat.name}
                </span>
                <span className="text-xs text-neutral-500 font-medium mt-0.5">
                  {count > 0 ? `${count} items` : 'Explore'}
                </span>
              </button>
            );
          })}
        </div>

        {/* View All Button */}
        <div className="mt-12 text-center">
          <button
            onClick={() => onSelectCategory('all')}
            className="inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-[#B8782A] hover:text-[#9c631e] group"
          >
            <span>View All 100 Menu Dishes</span>
            <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </section>
  );
};
