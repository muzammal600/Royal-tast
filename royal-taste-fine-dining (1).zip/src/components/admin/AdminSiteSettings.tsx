import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Save, CheckCircle, Lock, Shield, Phone, MessageSquare, MapPin, DollarSign, Globe } from 'lucide-react';

export const AdminSiteSettings: React.FC = () => {
  const { siteSettings, store } = useRoyalStore();

  const [settings, setSettings] = useState({ ...siteSettings });
  const [saved, setSaved] = useState(false);

  // Password change state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdMsg, setPwdMsg] = useState<{ text: string; success: boolean } | null>(null);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    store.updateSiteSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setPwdMsg({ text: 'New passwords do not match.', success: false });
      return;
    }
    if (newPassword.length < 6) {
      setPwdMsg({ text: 'New password must be at least 6 characters.', success: false });
      return;
    }

    const res = await store.changeAdminPassword(oldPassword, newPassword);
    setPwdMsg({ text: res.message, success: res.success });
    if (res.success) {
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPwdMsg(null), 4000);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="font-serif text-2xl font-bold text-neutral-900">
            Restaurant Brand & Operational Settings
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Changes made here update the live website immediately (WhatsApp link, phone, hours, delivery minimum).
          </p>
        </div>

        {saved && (
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
            <CheckCircle size={14} />
            <span>Settings Saved!</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: General Settings Form */}
        <div className="lg:col-span-8 bg-white p-6 sm:p-8 rounded-3xl border border-neutral-200 shadow-sm">
          <form onSubmit={handleSaveSettings} className="space-y-5">
            <h3 className="font-serif text-lg font-bold text-neutral-900 border-b pb-2">
              Restaurant Coordinates & Contacts
            </h3>

            {/* Restaurant Name & Tagline */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Brand Name
                </label>
                <input
                  type="text"
                  required
                  value={settings.restaurant_name}
                  onChange={(e) => setSettings({ ...settings, restaurant_name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Tagline
                </label>
                <input
                  type="text"
                  value={settings.tagline}
                  onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>
            </div>

            {/* Official Phone & WhatsApp Number */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Landline / Front Desk Phone
                </label>
                <input
                  type="text"
                  required
                  value={settings.phone}
                  onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  WhatsApp Contact (Floating Button Target)
                </label>
                <input
                  type="text"
                  required
                  value={settings.whatsapp}
                  onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
                <span className="text-[10px] text-neutral-400 mt-1 block">
                  Updates floating WhatsApp button wa.me link directly.
                </span>
              </div>
            </div>

            {/* Manager Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  General Manager Name
                </label>
                <input
                  type="text"
                  required
                  value={settings.manager_name}
                  onChange={(e) => setSettings({ ...settings, manager_name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Manager Direct Phone
                </label>
                <input
                  type="text"
                  required
                  value={settings.manager_number}
                  onChange={(e) => setSettings({ ...settings, manager_number: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>
            </div>

            {/* Email & Address */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={settings.email}
                  onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Free Delivery Minimum Amount (Rs)
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  value={settings.free_delivery_minimum}
                  onChange={(e) => setSettings({ ...settings, free_delivery_minimum: Number(e.target.value) })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Full Physical Address
              </label>
              <input
                type="text"
                required
                value={settings.address}
                onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
              />
            </div>

            {/* Hours & Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Operating Hours
                </label>
                <input
                  type="text"
                  required
                  value={settings.hours}
                  onChange={(e) => setSettings({ ...settings, hours: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Top Announcement Strip Text
                </label>
                <input
                  type="text"
                  value={settings.announcement_banner}
                  onChange={(e) => setSettings({ ...settings, announcement_banner: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>
            </div>

            {/* Map Latitude & Longitude */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Google Map Latitude (lat)
                </label>
                <input
                  type="number"
                  step="0.0001"
                  required
                  value={settings.lat}
                  onChange={(e) => setSettings({ ...settings, lat: Number(e.target.value) })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Google Map Longitude (lng)
                </label>
                <input
                  type="number"
                  step="0.0001"
                  required
                  value={settings.lng}
                  onChange={(e) => setSettings({ ...settings, lng: Number(e.target.value) })}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-sm"
                />
              </div>
            </div>

            {/* Social Links */}
            <div className="pt-2 border-t space-y-3">
              <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-500">
                Social Media Handles
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Facebook URL"
                  value={settings.social_facebook}
                  onChange={(e) => setSettings({ ...settings, social_facebook: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border rounded-xl text-xs"
                />
                <input
                  type="text"
                  placeholder="Instagram URL"
                  value={settings.social_instagram}
                  onChange={(e) => setSettings({ ...settings, social_instagram: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border rounded-xl text-xs"
                />
              </div>
            </div>

            <div className="pt-4 border-t flex justify-end">
              <button
                type="submit"
                className="px-8 py-3 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white text-xs font-bold uppercase tracking-wider shadow flex items-center gap-2"
              >
                <Save size={15} />
                <span>Save Site Settings</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right: Security & Password Management */}
        <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm space-y-5">
          <div className="flex items-center gap-2 text-neutral-900 border-b pb-3">
            <Lock size={18} className="text-[#B8782A]" />
            <h3 className="font-serif text-lg font-bold">Admin Security</h3>
          </div>

          <div className="p-3 bg-neutral-50 rounded-xl text-xs text-neutral-600 leading-relaxed space-y-1">
            <p><strong>Session Auto-Logout:</strong> Enabled.</p>
            <p>Admin session automatically terminates after 15 minutes of inactivity for security.</p>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-3 pt-2">
            <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-700">
              Change Administrator Password
            </h4>

            {pwdMsg && (
              <p className={`text-xs ${pwdMsg.success ? 'text-emerald-600' : 'text-rose-600'}`}>
                {pwdMsg.text}
              </p>
            )}

            <div>
              <label className="block text-[11px] font-bold text-neutral-600 mb-1">
                Current Password
              </label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full px-3 py-2 border rounded-xl text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-600 mb-1">
                New Password (min 6 chars)
              </label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3 py-2 border rounded-xl text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-600 mb-1">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3 py-2 border rounded-xl text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-full bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold uppercase tracking-wider"
            >
              Update Password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
