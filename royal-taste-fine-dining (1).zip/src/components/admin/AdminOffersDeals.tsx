import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Deal, Offer } from '../../types';
import { Tag, Plus, Edit2, Trash2, Power, Users, Check, X, Shield } from 'lucide-react';

export const AdminOffersDeals: React.FC = () => {
  const { deals, offers, store } = useRoyalStore();

  // Create Deal state
  const [isDealModalOpen, setIsDealModalOpen] = useState(false);
  const [dealTitle, setDealTitle] = useState('');
  const [dealSubtitle, setDealSubtitle] = useState('');
  const [dealPrice, setDealPrice] = useState<number>(999);
  const [dealOriginal, setDealOriginal] = useState<number>(1400);
  const [dealDescription, setDealDescription] = useState('');
  const [dealItemsStr, setDealItemsStr] = useState('1x Chicken Karahi\n2x Naan\n1x Soft Drink');
  const [dealServes, setDealServes] = useState('Serves 2 - 3 persons');
  const [dealImageUrl, setDealImageUrl] = useState('https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80');
  const [dealBadge, setDealBadge] = useState('New Combo');

  const handleToggleDeal = (deal: Deal) => {
    store.updateDeal(deal.id, { is_active: !deal.is_active });
  };

  const handleDeleteDeal = (id: string, title: string) => {
    store.deleteDeal(id);
  };

  const handleToggleOffer = (offer: Offer) => {
    store.updateOffer(offer.id, { is_active: !offer.is_active });
  };

  const handleSaveDeal = (e: React.FormEvent) => {
    e.preventDefault();
    const items = dealItemsStr
      .split('\n')
      .map((i) => i.trim())
      .filter(Boolean);

    store.addDeal({
      title: dealTitle.trim(),
      subtitle: dealSubtitle.trim(),
      price: Number(dealPrice),
      original_value: Number(dealOriginal),
      description: dealDescription.trim(),
      items,
      serves: dealServes.trim(),
      image_url: dealImageUrl.trim(),
      badge: dealBadge.trim() || undefined,
      is_active: true
    });

    setIsDealModalOpen(false);
  };

  return (
    <div className="space-y-8">
      {/* SECTION 1: Active Promotional Offers */}
      <div className="space-y-4">
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
          <div>
            <h2 className="font-serif text-xl font-bold text-neutral-900">
              Promotional Coupons & Category Discounts
            </h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              Pause or activate promo rules (FIRST20 coupon, category discounts).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className={`p-5 rounded-2xl border transition-all ${
                offer.is_active
                  ? 'bg-white border-neutral-200 shadow-sm'
                  : 'bg-neutral-50 border-neutral-200 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  {offer.code && (
                    <span className="font-mono text-xs font-bold text-[#B8782A] bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      CODE: {offer.code}
                    </span>
                  )}
                  <h3 className="font-serif text-lg font-bold text-neutral-900 mt-1.5">
                    {offer.title}
                  </h3>
                </div>

                <button
                  onClick={() => handleToggleOffer(offer)}
                  className={`p-2 rounded-xl transition-colors ${
                    offer.is_active
                      ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                      : 'bg-neutral-200 text-neutral-600 hover:bg-neutral-300'
                  }`}
                  title={offer.is_active ? 'Pause Offer' : 'Activate Offer'}
                >
                  <Power size={15} />
                </button>
              </div>

              <p className="text-xs text-neutral-600 mt-2">
                {offer.description}
              </p>

              <div className="pt-3 border-t border-neutral-100 mt-3 flex items-center justify-between text-xs">
                <span className="font-bold text-[#B8782A]">
                  -{offer.discount_value}% {offer.discount_type === 'percent' ? 'Discount' : 'Off'}
                </span>
                <span className="text-neutral-400 capitalize">
                  Applies to {offer.applies_to.replace('_', ' ')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: Combo Deals (Family, Student, Lunch Deal) */}
      <div className="space-y-4">
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-serif text-xl font-bold text-neutral-900">
              Royal Combo Deals Management
            </h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              Create and manage Family Deal, Student Deal, Lunch Deal combos.
            </p>
          </div>

          <button
            onClick={() => setIsDealModalOpen(true)}
            className="px-4 py-2 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e] flex items-center gap-1.5 shadow"
          >
            <Plus size={14} />
            <span>Create New Combo Deal</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {deals.map((deal) => (
            <div
              key={deal.id}
              className={`bg-white rounded-2xl overflow-hidden border border-neutral-200 shadow-sm flex flex-col justify-between ${
                !deal.is_active ? 'opacity-60' : ''
              }`}
            >
              <div>
                <div className="relative h-44 w-full bg-neutral-100">
                  <img
                    src={deal.image_url}
                    alt={deal.title}
                    className="w-full h-full object-cover"
                  />
                  {deal.badge && (
                    <span className="absolute top-2 left-2 bg-[#B8782A] text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow">
                      {deal.badge}
                    </span>
                  )}
                  <span className="absolute bottom-2 right-2 bg-black/75 text-white text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                    <Users size={12} className="text-[#B8782A]" />
                    <span>{deal.serves}</span>
                  </span>
                </div>

                <div className="p-4 space-y-2">
                  <span className="text-[11px] text-[#B8782A] font-semibold uppercase tracking-wider block">
                    {deal.subtitle}
                  </span>
                  <h3 className="font-serif text-lg font-bold text-neutral-900">
                    {deal.title}
                  </h3>
                  <p className="text-xs text-neutral-600 line-clamp-2">
                    {deal.description}
                  </p>

                  <div className="space-y-1 text-xs text-neutral-700 pt-2 border-t border-neutral-100">
                    <p className="font-bold text-[10px] uppercase text-neutral-400">Included Dishes:</p>
                    {deal.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-1.5 text-[11px]">
                        <Check size={12} className="text-[#B8782A]" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 flex items-baseline gap-2">
                    <span className="font-serif text-lg font-bold text-[#B8782A]">
                      Rs {deal.price.toLocaleString()}
                    </span>
                    {deal.original_value && (
                      <span className="text-xs text-neutral-400 line-through">
                        Rs {deal.original_value.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-4 pt-0 border-t border-neutral-100 mt-2 flex items-center justify-between">
                <button
                  onClick={() => handleToggleDeal(deal)}
                  className={`py-1 px-3 rounded-lg text-xs font-bold transition-colors ${
                    deal.is_active ? 'bg-amber-100 text-amber-900' : 'bg-neutral-200 text-neutral-700'
                  }`}
                >
                  {deal.is_active ? 'Active' : 'Paused'}
                </button>

                <button
                  onClick={() => handleDeleteDeal(deal.id, deal.title)}
                  className="p-1.5 text-neutral-400 hover:text-rose-600 transition-colors"
                  title="Delete Deal"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CREATE DEAL MODAL */}
      {isDealModalOpen && (
        <div
          onClick={() => setIsDealModalOpen(false)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-4 shadow-2xl border border-neutral-200"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-serif text-xl font-bold text-neutral-900">
                Create Royal Combo Deal
              </h3>
              <button
                onClick={() => setIsDealModalOpen(false)}
                className="p-1 rounded-full hover:bg-neutral-100"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveDeal} className="space-y-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Deal Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. VIP Platter Deal"
                  value={dealTitle}
                  onChange={(e) => setDealTitle(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Subtitle
                </label>
                <input
                  type="text"
                  placeholder="e.g. Grand Celebration Box"
                  value={dealSubtitle}
                  onChange={(e) => setDealSubtitle(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Combo Price (Rs) *
                  </label>
                  <input
                    type="number"
                    required
                    value={dealPrice}
                    onChange={(e) => setDealPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Original Value (Rs)
                  </label>
                  <input
                    type="number"
                    value={dealOriginal}
                    onChange={(e) => setDealOriginal(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Serves (e.g. Serves 3 - 4 persons)
                </label>
                <input
                  type="text"
                  value={dealServes}
                  onChange={(e) => setDealServes(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Included Dishes (One item per line)
                </label>
                <textarea
                  rows={3}
                  required
                  value={dealItemsStr}
                  onChange={(e) => setDealItemsStr(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Image URL
                </label>
                <input
                  type="text"
                  required
                  value={dealImageUrl}
                  onChange={(e) => setDealImageUrl(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-xs"
                />
              </div>

              <div className="pt-3 border-t flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsDealModalOpen(false)}
                  className="px-4 py-2 rounded-full border text-xs font-bold uppercase tracking-wider text-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e]"
                >
                  Create Deal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
