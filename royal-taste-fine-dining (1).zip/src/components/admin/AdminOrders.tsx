import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Order, OrderStatus } from '../../types';
import { Search, MapPin, Phone, User, Navigation, Clock, CheckCircle, AlertCircle, Eye, X, MessageCircle } from 'lucide-react';

export const AdminOrders: React.FC = () => {
  const { orders, store } = useRoyalStore();
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const getOrderWhatsAppUrl = (order: Order) => {
    const cleanPhone = order.customer.phone.replace(/\D/g, '');
    const dishList = order.items.map((i) => `${i.quantity}x ${i.item_name}`).join(', ');
    const msg = `Assalam-o-Alaikum ${order.customer.name}! 🛵\nGeneral Manager Muhammad Rizwan here from Royal Taste Fine Dining.\n\nUpdate on Order *${order.order_number}*:\n• Current Status: *${order.status}*\n• Total Amount: *Rs ${order.total_amount.toLocaleString()}*\n• Items: ${dishList}\n• Delivery To: ${order.customer.address}\n\nThank you for choosing Royal Taste! Piping hot and simmered in pure dairy desi ghee.`;
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  };

  const filteredOrders = orders.filter((order) => {
    if (filterStatus !== 'all' && order.status !== filterStatus) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchNum = order.order_number.toLowerCase().includes(q);
      const matchName = order.customer.name.toLowerCase().includes(q);
      const matchPhone = order.customer.phone.toLowerCase().includes(q);
      if (!matchNum && !matchName && !matchPhone) return false;
    }
    return true;
  });

  const handleStatusChange = (orderId: string, status: OrderStatus) => {
    store.updateOrderStatus(orderId, status);
    if (selectedOrder && selectedOrder.id === orderId) {
      setSelectedOrder({ ...selectedOrder, status });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm">
        <div>
          <h2 className="font-serif text-2xl font-bold text-neutral-900">
            Live Order Management
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Total of {orders.length} orders recorded in system.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search */}
          <div className="relative w-full sm:w-64">
            <Search size={15} className="absolute left-3 top-3 text-neutral-400" />
            <input
              type="text"
              placeholder="Search code, name, phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs focus:outline-none focus:border-[#B8782A]"
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full sm:w-auto py-2 px-3 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#B8782A]"
          >
            <option value="all">All Statuses ({orders.length})</option>
            <option value="Pending">Pending ({orders.filter((o) => o.status === 'Pending').length})</option>
            <option value="Preparing">Preparing ({orders.filter((o) => o.status === 'Preparing').length})</option>
            <option value="On the way">On the way ({orders.filter((o) => o.status === 'On the way').length})</option>
            <option value="Delivered">Delivered ({orders.filter((o) => o.status === 'Delivered').length})</option>
            <option value="Cancelled">Cancelled ({orders.filter((o) => o.status === 'Cancelled').length})</option>
          </select>
        </div>
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center text-neutral-500 shadow-sm border border-neutral-200/80">
          <p className="font-serif text-lg font-bold text-neutral-800">No orders match criteria</p>
          <p className="text-xs text-neutral-500 mt-1">
            Try switching filters or clearing your search query.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Card representation (mobile friendly and responsive desktop) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {filteredOrders.map((order) => {
              const hasCoordinates = order.customer.lat && order.customer.lng;

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-3xl p-5 sm:p-6 border border-neutral-200 shadow-sm hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
                >
                  <div>
                    {/* Card Top: Order Code & Status Dropdown */}
                    <div className="flex items-start justify-between gap-3 pb-3 border-b border-neutral-100">
                      <div>
                        <span className="font-mono text-base font-bold text-[#B8782A]">
                          {order.order_number}
                        </span>
                        <p className="text-[11px] text-neutral-400 mt-0.5">
                          {new Date(order.created_at).toLocaleDateString()} at{' '}
                          {new Date(order.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>

                      {/* Status Selector */}
                      <div className="flex items-center gap-2">
                        <select
                          value={order.status}
                          onChange={(e) => handleStatusChange(order.id, e.target.value as OrderStatus)}
                          className={`py-1.5 px-3 rounded-full text-xs font-bold border transition-colors cursor-pointer ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-100 border-emerald-300 text-emerald-800'
                              : order.status === 'Cancelled'
                              ? 'bg-rose-100 border-rose-300 text-rose-800'
                              : order.status === 'On the way'
                              ? 'bg-purple-100 border-purple-300 text-purple-800'
                              : order.status === 'Preparing'
                              ? 'bg-blue-100 border-blue-300 text-blue-800'
                              : 'bg-amber-100 border-amber-300 text-amber-800'
                          }`}
                        >
                          <option value="Pending">Pending</option>
                          <option value="Preparing">Preparing</option>
                          <option value="On the way">On the way</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Customer Info */}
                    <div className="pt-2 text-xs space-y-1 text-neutral-700">
                      <div className="flex items-center gap-2">
                        <User size={13} className="text-[#B8782A] shrink-0" />
                        <span className="font-bold text-neutral-900">{order.customer.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone size={13} className="text-[#B8782A] shrink-0" />
                        <a
                          href={`tel:${order.customer.phone}`}
                          className="hover:underline font-medium text-neutral-800"
                        >
                          {order.customer.phone}
                        </a>
                      </div>
                      <div className="flex items-start gap-2">
                        <MapPin size={13} className="text-[#B8782A] shrink-0 mt-0.5" />
                        <span className="text-neutral-600 line-clamp-2">{order.customer.address}</span>
                      </div>
                      {order.customer.notes && (
                        <p className="text-amber-800 bg-amber-50 p-2 rounded-lg text-[11px] mt-1">
                          Note: "{order.customer.notes}"
                        </p>
                      )}
                    </div>

                    {/* GPS Coordinates Button */}
                    {hasCoordinates && (
                      <div className="pt-2">
                        <a
                          href={`https://www.google.com/maps?q=${order.customer.lat},${order.customer.lng}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold hover:bg-emerald-100 transition-colors"
                        >
                          <Navigation size={12} className="text-emerald-600" />
                          <span>
                            View Customer GPS ({order.customer.lat?.toFixed(4)}, {order.customer.lng?.toFixed(4)})
                          </span>
                        </a>
                      </div>
                    )}

                    {/* Dishes summary */}
                    <div className="mt-3 pt-3 border-t border-neutral-100 text-xs">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                        Dishes Ordered:
                      </span>
                      <div className="space-y-1">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between text-neutral-700">
                            <span>
                              {item.quantity}x {item.item_name} {item.variant_name ? `(${item.variant_name})` : ''}
                            </span>
                            <span className="font-medium">Rs {item.total.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer: Total Amount & Details Modal trigger */}
                  <div className="pt-3 border-t border-neutral-100 flex flex-col gap-2.5">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-neutral-400 uppercase tracking-wider block">
                          Total Amount
                        </span>
                        <span className="font-serif text-lg font-bold text-neutral-900">
                          Rs {order.total_amount.toLocaleString()}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={getOrderWhatsAppUrl(order)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold transition-colors shadow-xs"
                        >
                          <MessageCircle size={13} className="fill-current" />
                          <span>WhatsApp Update</span>
                        </a>

                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-xs font-semibold text-neutral-800 transition-colors"
                        >
                          <Eye size={13} />
                          <span>Invoice</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Full Order Invoice Modal */}
      {selectedOrder && (
        <div
          onClick={() => setSelectedOrder(null)}
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-neutral-200"
          >
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h3 className="font-serif text-xl font-bold text-neutral-900">
                  Order Invoice {selectedOrder.order_number}
                </h3>
                <p className="text-xs text-neutral-500">
                  Status: <strong className="text-[#B8782A]">{selectedOrder.status}</strong>
                </p>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1 rounded-full hover:bg-neutral-100"
              >
                <X size={18} />
              </button>
            </div>

            {/* Customer block */}
            <div className="bg-neutral-50 p-4 rounded-xl text-xs space-y-1">
              <p><strong>Customer:</strong> {selectedOrder.customer.name}</p>
              <p><strong>Phone:</strong> {selectedOrder.customer.phone}</p>
              <p><strong>Address:</strong> {selectedOrder.customer.address}</p>
              {selectedOrder.customer.lat && selectedOrder.customer.lng && (
                <p>
                  <strong>GPS:</strong> {selectedOrder.customer.lat}, {selectedOrder.customer.lng}
                </p>
              )}
            </div>

            {/* Items */}
            <div className="space-y-2 text-xs divide-y divide-neutral-100">
              {selectedOrder.items.map((i, idx) => (
                <div key={idx} className="pt-2 flex justify-between">
                  <span>{i.quantity}x {i.item_name} {i.variant_name ? `(${i.variant_name})` : ''}</span>
                  <span className="font-semibold">Rs {i.total.toLocaleString()}</span>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="border-t pt-3 text-xs space-y-1 text-neutral-600">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>Rs {selectedOrder.subtotal.toLocaleString()}</span>
              </div>
              {selectedOrder.discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Discount:</span>
                  <span>- Rs {selectedOrder.discount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Delivery:</span>
                <span>{selectedOrder.delivery_fee === 0 ? 'FREE' : `Rs ${selectedOrder.delivery_fee}`}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-neutral-900 pt-2 border-t">
                <span>Total Amount:</span>
                <span className="text-[#B8782A]">Rs {selectedOrder.total_amount.toLocaleString()}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
              <a
                href={getOrderWhatsAppUrl(selectedOrder)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto flex-1 py-2.5 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold uppercase tracking-wider text-center flex items-center justify-center gap-1.5 shadow"
              >
                <MessageCircle size={14} className="fill-current" />
                <span>WhatsApp Customer</span>
              </a>

              <button
                onClick={() => setSelectedOrder(null)}
                className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold uppercase tracking-wider"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
