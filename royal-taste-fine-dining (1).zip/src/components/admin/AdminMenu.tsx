import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { MenuItem, SizeVariant, VegNonVeg } from '../../types';
import { Search, Plus, Edit2, Trash2, Check, X, Upload, Star, Eye } from 'lucide-react';

export const AdminMenu: React.FC = () => {
  const { menuItems, categories, store } = useRoyalStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Modal State for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [categoryId, setCategoryId] = useState('pakistani-desi');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<number>(500);
  const [imageUrl, setImageUrl] = useState('');
  const [badge, setBadge] = useState('');
  const [vegNonVeg, setVegNonVeg] = useState<VegNonVeg>('non-veg');
  const [rating, setRating] = useState<number>(4.8);
  const [isAvailable, setIsAvailable] = useState(true);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [hasVariants, setHasVariants] = useState(false);
  const [variants, setVariants] = useState<SizeVariant[]>([
    { name: 'Half', price: 1500 },
    { name: 'Full', price: 2800 }
  ]);

  const openAddModal = () => {
    setEditingItem(null);
    setName('');
    setCategoryId(categories[0]?.id || 'pakistani-desi');
    setDescription('');
    setPrice(650);
    setImageUrl('https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80');
    setBadge("Chef's Special");
    setVegNonVeg('non-veg');
    setRating(4.9);
    setIsAvailable(true);
    setDiscountPercent(0);
    setHasVariants(false);
    setVariants([
      { name: 'Half', price: 1500 },
      { name: 'Full', price: 2800 }
    ]);
    setIsModalOpen(true);
  };

  const openEditModal = (item: MenuItem) => {
    setEditingItem(item);
    setName(item.name);
    setCategoryId(item.category_id);
    setDescription(item.description);
    setPrice(item.price);
    setImageUrl(item.image_url);
    setBadge(item.badge || '');
    setVegNonVeg(item.veg_nonveg);
    setRating(item.rating);
    setIsAvailable(item.is_available);
    setDiscountPercent(item.discount_percent || 0);
    if (item.size_variants && item.size_variants.length > 0) {
      setHasVariants(true);
      setVariants([...item.size_variants]);
    } else {
      setHasVariants(false);
      setVariants([
        { name: 'Small', price: 750 },
        { name: 'Medium', price: 1300 },
        { name: 'Large', price: 1800 }
      ]);
    }
    setIsModalOpen(true);
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const payload = {
      name: name.trim(),
      category_id: categoryId,
      description: description.trim(),
      price: Number(price),
      image_url: imageUrl.trim() || 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80',
      badge: badge.trim() || undefined,
      veg_nonveg: vegNonVeg,
      rating: Number(rating),
      is_available: isAvailable,
      discount_percent: discountPercent > 0 ? Number(discountPercent) : undefined,
      size_variants: hasVariants ? variants : undefined
    };

    if (editingItem) {
      store.updateMenuItem(editingItem.id, payload);
    } else {
      store.addMenuItem(payload);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string, itemName: string) => {
    store.deleteMenuItem(id);
  };

  // Simulate local file photo upload to DataURL
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setImageUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const filteredItems = menuItems.filter((item) => {
    if (selectedCategory !== 'all' && item.category_id !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = item.name.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      if (!matchName && !matchDesc) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm">
        <div>
          <h2 className="font-serif text-2xl font-bold text-neutral-900">
            Menu Dishes Management ({menuItems.length} Dishes)
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Add, edit, adjust prices & variants, or upload photographs in real-time.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={openAddModal}
            className="px-5 py-2.5 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white text-xs font-bold uppercase tracking-wider transition-colors shadow flex items-center gap-1.5"
          >
            <Plus size={15} />
            <span>Add New Dish</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center gap-3 bg-white p-4 rounded-2xl border border-neutral-200 shadow-sm">
        <div className="relative w-full flex-1">
          <Search size={16} className="absolute left-3.5 top-3 text-neutral-400" />
          <input
            type="text"
            placeholder="Search dish name or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs focus:outline-none focus:border-[#B8782A]"
          />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="w-full md:w-auto py-2 px-3 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#B8782A]"
        >
          <option value="all">All Categories ({menuItems.length})</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} ({menuItems.filter((i) => i.category_id === c.id).length})
            </option>
          ))}
        </select>
      </div>

      {/* Dish Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl overflow-hidden border border-neutral-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow"
          >
            <div>
              {/* Image & Quick Badges */}
              <div className="relative h-40 w-full overflow-hidden bg-neutral-100">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
                {item.badge && (
                  <span className="absolute top-2 left-2 bg-[#B8782A] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                    {item.badge}
                  </span>
                )}
                <span
                  className={`absolute top-2 right-2 text-[9px] font-bold px-1.5 py-0.5 rounded ${
                    item.veg_nonveg === 'veg'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {item.veg_nonveg.toUpperCase()}
                </span>
                {!item.is_available && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center text-white font-bold text-xs uppercase tracking-wider">
                    Sold Out / Unavailable
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-neutral-500">
                  <span className="capitalize">{item.category_id.replace('-', ' ')}</span>
                  <div className="flex items-center gap-1 text-[#B8782A] font-bold">
                    <Star size={12} className="fill-current" />
                    <span>{item.rating}</span>
                  </div>
                </div>

                <h3 className="font-serif text-base font-bold text-neutral-900 leading-snug line-clamp-1">
                  {item.name}
                </h3>

                <p className="text-xs text-neutral-600 line-clamp-2">
                  {item.description}
                </p>

                {/* Variants preview */}
                {item.size_variants && item.size_variants.length > 0 && (
                  <div className="flex flex-wrap gap-1 text-[10px] text-neutral-600 pt-1">
                    {item.size_variants.map((v) => (
                      <span key={v.name} className="bg-neutral-100 px-1.5 py-0.5 rounded">
                        {v.name}: Rs {v.price.toLocaleString()}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer with Price and Actions */}
            <div className="p-4 pt-0 border-t border-neutral-100 mt-2 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-neutral-400 uppercase tracking-wider block">
                  Base Price
                </span>
                <span className="font-serif text-base font-bold text-neutral-900">
                  Rs {item.price.toLocaleString()}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => openEditModal(item)}
                  className="p-2 rounded-lg bg-neutral-100 hover:bg-[#B8782A] hover:text-white transition-colors"
                  title="Edit Dish"
                >
                  <Edit2 size={14} />
                </button>
                <button
                  onClick={() => handleDelete(item.id, item.name)}
                  className="p-2 rounded-lg bg-neutral-100 hover:bg-rose-600 hover:text-white transition-colors"
                  title="Delete Dish"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ADD / EDIT DISH MODAL */}
      {isModalOpen && (
        <div
          onClick={() => setIsModalOpen(false)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-5 shadow-2xl border border-neutral-200"
          >
            <div className="flex items-center justify-between border-b pb-4">
              <h3 className="font-serif text-xl font-bold text-neutral-900">
                {editingItem ? `Edit Dish: ${editingItem.name}` : 'Add New Royal Dish'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-full hover:bg-neutral-100 text-neutral-500"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="space-y-4">
              {/* Dish Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Dish Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Royal Shinwari Mutton Karahi"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>

              {/* Category & Diet */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Category *
                  </label>
                  <select
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Dietary Classification *
                  </label>
                  <select
                    value={vegNonVeg}
                    onChange={(e) => setVegNonVeg(e.target.value as VegNonVeg)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  >
                    <option value="non-veg">Non-Vegetarian</option>
                    <option value="veg">Vegetarian</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Gastronomic Description *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Appetizing description of ingredients and preparation method..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>

              {/* Base Price & Discount */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Base Price (Rs) *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Discount % (0 for none)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Rating (1-5)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    max="5"
                    value={rating}
                    onChange={(e) => setRating(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  />
                </div>
              </div>

              {/* Image URL & File Upload */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Food Photograph (URL or Upload)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="https://images.unsplash.com/..."
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-xs focus:outline-none focus:border-[#B8782A]"
                  />
                  <label className="px-3.5 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-semibold cursor-pointer shrink-0 flex items-center gap-1.5">
                    <Upload size={14} />
                    <span>Upload</span>
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Badge & Availability */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Badge (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Chef's Special, Bestseller, Spicy..."
                    value={badge}
                    onChange={(e) => setBadge(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                  />
                </div>

                <div className="flex items-center gap-3 pt-6">
                  <input
                    type="checkbox"
                    id="avail-toggle"
                    checked={isAvailable}
                    onChange={(e) => setIsAvailable(e.target.checked)}
                    className="h-4 w-4 text-[#B8782A] rounded border-neutral-300 focus:ring-[#B8782A]"
                  />
                  <label htmlFor="avail-toggle" className="text-xs font-bold text-neutral-800">
                    Currently Available for Orders
                  </label>
                </div>
              </div>

              {/* Portion / Size Variants toggle */}
              <div className="border-t pt-3">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                    Portion / Size Variants
                  </label>
                  <button
                    type="button"
                    onClick={() => setHasVariants(!hasVariants)}
                    className="text-xs text-[#B8782A] font-semibold hover:underline"
                  >
                    {hasVariants ? 'Disable Variants' : '+ Enable Half/Full, Sizes'}
                  </button>
                </div>

                {hasVariants && (
                  <div className="space-y-2 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                    {variants.map((v, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="Variant (e.g. Half)"
                          value={v.name}
                          onChange={(e) => {
                            const updated = [...variants];
                            updated[idx].name = e.target.value;
                            setVariants(updated);
                          }}
                          className="w-1/2 p-2 bg-white border border-neutral-300 rounded-lg text-xs"
                        />
                        <input
                          type="number"
                          placeholder="Price (Rs)"
                          value={v.price}
                          onChange={(e) => {
                            const updated = [...variants];
                            updated[idx].price = Number(e.target.value);
                            setVariants(updated);
                          }}
                          className="w-1/2 p-2 bg-white border border-neutral-300 rounded-lg text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => setVariants(variants.filter((_, i) => i !== idx))}
                          className="p-1 text-rose-500 hover:text-rose-700"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={() => setVariants([...variants, { name: 'Portion', price: 1000 }])}
                      className="text-xs text-[#B8782A] font-bold"
                    >
                      + Add Variant Line
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2.5 rounded-full border border-neutral-300 text-xs font-bold uppercase tracking-wider text-neutral-700 hover:bg-neutral-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white text-xs font-bold uppercase tracking-wider shadow"
                >
                  {editingItem ? 'Save Changes' : 'Publish Dish'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
