import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { CrownIcon } from '../common/CrownIcon';
import {
  LayoutDashboard,
  ShoppingBag,
  Calendar,
  Utensils,
  Sparkles,
  Tag,
  Users,
  MessageSquare,
  Settings,
  Database,
  LogOut,
  ExternalLink,
  Menu as MenuIcon,
  X,
  ShieldCheck,
  Clock
} from 'lucide-react';
import { AdminDashboard } from './AdminDashboard';
import { AdminOrders } from './AdminOrders';
import { AdminReservations } from './AdminReservations';
import { AdminMenu } from './AdminMenu';
import { AdminWeeklySpecials } from './AdminWeeklySpecials';
import { AdminOffersDeals } from './AdminOffersDeals';
import { AdminChefsGallery } from './AdminChefsGallery';
import { AdminMessagesNewsletter } from './AdminMessagesNewsletter';
import { AdminSiteSettings } from './AdminSiteSettings';
import { AdminSupabaseSettings } from './AdminSupabaseSettings';

interface AdminLayoutProps {
  onBackToSite: () => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ onBackToSite }) => {
  const { currentAdmin, store } = useRoyalStore();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const handleLogout = async () => {
    await store.logoutAdmin();
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Orders & GPS', icon: ShoppingBag },
    { id: 'reservations', label: 'Reservations', icon: Calendar },
    { id: 'menu', label: '100 Dishes Menu', icon: Utensils },
    { id: 'specials', label: 'Weekly Specials', icon: Sparkles },
    { id: 'offers', label: 'Deals & Coupons', icon: Tag },
    { id: 'chefs', label: 'Chefs & Gallery', icon: Users },
    { id: 'messages', label: 'Inquiries & News', icon: MessageSquare },
    { id: 'settings', label: 'Site Settings', icon: Settings },
    { id: 'supabase', label: 'Supabase DB', icon: Database }
  ];

  return (
    <div className="min-h-screen bg-[#f5f0e6] flex flex-col">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 bg-neutral-900 text-white border-b border-amber-900/40 px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between">
          {/* Brand & Mobile Hamburger */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileDrawerOpen(!mobileDrawerOpen)}
              className="lg:hidden p-2 rounded-lg bg-neutral-800 text-white hover:text-[#B8782A]"
              aria-label="Toggle admin navigation"
            >
              {mobileDrawerOpen ? <X size={20} /> : <MenuIcon size={20} />}
            </button>

            <div className="flex items-center gap-2">
              <CrownIcon size={22} color="#B8782A" />
              <div>
                <span className="font-serif text-base sm:text-lg font-black tracking-wider text-white">
                  ROYAL TASTE
                </span>
                <span className="text-[9px] uppercase tracking-widest text-[#B8782A] font-bold ml-1.5 hidden sm:inline">
                  Admin Management
                </span>
              </div>
            </div>
          </div>

          {/* Right Admin Controls */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Auto logout notice */}
            <div className="hidden md:flex items-center gap-1.5 text-[11px] text-amber-200/80 bg-neutral-800/80 px-2.5 py-1 rounded-full border border-neutral-700">
              <Clock size={12} className="text-[#B8782A]" />
              <span>15m Auto-Logout Active</span>
            </div>

            {/* Admin Badge */}
            <div className="flex items-center gap-2 text-xs">
              <ShieldCheck size={16} className="text-[#B8782A]" />
              <div className="hidden sm:block text-right">
                <span className="font-bold text-white block leading-tight">
                  {currentAdmin?.name || 'Administrator'}
                </span>
                <span className="text-[10px] text-neutral-400 block">
                  {currentAdmin?.email}
                </span>
              </div>
            </div>

            {/* View Live Website Button */}
            <button
              onClick={onBackToSite}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold transition-colors"
              title="Return to Customer Website"
            >
              <span>Live Website</span>
              <ExternalLink size={13} className="text-[#B8782A]" />
            </button>

            {/* Logout */}
            <button
              onClick={handleLogout}
              className="p-2 sm:px-3 sm:py-1.5 rounded-full bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Sign Out"
            >
              <LogOut size={14} />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block w-64 bg-white border-r border-neutral-200/90 p-4 space-y-1.5 shrink-0 overflow-y-auto">
          <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-neutral-400">
            Operations & Control
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
                  isActive
                    ? 'bg-[#B8782A] text-white shadow-md'
                    : 'text-neutral-700 hover:bg-neutral-100 hover:text-neutral-900'
                }`}
              >
                <Icon size={16} />
                <span>{item.label}</span>
              </button>
            );
          })}

          <div className="pt-6 mt-6 border-t border-neutral-100 px-3">
            <button
              onClick={onBackToSite}
              className="w-full py-2.5 px-3 rounded-xl border border-neutral-200 text-xs font-bold text-neutral-700 hover:bg-neutral-50 flex items-center justify-center gap-2"
            >
              <span>Back to Storefront</span>
              <ExternalLink size={13} />
            </button>
          </div>
        </aside>

        {/* Mobile Navigation Drawer */}
        {mobileDrawerOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm flex">
            <div className="w-64 bg-white p-5 space-y-2 overflow-y-auto">
              <div className="flex items-center justify-between pb-3 border-b">
                <span className="font-serif font-bold text-base">Admin Menu</span>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-1 rounded-full hover:bg-neutral-100"
                >
                  <X size={18} />
                </button>
              </div>

              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileDrawerOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold text-left ${
                      isActive ? 'bg-[#B8782A] text-white' : 'text-neutral-700 hover:bg-neutral-100'
                    }`}
                  >
                    <Icon size={16} />
                    <span>{item.label}</span>
                  </button>
                );
              })}

              <div className="pt-4 border-t">
                <button
                  onClick={onBackToSite}
                  className="w-full py-2 rounded-xl bg-neutral-900 text-white text-xs font-bold uppercase tracking-wider"
                >
                  Return to Website
                </button>
              </div>
            </div>
            <div className="flex-1" onClick={() => setMobileDrawerOpen(false)}></div>
          </div>
        )}

        {/* Content Pane */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && <AdminDashboard onNavigateTab={setActiveTab} />}
            {activeTab === 'orders' && <AdminOrders />}
            {activeTab === 'reservations' && <AdminReservations />}
            {activeTab === 'menu' && <AdminMenu />}
            {activeTab === 'specials' && <AdminWeeklySpecials />}
            {activeTab === 'offers' && <AdminOffersDeals />}
            {activeTab === 'chefs' && <AdminChefsGallery />}
            {activeTab === 'messages' && <AdminMessagesNewsletter />}
            {activeTab === 'settings' && <AdminSiteSettings />}
            {activeTab === 'supabase' && <AdminSupabaseSettings />}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <div className="lg:hidden sticky bottom-0 z-20 bg-white border-t border-neutral-200 px-2 py-2 flex items-center justify-around text-[10px] font-bold text-neutral-600">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg ${
            activeTab === 'dashboard' ? 'text-[#B8782A]' : 'hover:text-neutral-900'
          }`}
        >
          <LayoutDashboard size={18} />
          <span>Overview</span>
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg ${
            activeTab === 'orders' ? 'text-[#B8782A]' : 'hover:text-neutral-900'
          }`}
        >
          <ShoppingBag size={18} />
          <span>Orders</span>
        </button>
        <button
          onClick={() => setActiveTab('menu')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg ${
            activeTab === 'menu' ? 'text-[#B8782A]' : 'hover:text-neutral-900'
          }`}
        >
          <Utensils size={18} />
          <span>Dishes</span>
        </button>
        <button
          onClick={() => setActiveTab('reservations')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg ${
            activeTab === 'reservations' ? 'text-[#B8782A]' : 'hover:text-neutral-900'
          }`}
        >
          <Calendar size={18} />
          <span>Bookings</span>
        </button>
        <button
          onClick={() => setMobileDrawerOpen(true)}
          className="flex flex-col items-center py-1 px-2 rounded-lg hover:text-neutral-900"
        >
          <MenuIcon size={18} />
          <span>More</span>
        </button>
      </div>
    </div>
  );
};
