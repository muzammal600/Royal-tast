import React, { useState } from 'react';
import { getStoredSupabaseConfig, saveSupabaseConfig, isSupabaseConfigured } from '../../lib/supabase';
import { Database, CheckCircle, AlertTriangle, Copy, Check, Server, RefreshCw } from 'lucide-react';

export const AdminSupabaseSettings: React.FC = () => {
  const currentConfig = getStoredSupabaseConfig();
  const [supabaseUrl, setSupabaseUrl] = useState(currentConfig.url);
  const [supabaseKey, setSupabaseKey] = useState(currentConfig.key);
  const [saved, setSaved] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  const isConnected = isSupabaseConfigured();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveSupabaseConfig(supabaseUrl, supabaseKey);
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      window.location.reload();
    }, 1500);
  };

  const sqlCode = `-- Run this in your Supabase SQL Editor:
-- Creates all tables, RLS policies, and realtime publications

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'admin' CHECK (role IN ('admin', 'manager', 'customer')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  image_url TEXT,
  description TEXT,
  display_order INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS public.menu_items (
  id TEXT PRIMARY KEY,
  category_id TEXT REFERENCES public.categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price NUMERIC NOT NULL,
  size_variants JSONB DEFAULT '[]'::jsonb,
  image_url TEXT NOT NULL,
  badge TEXT,
  veg_nonveg TEXT NOT NULL,
  rating NUMERIC DEFAULT 4.8,
  is_available BOOLEAN DEFAULT TRUE,
  discount_percent INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS public.orders (
  id TEXT PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_address TEXT NOT NULL,
  customer_notes TEXT,
  customer_lat NUMERIC,
  customer_lng NUMERIC,
  location_accuracy NUMERIC,
  items JSONB NOT NULL,
  subtotal NUMERIC NOT NULL,
  discount NUMERIC DEFAULT 0,
  delivery_fee NUMERIC DEFAULT 0,
  total_amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'Pending',
  payment_method TEXT DEFAULT 'Cash on Delivery',
  promo_code TEXT,
  estimated_delivery_time TEXT
);

CREATE TABLE IF NOT EXISTS public.reservations (
  id TEXT PRIMARY KEY,
  booking_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  date DATE NOT NULL,
  time TEXT NOT NULL,
  guests INT NOT NULL,
  special_request TEXT,
  status TEXT DEFAULT 'Confirmed',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public Read Menu" ON public.menu_items FOR SELECT USING (true);
CREATE POLICY "Public Insert Orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Public Read Orders" ON public.orders FOR SELECT USING (true);
CREATE POLICY "Public Insert Reservations" ON public.reservations FOR INSERT WITH CHECK (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.reservations;
`;

  const copySql = () => {
    navigator.clipboard?.writeText(sqlCode);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Status banner */}
      <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Database size={18} className="text-[#B8782A]" />
            <h2 className="font-serif text-2xl font-bold text-neutral-900">
              Supabase Backend Integration
            </h2>
          </div>
          <p className="text-xs text-neutral-500">
            PostgreSQL database, Row Level Security (RLS), Realtime subscriptions, and Supabase Auth.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isConnected ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
              <CheckCircle size={14} />
              <span>Supabase Connected</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
              <AlertTriangle size={14} />
              <span>Standalone Store (Syncs locally)</span>
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Supabase Config Form */}
        <div className="lg:col-span-6 bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm space-y-4">
          <h3 className="font-serif text-lg font-bold text-neutral-900 border-b pb-2">
            API Credentials Configuration
          </h3>
          <p className="text-xs text-neutral-600 leading-relaxed">
            Optionally specify your Supabase Project URL and Anon Public Key below, or set them via{' '}
            <code className="bg-neutral-100 px-1 py-0.5 rounded text-amber-900">VITE_SUPABASE_URL</code> and{' '}
            <code className="bg-neutral-100 px-1 py-0.5 rounded text-amber-900">VITE_SUPABASE_ANON_KEY</code>.
          </p>

          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Supabase Project URL
              </label>
              <input
                type="text"
                placeholder="https://xyzcompany.supabase.co"
                value={supabaseUrl}
                onChange={(e) => setSupabaseUrl(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Supabase Anon Public API Key
              </label>
              <input
                type="password"
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                value={supabaseKey}
                onChange={(e) => setSupabaseKey(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-50 border rounded-xl text-xs font-mono"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e] transition-colors shadow"
              >
                {saved ? 'Reconnecting...' : 'Save & Connect Supabase'}
              </button>

              {saved && (
                <span className="text-xs text-emerald-600 font-semibold">
                  Saved! Refreshing...
                </span>
              )}
            </div>
          </form>
        </div>

        {/* SQL Schema Preview */}
        <div className="lg:col-span-6 bg-[#1f1912] text-amber-100 p-6 rounded-3xl border border-amber-900/30 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-amber-900/50 pb-2">
            <h3 className="font-serif text-lg font-bold text-white">
              Database SQL Migration Script
            </h3>
            <button
              onClick={copySql}
              className="px-3 py-1.5 rounded-lg bg-[#B8782A] text-white text-xs font-bold flex items-center gap-1.5 hover:bg-[#9c631e]"
            >
              {copiedSql ? <Check size={14} /> : <Copy size={14} />}
              <span>{copiedSql ? 'Copied' : 'Copy SQL'}</span>
            </button>
          </div>

          <p className="text-xs text-neutral-300">
            Paste this SQL script in the Supabase SQL editor to create all schema tables, RLS security policies, and realtime broadcast publications.
          </p>

          <pre className="p-3 bg-black/50 rounded-xl text-[11px] font-mono text-neutral-300 overflow-x-auto max-h-56 leading-relaxed">
            {sqlCode}
          </pre>
        </div>
      </div>
    </div>
  );
};
