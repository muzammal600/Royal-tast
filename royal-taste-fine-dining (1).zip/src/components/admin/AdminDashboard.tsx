import React from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { ShoppingBag, Calendar, DollarSign, Utensils, TrendingUp, Clock, MapPin, ArrowRight, CheckCircle } from 'lucide-react';
import { CrownIcon } from '../common/CrownIcon';
import { OrderStatus } from '../../types';

interface AdminDashboardProps {
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateTab }) => {
  const { orders, reservations, menuItems, store } = useRoyalStore();

  // Metrics
  const totalRevenue = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.total_amount, 0);

  const pendingOrders = orders.filter((o) => o.status === 'Pending').length;
  const activeReservations = reservations.filter((r) => r.status === 'Confirmed').length;
  const activeDishes = menuItems.filter((i) => i.is_available).length;

  const recentOrders = orders.slice(0, 5);

  const handleStatusChange = (orderId: string, status: OrderStatus) => {
    store.updateOrderStatus(orderId, status);
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#1f1912] to-[#2e2317] rounded-3xl p-6 sm:p-8 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 shadow-xl border border-amber-900/40">
        <div>
          <div className="flex items-center gap-2 text-[#B8782A] text-xs font-semibold uppercase tracking-wider mb-1">
            <CrownIcon size={16} color="#B8782A" />
            <span>Executive Command Center</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold">
            Royal Taste Live Analytics
          </h2>
          <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-xl">
            Real-time synchronization across 100 menu dishes, live customer dispatch, table bookings, and revenue streams.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => onNavigateTab('menu')}
            className="px-4 py-2.5 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white text-xs font-bold uppercase tracking-wider transition-colors shadow"
          >
            + Add New Dish
          </button>
          <button
            onClick={() => onNavigateTab('orders')}
            className="px-4 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-bold uppercase tracking-wider transition-colors"
          >
            View All Orders
          </button>
        </div>
      </div>

      {/* 4 Key Performance Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">
              Total Revenue
            </span>
            <div className="font-serif text-2xl font-black text-neutral-900 mt-1">
              Rs {totalRevenue.toLocaleString()}
            </div>
            <span className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-0.5">
              <TrendingUp size={12} />
              <span>Cash on Delivery</span>
            </span>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-amber-50 text-[#B8782A] flex items-center justify-center font-bold text-lg">
            Rs
          </div>
        </div>

        {/* Total Orders */}
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">
              Total Orders
            </span>
            <div className="font-serif text-2xl font-black text-neutral-900 mt-1">
              {orders.length}
            </div>
            <span className="text-[11px] text-amber-700 font-medium mt-0.5 block">
              {pendingOrders} Pending Action
            </span>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center">
            <ShoppingBag size={22} />
          </div>
        </div>

        {/* Table Reservations */}
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">
              Confirmed Bookings
            </span>
            <div className="font-serif text-2xl font-black text-neutral-900 mt-1">
              {activeReservations}
            </div>
            <span className="text-[11px] text-neutral-500 font-medium mt-0.5 block">
              {reservations.length} total reservations
            </span>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <Calendar size={22} />
          </div>
        </div>

        {/* Active Dishes */}
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-500">
              Active Dishes
            </span>
            <div className="font-serif text-2xl font-black text-neutral-900 mt-1">
              {activeDishes} / {menuItems.length}
            </div>
            <span className="text-[11px] text-neutral-500 font-medium mt-0.5 block">
              10 Food Categories
            </span>
          </div>
          <div className="h-12 w-12 rounded-2xl bg-purple-50 text-purple-700 flex items-center justify-center">
            <Utensils size={22} />
          </div>
        </div>
      </div>

      {/* Visual Analytics / Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Revenue Breakdown by Category Bar Chart */}
        <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-serif text-lg font-bold text-neutral-900">
                Menu Category Distribution & Demand
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                All 100 items distributed across fine dining categories.
              </p>
            </div>
            <span className="text-xs font-bold text-[#B8782A] bg-amber-50 px-2.5 py-1 rounded-full">
              100 Items Total
            </span>
          </div>

          <div className="space-y-3 pt-2">
            {[
              { cat: 'Pakistani / Desi', count: 20, pct: '100%', color: 'bg-[#B8782A]' },
              { cat: 'Drinks & Beverages', count: 18, pct: '90%', color: 'bg-amber-600' },
              { cat: 'Starters & Soups', count: 10, pct: '50%', color: 'bg-emerald-600' },
              { cat: 'Royal Desserts', count: 10, pct: '50%', color: 'bg-rose-600' },
              { cat: 'Fast Food & Rolls', count: 9, pct: '45%', color: 'bg-blue-600' },
              { cat: 'Live Charcoal BBQ', count: 8, pct: '40%', color: 'bg-orange-600' },
              { cat: 'Chinese Specialties', count: 8, pct: '40%', color: 'bg-red-600' },
              { cat: 'Pizza & Pasta', count: 7, pct: '35%', color: 'bg-indigo-600' },
              { cat: 'Steaks & Continental', count: 6, pct: '30%', color: 'bg-purple-600' },
              { cat: 'Salads & Raita', count: 4, pct: '20%', color: 'bg-teal-600' }
            ].map((bar) => (
              <div key={bar.cat} className="space-y-1">
                <div className="flex justify-between text-xs font-medium text-neutral-700">
                  <span>{bar.cat}</span>
                  <span className="font-bold text-neutral-900">{bar.count} items</span>
                </div>
                <div className="w-full bg-neutral-100 rounded-full h-2 overflow-hidden">
                  <div className={`h-full rounded-full ${bar.color}`} style={{ width: bar.pct }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Operational Status */}
        <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-neutral-200/80 shadow-sm space-y-4">
          <h3 className="font-serif text-lg font-bold text-neutral-900">
            Kitchen Dispatch Status
          </h3>
          <p className="text-xs text-neutral-500">
            Current live status breakdown across all submitted customer orders.
          </p>

          <div className="space-y-3 pt-2">
            {[
              { status: 'Pending', count: orders.filter((o) => o.status === 'Pending').length, bg: 'bg-amber-100 text-amber-800' },
              { status: 'Preparing', count: orders.filter((o) => o.status === 'Preparing').length, bg: 'bg-blue-100 text-blue-800' },
              { status: 'On the way', count: orders.filter((o) => o.status === 'On the way').length, bg: 'bg-purple-100 text-purple-800' },
              { status: 'Delivered', count: orders.filter((o) => o.status === 'Delivered').length, bg: 'bg-emerald-100 text-emerald-800' },
              { status: 'Cancelled', count: orders.filter((o) => o.status === 'Cancelled').length, bg: 'bg-rose-100 text-rose-800' }
            ].map((s) => (
              <div key={s.status} className="flex items-center justify-between p-3 rounded-xl bg-neutral-50">
                <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${s.bg}`}>
                  {s.status}
                </span>
                <span className="font-bold text-sm text-neutral-900">{s.count} orders</span>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-neutral-100">
            <button
              onClick={() => onNavigateTab('orders')}
              className="w-full py-2.5 rounded-xl bg-neutral-900 text-white text-xs font-bold uppercase tracking-wider hover:bg-neutral-800 transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Manage Live Orders</span>
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* Recent Orders List with Live Status Update */}
      <div className="bg-white rounded-3xl border border-neutral-200/80 shadow-sm p-6 sm:p-8 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-serif text-xl font-bold text-neutral-900">
              Recent Customer Orders
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Update status here to trigger live updates on customer's tracking screen.
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-bold uppercase tracking-wider text-[#B8782A] hover:underline"
          >
            View All ({orders.length})
          </button>
        </div>

        {recentOrders.length === 0 ? (
          <div className="py-8 text-center text-xs text-neutral-400">
            No orders placed yet. As guests place orders from the website, they will appear here in real time.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FAF5EC] text-neutral-600 uppercase font-semibold">
                <tr>
                  <th className="p-3 rounded-l-xl">Order Code</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Dishes</th>
                  <th className="p-3">Total (Rs)</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 rounded-r-xl">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 text-neutral-800">
                {recentOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-neutral-50/80 transition-colors">
                    <td className="p-3 font-mono font-bold text-[#B8782A]">
                      {ord.order_number}
                    </td>
                    <td className="p-3">
                      <div className="font-bold text-neutral-900">{ord.customer.name}</div>
                      <div className="text-neutral-500 text-[11px]">{ord.customer.phone}</div>
                    </td>
                    <td className="p-3">
                      <div className="max-w-xs truncate text-neutral-700">
                        {ord.items.map((i) => `${i.quantity}x ${i.item_name}`).join(', ')}
                      </div>
                    </td>
                    <td className="p-3 font-bold text-neutral-900">
                      Rs {ord.total_amount.toLocaleString()}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          ord.status === 'Delivered'
                            ? 'bg-emerald-100 text-emerald-800'
                            : ord.status === 'Cancelled'
                            ? 'bg-rose-100 text-rose-800'
                            : ord.status === 'On the way'
                            ? 'bg-purple-100 text-purple-800'
                            : ord.status === 'Preparing'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {ord.status}
                      </span>
                    </td>
                    <td className="p-3">
                      <select
                        value={ord.status}
                        onChange={(e) => handleStatusChange(ord.id, e.target.value as OrderStatus)}
                        className="py-1 px-2 bg-white border border-neutral-300 rounded-lg text-xs font-semibold focus:outline-none focus:border-[#B8782A]"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Preparing">Preparing</option>
                        <option value="On the way">On the way</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
