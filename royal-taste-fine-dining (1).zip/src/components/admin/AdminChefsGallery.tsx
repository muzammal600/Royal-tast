import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Chef, GalleryItem, Testimonial } from '../../types';
import { Plus, Edit2, Trash2, Upload, Star, X } from 'lucide-react';

export const AdminChefsGallery: React.FC = () => {
  const { chefs, gallery, testimonials, store } = useRoyalStore();
  const [subTab, setSubTab] = useState<'chefs' | 'gallery' | 'testimonials'>('chefs');

  // Chef edit modal
  const [editingChef, setEditingChef] = useState<Chef | null>(null);
  const [chefName, setChefName] = useState('');
  const [chefRole, setChefRole] = useState('');
  const [chefExp, setChefExp] = useState('');
  const [chefSpec, setChefSpec] = useState('');
  const [chefBio, setChefBio] = useState('');
  const [chefImage, setChefImage] = useState('');

  // Gallery add modal
  const [isGalModalOpen, setIsGalModalOpen] = useState(false);
  const [galTitle, setGalTitle] = useState('');
  const [galCategory, setGalCategory] = useState('Ambience');
  const [galImage, setGalImage] = useState('https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80');

  const openChefEdit = (c: Chef) => {
    setEditingChef(c);
    setChefName(c.name);
    setChefRole(c.role);
    setChefExp(c.experience);
    setChefSpec(c.specialty);
    setChefBio(c.bio);
    setChefImage(c.image_url);
  };

  const saveChef = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChef) return;
    store.updateChef(editingChef.id, {
      name: chefName.trim(),
      role: chefRole.trim(),
      experience: chefExp.trim(),
      specialty: chefSpec.trim(),
      bio: chefBio.trim(),
      image_url: chefImage.trim()
    });
    setEditingChef(null);
  };

  const handleAddGalleryItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!galTitle.trim() || !galImage.trim()) return;
    store.addGalleryItem({
      title: galTitle.trim(),
      category: galCategory.trim(),
      image_url: galImage.trim()
    });
    setGalTitle('');
    setIsGalModalOpen(false);
  };

  const handleDeleteGallery = (id: string) => {
    store.deleteGalleryItem(id);
  };

  return (
    <div className="space-y-6">
      {/* Subtab Navigation */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-3">
        <button
          onClick={() => setSubTab('chefs')}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors ${
            subTab === 'chefs' ? 'bg-[#B8782A] text-white shadow' : 'bg-neutral-100 text-neutral-700'
          }`}
        >
          Master Chefs ({chefs.length})
        </button>
        <button
          onClick={() => setSubTab('gallery')}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors ${
            subTab === 'gallery' ? 'bg-[#B8782A] text-white shadow' : 'bg-neutral-100 text-neutral-700'
          }`}
        >
          Photo Gallery ({gallery.length})
        </button>
        <button
          onClick={() => setSubTab('testimonials')}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors ${
            subTab === 'testimonials' ? 'bg-[#B8782A] text-white shadow' : 'bg-neutral-100 text-neutral-700'
          }`}
        >
          Guest Testimonials ({testimonials.length})
        </button>
      </div>

      {/* CHEFS SUBTAB */}
      {subTab === 'chefs' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {chefs.map((chef) => (
            <div
              key={chef.id}
              className="bg-white rounded-2xl overflow-hidden border border-neutral-200 shadow-sm flex flex-col justify-between"
            >
              <div>
                <img
                  src={chef.image_url}
                  alt={chef.name}
                  className="h-56 w-full object-cover"
                />
                <div className="p-5 space-y-1.5">
                  <span className="text-xs text-[#B8782A] font-bold uppercase tracking-wider">
                    {chef.role}
                  </span>
                  <h3 className="font-serif text-xl font-bold text-neutral-900">
                    {chef.name}
                  </h3>
                  <p className="text-xs font-semibold text-neutral-700">{chef.experience}</p>
                  <p className="text-xs text-neutral-500 font-medium bg-neutral-100 p-2 rounded-lg mt-1">
                    Specialty: {chef.specialty}
                  </p>
                  <p className="text-xs text-neutral-600 line-clamp-3 mt-2">{chef.bio}</p>
                </div>
              </div>

              <div className="p-5 pt-0 border-t border-neutral-100 mt-2 flex justify-end">
                <button
                  onClick={() => openChefEdit(chef)}
                  className="py-1.5 px-3 rounded-lg bg-neutral-100 hover:bg-[#B8782A] hover:text-white text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Edit2 size={13} />
                  <span>Edit Profile</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* GALLERY SUBTAB */}
      {subTab === 'gallery' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-neutral-200">
            <span className="text-xs font-bold uppercase text-neutral-600">
              Restaurant Photographic Assets
            </span>
            <button
              onClick={() => setIsGalModalOpen(true)}
              className="px-4 py-2 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow"
            >
              <Plus size={14} />
              <span>Add Gallery Image</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {gallery.map((g) => (
              <div
                key={g.id}
                className="group relative h-48 rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-100"
              >
                <img src={g.image_url} alt={g.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-between text-white text-xs">
                  <div>
                    <span className="text-[10px] text-[#B8782A] font-bold uppercase">{g.category}</span>
                    <p className="font-serif font-bold text-xs mt-0.5">{g.title}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteGallery(g.id)}
                    className="self-end p-2 bg-rose-600 rounded-lg hover:bg-rose-700 text-white"
                    title="Delete Image"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TESTIMONIALS SUBTAB */}
      {subTab === 'testimonials' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div key={t.id} className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm space-y-3">
              <div className="flex items-center gap-1 text-[#B8782A]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={14} className={i < t.rating ? 'fill-current' : 'text-neutral-300'} />
                ))}
              </div>
              <p className="text-xs text-neutral-700 italic">"{t.comment}"</p>
              <div className="pt-2 border-t border-neutral-100 flex items-center gap-2.5">
                {t.avatar_url && (
                  <img src={t.avatar_url} alt={t.name} className="w-8 h-8 rounded-full object-cover" />
                )}
                <div>
                  <h4 className="font-bold text-xs text-neutral-900">{t.name}</h4>
                  <span className="text-[10px] text-neutral-500">{t.role} • {t.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* EDIT CHEF MODAL */}
      {editingChef && (
        <div
          onClick={() => setEditingChef(null)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-4 shadow-2xl border"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-serif text-xl font-bold">Edit Chef {editingChef.name}</h3>
              <button onClick={() => setEditingChef(null)} className="p-1 rounded-full hover:bg-neutral-100">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={saveChef} className="space-y-3">
              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Name</label>
                <input
                  type="text"
                  required
                  value={chefName}
                  onChange={(e) => setChefName(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Designation Role</label>
                <input
                  type="text"
                  required
                  value={chefRole}
                  onChange={(e) => setChefRole(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Culinary Specialty</label>
                <input
                  type="text"
                  required
                  value={chefSpec}
                  onChange={(e) => setChefSpec(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Bio</label>
                <textarea
                  rows={3}
                  required
                  value={chefBio}
                  onChange={(e) => setChefBio(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Photo URL</label>
                <input
                  type="text"
                  required
                  value={chefImage}
                  onChange={(e) => setChefImage(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-xs"
                />
              </div>

              <div className="pt-3 border-t flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingChef(null)}
                  className="px-4 py-2 border rounded-full text-xs font-bold uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#B8782A] text-white rounded-full text-xs font-bold uppercase"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD GALLERY MODAL */}
      {isGalModalOpen && (
        <div
          onClick={() => setIsGalModalOpen(false)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl border"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-serif text-lg font-bold">Add Photo to Royal Gallery</h3>
              <button onClick={() => setIsGalModalOpen(false)} className="p-1 rounded-full hover:bg-neutral-100">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddGalleryItem} className="space-y-3">
              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Caption / Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tandoori Naan Clay Oven"
                  value={galTitle}
                  onChange={(e) => setGalTitle(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Category</label>
                <select
                  value={galCategory}
                  onChange={(e) => setGalCategory(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-sm"
                >
                  <option value="Ambience">Ambience</option>
                  <option value="Food">Food Dish</option>
                  <option value="Kitchen">Live Kitchen</option>
                  <option value="Dessert">Royal Dessert</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-neutral-700 mb-1">Image URL</label>
                <input
                  type="text"
                  required
                  value={galImage}
                  onChange={(e) => setGalImage(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-xs"
                />
              </div>

              <div className="pt-3 border-t flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsGalModalOpen(false)}
                  className="px-4 py-2 border rounded-full text-xs font-bold uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#B8782A] text-white rounded-full text-xs font-bold uppercase"
                >
                  Add to Gallery
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
