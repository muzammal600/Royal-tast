import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Reservation } from '../../types';
import { Calendar, Clock, Users, Phone, User, CheckCircle, XCircle, Search, Mail, MessageCircle } from 'lucide-react';

export const AdminReservations: React.FC = () => {
  const { reservations, store } = useRoyalStore();
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = reservations.filter((res) => {
    if (filterStatus !== 'all' && res.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = res.name.toLowerCase().includes(q);
      const matchPhone = res.phone.toLowerCase().includes(q);
      const matchId = res.booking_id.toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchId) return false;
    }
    return true;
  });

  const handleUpdateStatus = (id: string, status: 'Confirmed' | 'Pending' | 'Cancelled') => {
    store.updateReservationStatus(id, status);
  };

  const getReservationWhatsAppUrl = (res: Reservation) => {
    const cleanPhone = res.phone.replace(/\D/g, '');
    const msg = `Assalam-o-Alaikum ${res.name}! 👑\nThis is Muhammad Rizwan, General Manager at Royal Taste Fine Dining.\n\nYour table reservation is confirmed!\n• Booking ID: *${res.booking_id}*\n• Guests: *${res.guests} Pax*\n• Date: *${res.date}*\n• Time: *${res.time}*\n📍 Address: Plot 42-B, MM Alam Road, Gulberg III, Lahore\n\nComplimentary valet parking has been reserved for your vehicle. We look forward to hosting you!`;
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm">
        <div>
          <h2 className="font-serif text-2xl font-bold text-neutral-900">
            Table Reservations Management
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Total {reservations.length} bookings received.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:w-64">
            <Search size={15} className="absolute left-3 top-3 text-neutral-400" />
            <input
              type="text"
              placeholder="Search guest or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs focus:outline-none focus:border-[#B8782A]"
            />
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full sm:w-auto py-2 px-3 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-semibold focus:outline-none focus:border-[#B8782A]"
          >
            <option value="all">All Bookings ({reservations.length})</option>
            <option value="Confirmed">Confirmed ({reservations.filter((r) => r.status === 'Confirmed').length})</option>
            <option value="Pending">Pending ({reservations.filter((r) => r.status === 'Pending').length})</option>
            <option value="Cancelled">Cancelled ({reservations.filter((r) => r.status === 'Cancelled').length})</option>
          </select>
        </div>
      </div>

      {/* Reservations List */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center text-neutral-500 shadow-sm border border-neutral-200">
          <p className="font-serif text-lg font-bold text-neutral-800">No reservations found</p>
          <p className="text-xs text-neutral-400 mt-1">Guest table bookings will appear here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((res) => (
            <div
              key={res.id}
              className="bg-white rounded-2xl p-5 border border-neutral-200 shadow-sm flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b pb-2.5">
                  <span className="font-mono text-sm font-bold text-[#B8782A]">
                    {res.booking_id}
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      res.status === 'Confirmed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : res.status === 'Cancelled'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {res.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-neutral-700">
                  <div className="flex items-center gap-2">
                    <User size={13} className="text-[#B8782A]" />
                    <span className="font-bold text-neutral-900 text-sm">{res.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={13} className="text-[#B8782A]" />
                    <a href={`tel:${res.phone}`} className="hover:underline">{res.phone}</a>
                  </div>
                  {res.email && (
                    <div className="flex items-center gap-2">
                      <Mail size={13} className="text-[#B8782A]" />
                      <span>{res.email}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Calendar size={13} className="text-[#B8782A]" />
                    <span className="font-medium text-neutral-800">Date: {res.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={13} className="text-[#B8782A]" />
                    <span className="font-medium text-neutral-800">Time: {res.time}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users size={13} className="text-[#B8782A]" />
                    <span className="font-bold text-neutral-900">{res.guests} Guests Table</span>
                  </div>

                  {res.special_request && (
                    <div className="p-2.5 rounded-xl bg-amber-50/80 border border-amber-200/60 mt-2">
                      <span className="font-bold text-[10px] text-amber-900 uppercase tracking-wider block">
                        Special Request:
                      </span>
                      <p className="text-neutral-700 text-xs mt-0.5 italic">
                        "{res.special_request}"
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Status Actions */}
              <div className="pt-3 border-t border-neutral-100 flex flex-col gap-2">
                <a
                  href={getReservationWhatsAppUrl(res)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-1.5 px-3 rounded-lg bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <MessageCircle size={13} className="fill-current" />
                  <span>Send WhatsApp Confirmation</span>
                </a>

                <div className="flex items-center justify-between gap-2">
                  <button
                    onClick={() => handleUpdateStatus(res.id, 'Confirmed')}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs transition-colors flex items-center justify-center gap-1"
                  >
                    <CheckCircle size={13} />
                    <span>Confirm</span>
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(res.id, 'Cancelled')}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 font-bold text-xs transition-colors flex items-center justify-center gap-1"
                  >
                    <XCircle size={13} />
                    <span>Cancel</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
