import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { Mail, MessageSquare, Phone, User, Check, Copy, Sparkles, Send, MessageCircle, X, Users, Clock, MapPin, AlertTriangle } from 'lucide-react';
import { analyzeInquiryKeywords, KeywordAnalysisResult } from '../../utils/aiResponseTemplates';
import { ContactMessage } from '../../types';

export const AdminMessagesNewsletter: React.FC = () => {
  const { messages, newsletterSubscribers, siteSettings } = useRoyalStore();
  const [copiedNotification, setCopiedNotification] = useState(false);

  // AI Smart WhatsApp Reply Modal State
  const [activeMessageForAi, setActiveMessageForAi] = useState<ContactMessage | null>(null);
  const [analysis, setAnalysis] = useState<KeywordAnalysisResult | null>(null);
  const [selectedTemplateKey, setSelectedTemplateKey] = useState<'instantConfirmation' | 'executiveHospitality' | 'followUpAction'>('instantConfirmation');
  const [aiDraft, setAiDraft] = useState('');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [draftCopied, setDraftCopied] = useState(false);

  const handleCopyEmails = () => {
    navigator.clipboard?.writeText(newsletterSubscribers.join(', '));
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2500);
  };

  const openAiReplyModal = (message: ContactMessage) => {
    setActiveMessageForAi(message);
    setDraftCopied(false);

    // Initial keyword analysis
    const result = analyzeInquiryKeywords(message.message, message.name);
    setAnalysis(result);
    setSelectedTemplateKey('instantConfirmation');
    setAiDraft(result.templates.manager.instantConfirmation);
  };

  const handleSwitchTemplate = (key: 'instantConfirmation' | 'executiveHospitality' | 'followUpAction') => {
    setSelectedTemplateKey(key);
    if (analysis) {
      setAiDraft(analysis.templates.manager[key]);
    }
  };

  // Enhance using Gemini 3.8 Flash
  const handleGenerateGeminiReply = async () => {
    if (!activeMessageForAi) return;
    setIsAiGenerating(true);

    try {
      const res = await fetch('/api/ai/draft-response', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: activeMessageForAi.message,
          customerName: activeMessageForAi.name,
          perspective: 'manager',
          templateStyle: selectedTemplateKey
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.draft) {
          setAiDraft(data.draft);
        }
      }
    } catch (err) {
      console.warn('Gemini reply generation fallback:', err);
    } finally {
      setIsAiGenerating(false);
    }
  };

  const handleCopyAiDraft = () => {
    navigator.clipboard?.writeText(aiDraft);
    setDraftCopied(true);
    setTimeout(() => setDraftCopied(false), 2000);
  };

  const getWhatsAppReplyUrl = () => {
    if (!activeMessageForAi) return '';
    const cleanPhone = activeMessageForAi.phone.replace(/\D/g, '');
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(aiDraft)}`;
  };

  return (
    <div className="space-y-8">
      {/* SECTION 1: Customer Contact Messages */}
      <div className="space-y-4">
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <MessageSquare size={18} className="text-[#B8782A]" />
              <h2 className="font-serif text-xl font-bold text-neutral-900">
                Customer Inquiries & WhatsApp AI Responder ({messages.length})
              </h2>
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">
              Automated AI keyword analysis extracts guest count, timings, and crafts immediate Pakistani fine dining replies.
            </p>
          </div>
        </div>

        {messages.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center text-xs text-neutral-400 border border-neutral-200">
            No inquiries received yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {messages.map((m) => {
              const quickAnalysis = analyzeInquiryKeywords(m.message, m.name);

              return (
                <div
                  key={m.id}
                  className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-serif text-base font-bold text-neutral-900">
                          {m.subject || 'General Inquiry'}
                        </h3>
                        <p className="text-[11px] text-neutral-400">
                          {new Date(m.created_at).toLocaleString()}
                        </p>
                      </div>

                      <div className="flex flex-col items-end gap-1 shrink-0">
                        <span className="px-2 py-0.5 rounded-full bg-amber-50 text-[#B8782A] text-[10px] font-bold border border-amber-200">
                          {quickAnalysis.matchedCategory}
                        </span>
                        {quickAnalysis.entities.urgency === 'high' && (
                          <span className="px-1.5 py-0.5 rounded-md bg-rose-100 text-rose-700 text-[9px] font-bold uppercase tracking-wider flex items-center gap-0.5">
                            <AlertTriangle size={9} />
                            <span>Urgent Inquiry</span>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-xs space-y-1 text-neutral-700 bg-neutral-50 p-3 rounded-xl border border-neutral-100">
                      <p><strong>From:</strong> {m.name}</p>
                      <p><strong>Email:</strong> {m.email}</p>
                      <p><strong>Phone:</strong> {m.phone}</p>
                    </div>

                    {/* Detected Context Pills */}
                    {(quickAnalysis.entities.guestCount || quickAnalysis.entities.timeOrDate || quickAnalysis.entities.locationArea) && (
                      <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-neutral-600 bg-amber-50/40 p-2 rounded-lg border border-amber-200/40">
                        <span className="font-semibold text-neutral-500">Detected:</span>
                        {quickAnalysis.entities.guestCount && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 font-bold">
                            {quickAnalysis.entities.guestCount} Guests
                          </span>
                        )}
                        {quickAnalysis.entities.timeOrDate && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 font-bold">
                            {quickAnalysis.entities.timeOrDate}
                          </span>
                        )}
                        {quickAnalysis.entities.locationArea && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 font-bold">
                            {quickAnalysis.entities.locationArea}
                          </span>
                        )}
                      </div>
                    )}

                    <p className="text-xs text-neutral-700 leading-relaxed italic bg-amber-50/50 p-3 rounded-xl border border-amber-100">
                      "{m.message}"
                    </p>
                  </div>

                  <div className="pt-3 border-t border-neutral-100 flex flex-wrap gap-2">
                    <button
                      onClick={() => openAiReplyModal(m)}
                      className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-[#B8782A] text-white text-xs font-bold hover:brightness-105 transition-all flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Sparkles size={13} />
                      <span>AI Smart WhatsApp Reply</span>
                    </button>

                    <a
                      href={`mailto:${m.email}?subject=RE: ${encodeURIComponent(m.subject)}`}
                      className="py-2 px-3 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1"
                    >
                      <Mail size={13} />
                      <span>Email</span>
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* SECTION 2: Newsletter Subscribers */}
      <div className="space-y-4">
        <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
          <div>
            <h2 className="font-serif text-xl font-bold text-neutral-900">
              Royal Gazette Newsletter Subscribers ({newsletterSubscribers.length})
            </h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              Verified email addresses subscribed to seasonal updates and offers.
            </p>
          </div>

          <button
            onClick={handleCopyEmails}
            className="px-4 py-2 rounded-full bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow"
          >
            <Copy size={13} />
            <span>{copiedNotification ? 'Emails Copied!' : 'Export Email List'}</span>
          </button>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm">
          <div className="flex flex-wrap gap-2">
            {newsletterSubscribers.map((email, idx) => (
              <span
                key={idx}
                className="px-3 py-1.5 rounded-full bg-neutral-100 text-neutral-800 text-xs font-mono border border-neutral-200"
              >
                {email}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* AI Smart WhatsApp Reply Modal */}
      {activeMessageForAi && analysis && (
        <div
          onClick={() => setActiveMessageForAi(null)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 space-y-4 shadow-2xl border border-neutral-200 max-h-[92vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2">
                <div className="h-9 w-9 rounded-xl bg-[#25D366] text-white flex items-center justify-center shadow">
                  <MessageCircle size={18} className="fill-current" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-bold text-neutral-900">
                    AI Manager WhatsApp Responder
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    Replying to {activeMessageForAi.name} ({activeMessageForAi.phone})
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActiveMessageForAi(null)}
                className="p-1.5 rounded-full hover:bg-neutral-100 text-neutral-400"
              >
                <X size={18} />
              </button>
            </div>

            {/* Original Customer Message Recap */}
            <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200 text-xs text-neutral-700 space-y-1">
              <span className="font-bold text-[10px] text-neutral-400 uppercase tracking-wider block">
                Inquiry Message:
              </span>
              <p className="italic">"{activeMessageForAi.message}"</p>
            </div>

            {/* Keyword Intelligence Card */}
            <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200 text-xs space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-neutral-700">Category:</span>
                  <span className="px-2 py-0.5 rounded-md bg-[#B8782A] text-white text-[10px] font-bold uppercase tracking-wider">
                    {analysis.matchedCategory}
                  </span>
                </div>

                <div className="text-[11px] text-neutral-600">
                  Keywords: <strong className="text-amber-900">{analysis.matchedKeywords.join(', ') || 'General'}</strong>
                </div>
              </div>

              {/* Context entities if detected */}
              {(analysis.entities.guestCount || analysis.entities.timeOrDate || analysis.entities.locationArea) && (
                <div className="pt-2 border-t border-amber-200/60 flex flex-wrap items-center gap-2 text-[10px]">
                  <span className="font-semibold text-neutral-500">Extracted Context:</span>
                  {analysis.entities.guestCount && (
                    <span className="px-2 py-0.5 rounded bg-amber-200/70 text-amber-950 font-bold">
                      {analysis.entities.guestCount} Guests
                    </span>
                  )}
                  {analysis.entities.timeOrDate && (
                    <span className="px-2 py-0.5 rounded bg-amber-200/70 text-amber-950 font-bold">
                      {analysis.entities.timeOrDate}
                    </span>
                  )}
                  {analysis.entities.locationArea && (
                    <span className="px-2 py-0.5 rounded bg-amber-200/70 text-amber-950 font-bold">
                      {analysis.entities.locationArea}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Template Selector Buttons */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-700">
                  Choose Manager Response Template:
                </label>

                <button
                  type="button"
                  onClick={handleGenerateGeminiReply}
                  disabled={isAiGenerating}
                  className="text-xs text-[#B8782A] hover:text-[#9c631e] font-bold flex items-center gap-1 transition-colors disabled:opacity-50"
                  title="Generate bespoke AI draft using Gemini 3.8 Flash"
                >
                  <Sparkles size={12} className={isAiGenerating ? 'animate-spin' : ''} />
                  <span>{isAiGenerating ? 'AI Generating...' : '✨ Re-craft with Gemini'}</span>
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1.5 p-1 bg-neutral-100 rounded-xl text-[11px]">
                <button
                  type="button"
                  onClick={() => handleSwitchTemplate('instantConfirmation')}
                  className={`py-1.5 px-2 rounded-lg font-bold transition-all ${
                    selectedTemplateKey === 'instantConfirmation'
                      ? 'bg-white text-neutral-900 shadow-sm'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  ⚡ Instant Confirm
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchTemplate('executiveHospitality')}
                  className={`py-1.5 px-2 rounded-lg font-bold transition-all ${
                    selectedTemplateKey === 'executiveHospitality'
                      ? 'bg-white text-neutral-900 shadow-sm'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  👑 Royal Hospitality
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchTemplate('followUpAction')}
                  className={`py-1.5 px-2 rounded-lg font-bold transition-all ${
                    selectedTemplateKey === 'followUpAction'
                      ? 'bg-white text-neutral-900 shadow-sm'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  📍 Location & Action
                </button>
              </div>
            </div>

            {/* Editable Response Draft */}
            <div className="space-y-1.5">
              <textarea
                rows={6}
                value={aiDraft}
                onChange={(e) => setAiDraft(e.target.value)}
                className="w-full p-3.5 bg-[#E7FFDB] border border-emerald-300 rounded-2xl text-xs font-sans leading-relaxed text-neutral-800 focus:outline-none focus:ring-2 focus:ring-emerald-400"
              />
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleCopyAiDraft}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-neutral-200 hover:bg-neutral-100 text-neutral-700 font-semibold text-xs flex items-center justify-center gap-1.5"
              >
                {draftCopied ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                <span>{draftCopied ? 'Copied' : 'Copy Text'}</span>
              </button>

              <a
                href={getWhatsAppReplyUrl()}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setActiveMessageForAi(null)}
                className="w-full sm:w-auto flex-1 py-3 px-5 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow"
              >
                <MessageCircle size={15} className="fill-current" />
                <span>Send via WhatsApp to {activeMessageForAi.name}</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
