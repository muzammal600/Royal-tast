import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { CrownIcon } from '../common/CrownIcon';
import { Lock, Mail, User, ShieldAlert, ArrowRight, KeyRound, CheckCircle } from 'lucide-react';
import { isSupabaseConfigured } from '../../lib/supabase';

interface AdminLoginProps {
  onSuccess: () => void;
  onBackToSite: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess, onBackToSite }) => {
  const { store } = useRoyalStore();
  const [mode, setMode] = useState<'login' | 'setup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const supabaseActive = isSupabaseConfigured();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setLoading(true);

    try {
      const res = await store.adminLogin(email, password);
      if (res.success) {
        onSuccess();
      } else {
        if (res.message === 'INITIAL_SETUP_REQUIRED') {
          setMode('setup');
          setErrorMessage('No admin account found yet. Please create your primary administrator credentials below.');
        } else {
          setErrorMessage(res.message);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    setErrorMessage(null);
    setLoading(true);
    try {
      const res = await store.registerInitialAdmin(email, password, name);
      if (res.success) {
        onSuccess();
      } else {
        setErrorMessage(res.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMessage('Please enter your administrator email.');
      return;
    }
    setErrorMessage(null);
    setLoading(true);
    try {
      const res = await store.sendPasswordResetEmail(email);
      if (res.success) {
        setSuccessMessage(res.message);
      } else {
        setErrorMessage(res.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#19140e] via-[#241c14] to-[#14100b] text-neutral-100 flex items-center justify-center p-4 sm:p-6">
      <div className="max-w-md w-full bg-[#FAF5EC] text-neutral-900 rounded-3xl p-8 sm:p-10 shadow-2xl border border-amber-900/30 relative">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <CrownIcon size={28} color="#B8782A" className="mx-auto mb-2" />
          <h1 className="font-serif text-2xl sm:text-3xl font-black tracking-[0.16em] text-neutral-900">
            ROYAL TASTE
          </h1>
          <p className="text-xs uppercase tracking-widest text-[#B8782A] font-semibold mt-0.5">
            Executive Admin Portal
          </p>
          <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-200">
            {supabaseActive ? 'Supabase Auth Protected' : 'Role-Based Local Security'}
          </div>
        </div>

        {/* Error / Success Alerts */}
        {errorMessage && (
          <div className="mb-6 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <ShieldAlert size={16} className="shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
            <CheckCircle size={16} className="shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Admin Email Address
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="email"
                  required
                  placeholder="admin@royaltaste.pk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setErrorMessage(null);
                    setSuccessMessage(null);
                    setMode('forgot');
                  }}
                  className="text-xs text-[#B8782A] hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white font-bold uppercase tracking-wider text-xs transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In as Administrator'}</span>
              <ArrowRight size={14} />
            </button>

            <div className="pt-4 text-center border-t border-neutral-200 mt-4">
              <button
                type="button"
                onClick={() => {
                  setErrorMessage(null);
                  setSuccessMessage(null);
                  setMode('setup');
                }}
                className="text-xs text-neutral-500 hover:text-neutral-800"
              >
                First time admin? <span className="text-[#B8782A] font-semibold">Initialize Account</span>
              </button>
            </div>
          </form>
        )}

        {/* INITIAL SETUP FORM */}
        {mode === 'setup' && (
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 leading-relaxed">
              Create your primary executive administrator credentials. No hardcoded or default passwords exist.
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Your Full Name
              </label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Muhammad Rizwan (General Manager)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Admin Email Address
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="email"
                  required
                  placeholder="manager@royaltaste.pk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Admin Password (min. 6 characters)
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Confirm Admin Password
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white font-bold uppercase tracking-wider text-xs transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <span>{loading ? 'Creating Administrator...' : 'Register Secure Admin'}</span>
              <KeyRound size={14} />
            </button>

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => {
                  setErrorMessage(null);
                  setSuccessMessage(null);
                  setMode('login');
                }}
                className="text-xs text-neutral-500 hover:text-neutral-800"
              >
                Already have credentials? <span className="text-[#B8782A] font-semibold">Sign In</span>
              </button>
            </div>
          </form>
        )}

        {/* FORGOT PASSWORD FORM */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="space-y-4">
            <p className="text-xs text-neutral-600 leading-relaxed">
              Enter your registered administrator email address to receive password reset instructions.
            </p>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                Admin Email Address
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-3.5 text-neutral-400" />
                <input
                  type="email"
                  required
                  placeholder="admin@royaltaste.pk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm focus:outline-none focus:border-[#B8782A]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-full bg-[#B8782A] hover:bg-[#9c631e] text-white font-bold uppercase tracking-wider text-xs transition-all shadow-md"
            >
              {loading ? 'Dispatching...' : 'Send Password Reset Link'}
            </button>

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => {
                  setErrorMessage(null);
                  setSuccessMessage(null);
                  setMode('login');
                }}
                className="text-xs text-[#B8782A] font-semibold hover:underline"
              >
                ← Back to Login
              </button>
            </div>
          </form>
        )}

        {/* Back to public site button */}
        <div className="mt-6 pt-4 border-t border-neutral-200 text-center">
          <button
            onClick={onBackToSite}
            className="text-xs text-neutral-500 hover:text-[#B8782A] transition-colors"
          >
            ← Return to Royal Taste Dining Website
          </button>
        </div>
      </div>
    </div>
  );
};
