import React, { useState } from 'react';
import { useRoyalStore } from '../../hooks/useRoyalStore';
import { WeeklySpecial } from '../../types';
import { Edit2, Sparkles, Check, X, Calendar } from 'lucide-react';

export const AdminWeeklySpecials: React.FC = () => {
  const { weeklySpecials, store } = useRoyalStore();
  const [editingSpecial, setEditingSpecial] = useState<WeeklySpecial | null>(null);

  // Form state
  const [dishName, setDishName] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [originalPrice, setOriginalPrice] = useState<number>(0);
  const [specialPrice, setSpecialPrice] = useState<number>(0);
  const [imageUrl, setImageUrl] = useState('');
  const [badge, setBadge] = useState('');

  const openEdit = (special: WeeklySpecial) => {
    setEditingSpecial(special);
    setDishName(special.dish_name);
    setTitle(special.title);
    setDescription(special.description);
    setOriginalPrice(special.original_price);
    setSpecialPrice(special.special_price);
    setImageUrl(special.image_url);
    setBadge(special.badge || '');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSpecial) return;

    store.updateWeeklySpecial(editingSpecial.id, {
      dish_name: dishName.trim(),
      title: title.trim(),
      description: description.trim(),
      original_price: Number(originalPrice),
      special_price: Number(specialPrice),
      image_url: imageUrl.trim(),
      badge: badge.trim() || undefined
    });

    setEditingSpecial(null);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-2xl border border-neutral-200/80 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="font-serif text-2xl font-bold text-neutral-900">
            Weekly Specials Configuration (Mon – Sun)
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Configure designated daily special dish, discount pricing in Rs, and banners.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {weeklySpecials.map((special) => (
          <div
            key={special.id}
            className="bg-white rounded-2xl overflow-hidden border border-neutral-200 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="relative h-44 w-full bg-neutral-100">
                <img
                  src={special.image_url}
                  alt={special.dish_name}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-2 left-2 bg-[#B8782A] text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow">
                  {special.day}
                </span>
                {special.badge && (
                  <span className="absolute bottom-2 left-2 bg-black/70 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded">
                    {special.badge}
                  </span>
                )}
              </div>

              <div className="p-4 space-y-2">
                <span className="text-[11px] text-[#B8782A] font-bold uppercase tracking-wider block">
                  {special.title}
                </span>
                <h3 className="font-serif text-lg font-bold text-neutral-900">
                  {special.dish_name}
                </h3>
                <p className="text-xs text-neutral-600 line-clamp-2">
                  {special.description}
                </p>

                <div className="pt-2 flex items-baseline gap-2">
                  <span className="font-serif text-lg font-bold text-[#B8782A]">
                    Rs {special.special_price.toLocaleString()}
                  </span>
                  <span className="text-xs text-neutral-400 line-through">
                    Rs {special.original_price.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                    Save Rs {(special.original_price - special.special_price).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 pt-0 border-t border-neutral-100 mt-2 flex justify-end">
              <button
                onClick={() => openEdit(special)}
                className="py-1.5 px-3 rounded-xl bg-neutral-100 hover:bg-[#B8782A] hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Edit2 size={13} />
                <span>Edit {special.day}'s Special</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Special Modal */}
      {editingSpecial && (
        <div
          onClick={() => setEditingSpecial(null)}
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-4 shadow-2xl border border-neutral-200"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-serif text-xl font-bold text-neutral-900">
                Edit {editingSpecial.day}'s Special
              </h3>
              <button
                onClick={() => setEditingSpecial(null)}
                className="p-1 rounded-full hover:bg-neutral-100"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Special Dish Name
                </label>
                <input
                  type="text"
                  required
                  value={dishName}
                  onChange={(e) => setDishName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Theme Title (e.g. Biryani Day, Karahi Night)
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Original Price (Rs)
                  </label>
                  <input
                    type="number"
                    required
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Special Offer Price (Rs)
                  </label>
                  <input
                    type="number"
                    required
                    value={specialPrice}
                    onChange={(e) => setSpecialPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Image URL
                </label>
                <input
                  type="text"
                  required
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Badge (e.g. Save Rs 200, Mega Deal)
                </label>
                <input
                  type="text"
                  value={badge}
                  onChange={(e) => setBadge(e.target.value)}
                  className="w-full px-3.5 py-2 bg-neutral-50 border border-neutral-300 rounded-xl text-xs"
                />
              </div>

              <div className="pt-3 border-t flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingSpecial(null)}
                  className="px-4 py-2 rounded-full border text-xs font-bold uppercase tracking-wider text-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-full bg-[#B8782A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#9c631e]"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
