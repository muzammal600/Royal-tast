import { Category, Chef, Deal, GalleryItem, MenuItem, Offer, SiteSettings, Testimonial, WeeklySpecial } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'starters-soups',
    name: 'Starters & Soups',
    slug: 'starters-soups',
    image_url: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80',
    description: 'Aromatic warm soups and crispy golden appetizers to awaken your palate.',
    display_order: 1
  },
  {
    id: 'salads',
    name: 'Salads & Raita',
    slug: 'salads',
    image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    description: 'Crisp garden greens, authentic Russian salad, and spiced yogurt accompaniments.',
    display_order: 2
  },
  {
    id: 'pakistani-desi',
    name: 'Pakistani / Desi',
    slug: 'pakistani-desi',
    image_url: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80',
    description: 'Iconic royal karahis, slow-cooked nihari, dum biryani, and piping-hot tandoori breads.',
    display_order: 3
  },
  {
    id: 'bbq',
    name: 'Live BBQ & Grills',
    slug: 'bbq',
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    description: 'Charcoal-grilled skewers, succulent mutton chops, tender malai boti, and royal platters.',
    display_order: 4
  },
  {
    id: 'chinese',
    name: 'Chinese Specialties',
    slug: 'chinese',
    image_url: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80',
    description: 'Wok-tossed chowmein, spicy chilli dry chicken, sizzling Manchurian, and fried rice.',
    display_order: 5
  },
  {
    id: 'fast-food',
    name: 'Fast Food & Rolls',
    slug: 'fast-food',
    image_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80',
    description: 'Crispy zinger burgers, juicy beef patties, club sandwiches, and paratha rolls.',
    display_order: 6
  },
  {
    id: 'pizza-pasta',
    name: 'Pizza & Pasta',
    slug: 'pizza-pasta',
    image_url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80',
    description: 'Stone-baked artisan pizzas, rich Alfredo pasta, and layered Italian-desi lasagna.',
    display_order: 7
  },
  {
    id: 'steaks-continental',
    name: 'Steaks & Continental',
    slug: 'steaks-continental',
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    description: 'Prime ribeye beef cuts, grilled Norwegian salmon, and chicken cordon bleu.',
    display_order: 8
  },
  {
    id: 'drinks',
    name: 'Beverages & Mocktails',
    slug: 'drinks',
    image_url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80',
    description: 'Refreshing mint margaritas, thick lassis, shakes, coolers, and traditional doodh patti.',
    display_order: 9
  },
  {
    id: 'desserts',
    name: 'Royal Desserts',
    slug: 'desserts',
    image_url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=600&q=80',
    description: 'Warm gulab jamuns, saffron kheer, royal falooda, gajar halwa, and molten chocolate cake.',
    display_order: 10
  }
];

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  // --- STARTERS AND SOUPS (10 items) ---
  {
    id: 'starter-1',
    category_id: 'starters-soups',
    name: 'Chicken Corn Soup',
    description: 'Silky, comforting chicken broth loaded with tender shredded chicken, sweet corn, and egg drops.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=600&q=80',
    badge: 'Popular',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'starter-2',
    category_id: 'starters-soups',
    name: 'Hot and Sour Soup',
    description: 'A tangy, spicy Indo-Pak favorite loaded with seasonal vegetables, chicken strips, soy and chili.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=600&q=80',
    badge: 'Spicy',
    veg_nonveg: 'non-veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'starter-3',
    category_id: 'starters-soups',
    name: 'Chicken Wings (6 pcs)',
    description: 'Crispy fried chicken wings tossed in our signature smoky honey-chili glaze.',
    price: 750,
    image_url: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?auto=format&fit=crop&w=600&q=80',
    badge: 'Crispy',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'starter-4',
    category_id: 'starters-soups',
    name: 'Chicken Nuggets (8 pcs)',
    description: 'Golden crumb-crusted breast fillets fried crisp and served with garlic mayo dip.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'starter-5',
    category_id: 'starters-soups',
    name: 'Loaded Fries',
    description: 'Crisp golden potato fries smothered in warm cheese sauce, diced chicken chunks, and jalapenos.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80',
    badge: 'Bestseller',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'starter-6',
    category_id: 'starters-soups',
    name: 'Cheese Garlic Bread',
    description: 'Toasted baguette slices brushed with garlic herb butter and capped with melted mozzarella.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1619895092538-128341789043?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'starter-7',
    category_id: 'starters-soups',
    name: 'Chicken Spring Rolls (4 pcs)',
    description: 'Delicate crispy wonton wrappers filled with sautéed chicken, crunchy shredded cabbage, and carrots.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'starter-8',
    category_id: 'starters-soups',
    name: 'Dynamite Prawns',
    description: 'Jumbo succulent tiger prawns battered golden and dressed in fiery Japanese-style dynamite sauce.',
    price: 1450,
    image_url: 'https://images.unsplash.com/photo-1559742811-82286364ceaf?auto=format&fit=crop&w=600&q=80',
    badge: "Chef's Special",
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'starter-9',
    category_id: 'starters-soups',
    name: 'Fish Fingers',
    description: 'Tender fresh river sole fillets seasoned with spices, breaded, and fried with house tartar sauce.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1526318896980-cf78c088247c?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'starter-10',
    category_id: 'starters-soups',
    name: 'Samosa Chaat',
    description: 'Crushed crispy samosas crowned with spiced chickpeas, sweet tamarind chutney, and whipped curd.',
    price: 350,
    image_url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
    badge: 'Street Classic',
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },

  // --- SALADS (4 items) ---
  {
    id: 'salad-1',
    category_id: 'salads',
    name: 'Fresh Green Salad',
    description: 'Garden-fresh cucumbers, ripe tomatoes, red onions, radish, and green chili with freshly squeezed lemon.',
    price: 350,
    image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.5,
    is_available: true
  },
  {
    id: 'salad-2',
    category_id: 'salads',
    name: 'Russian Salad',
    description: 'Creamy classic blend of diced apples, pineapple chunks, green peas, and potatoes in rich sweet mayo.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?auto=format&fit=crop&w=600&q=80',
    badge: 'Classic',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'salad-3',
    category_id: 'salads',
    name: 'Caesar Salad',
    description: 'Crisp romaine lettuce hearts, herb croutons, and parmesan shavings tossed in homemade Caesar dressing.',
    price: 850,
    image_url: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'salad-4',
    category_id: 'salads',
    name: 'Raita',
    description: 'Cool whisked fresh dahi infused with roasted cumin, fresh garden mint, and delicate rock salt.',
    price: 150,
    image_url: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },

  // --- PAKISTANI / DESI (20 items) ---
  {
    id: 'desi-1',
    category_id: 'pakistani-desi',
    name: 'Chicken Karahi',
    description: 'Our signature wok-cooked fresh chicken tossed in aromatic tomatoes, ginger slivers, and green chilies in pure desi ghee.',
    price: 1500,
    size_variants: [
      { name: 'Half (0.5 kg)', price: 1500 },
      { name: 'Full (1.0 kg)', price: 2800 }
    ],
    image_url: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80',
    badge: 'Royal Signature',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'desi-2',
    category_id: 'pakistani-desi',
    name: 'Mutton Karahi',
    description: 'Tender baby mutton pieces prepared in an authentic Shinwari cast iron wok with fresh tomatoes and black pepper.',
    price: 2400,
    size_variants: [
      { name: 'Half (0.5 kg)', price: 2400 },
      { name: 'Full (1.0 kg)', price: 4600 }
    ],
    image_url: 'https://images.unsplash.com/photo-1545247181-516773ca83f3?auto=format&fit=crop&w=600&q=80',
    badge: 'Bestseller',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'desi-3',
    category_id: 'pakistani-desi',
    name: 'Chicken Handi',
    description: 'Boneless tender chicken cubes simmered in a velvet clay pot gravy enriched with fresh cream and royal spices.',
    price: 1600,
    size_variants: [
      { name: 'Half', price: 1600 },
      { name: 'Full', price: 3000 }
    ],
    image_url: 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=600&q=80',
    badge: 'Creamy',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'desi-4',
    category_id: 'pakistani-desi',
    name: 'Beef Nihari',
    description: 'Authentic 12-hour slow-cooked beef shank infused with royal bone marrow broth, ginger juliennes, and lemon.',
    price: 1100,
    image_url: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=600&q=80',
    badge: 'Lahore Classic',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'desi-5',
    category_id: 'pakistani-desi',
    name: 'Haleem',
    description: 'Slow-simmered aromatic stew of shredded beef, whole wheat, barley, and lentils garnished with fried onions.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80',
    badge: 'Comfort Food',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'desi-6',
    category_id: 'pakistani-desi',
    name: 'Paya',
    description: 'Traditional goat trotters stew cooked overnight with warming spices until gelatinous and deeply flavorful.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=600&q=80',
    badge: 'Authentic',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'desi-7',
    category_id: 'pakistani-desi',
    name: 'Chicken Qorma',
    description: 'Royal Mughlai style chicken braised in velvety browned onion and yogurt gravy infused with kewra water.',
    price: 1200,
    image_url: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=600&q=80',
    badge: 'Mughlai',
    veg_nonveg: 'non-veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'desi-8',
    category_id: 'pakistani-desi',
    name: 'Daal Mash',
    description: 'Peeled white urad lentils cooked till firm and tender, finished with a sputtering desi ghee tarka of cumin and garlic.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1546833998-877b37c2e5c6?auto=format&fit=crop&w=600&q=80',
    badge: 'Dhabba Special',
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'desi-9',
    category_id: 'pakistani-desi',
    name: 'Daal Fry',
    description: 'Yellow lentils tempered with aromatic cumin seeds, red chilies, freshly chopped tomatoes, and cilantro.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'desi-10',
    category_id: 'pakistani-desi',
    name: 'Palak Paneer',
    description: 'Velvety puréed garden spinach simmered with cottage cheese cubes, garlic, and fresh milk cream.',
    price: 750,
    image_url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
    badge: 'Vegetarian Pick',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'desi-11',
    category_id: 'pakistani-desi',
    name: 'Mix Sabzi',
    description: 'Medley of seasonal carrots, green peas, potatoes, and beans wok-tossed in onion-tomato masala.',
    price: 600,
    image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.5,
    is_available: true
  },
  {
    id: 'desi-12',
    category_id: 'pakistani-desi',
    name: 'Chicken Biryani',
    description: 'Long-grain aged basmati rice layered with succulent marinated chicken, saffron, potatoes, and dried plums.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80',
    badge: 'All-Time Favorite',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'desi-13',
    category_id: 'pakistani-desi',
    name: 'Mutton Biryani',
    description: 'Prime mutton cuts dum-cooked under sealed earthen pots with fragrant basmati, mint, and whole spices.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=600&q=80',
    badge: 'Royal Feast',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'desi-14',
    category_id: 'pakistani-desi',
    name: 'Chicken Pulao',
    description: 'Subtly spiced basmati rice simmered gently in rich chicken bone yakhni broth with caramelized onions.',
    price: 600,
    image_url: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'desi-15',
    category_id: 'pakistani-desi',
    name: 'Mutton Pulao',
    description: 'Traditional Bannu-style yakhni pulao with fork-tender mutton pieces and marrow essence.',
    price: 900,
    image_url: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=600&q=80',
    badge: 'Specialty',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'desi-16',
    category_id: 'pakistani-desi',
    name: 'Plain Rice',
    description: 'Fluffy steamed fragrant extra long grain Pakistani basmati rice.',
    price: 300,
    image_url: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.4,
    is_available: true
  },
  {
    id: 'desi-17',
    category_id: 'pakistani-desi',
    name: 'Butter Naan',
    description: 'Soft tandoori leavened flatbread brushed with abundant melted salted dairy butter.',
    price: 80,
    image_url: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'desi-18',
    category_id: 'pakistani-desi',
    name: 'Roghni Naan',
    description: 'Royal bakery-grade tandoor naan enriched with milk, sesame seeds, and golden butter glaze.',
    price: 100,
    image_url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
    badge: 'Royal Bread',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'desi-19',
    category_id: 'pakistani-desi',
    name: 'Garlic Naan',
    description: 'Clay-oven baked bread infused with minced roasted garlic, fresh coriander leaves, and ghee.',
    price: 120,
    image_url: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'desi-20',
    category_id: 'pakistani-desi',
    name: 'Tandoori Roti',
    description: 'Traditional whole-wheat flatbread freshly slapped on the searing clay walls of our tandoor.',
    price: 40,
    image_url: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },

  // --- BBQ (8 items) ---
  {
    id: 'bbq-1',
    category_id: 'bbq',
    name: 'Chicken Tikka',
    description: 'Marinated in spicy yogurt, lemon juice, and red tandoori masala, charcoal-grilled to smoky tenderness.',
    price: 450,
    size_variants: [
      { name: 'Leg Piece', price: 450 },
      { name: 'Chest Piece', price: 480 }
    ],
    image_url: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80',
    badge: 'Popular',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'bbq-2',
    category_id: 'bbq',
    name: 'Malai Boti',
    description: 'Boneless chicken cubes steeped in thick cream, green cardamom, white pepper, and melted butter.',
    price: 1100,
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    badge: 'Melt In Mouth',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'bbq-3',
    category_id: 'bbq',
    name: 'Reshmi Kebab (4 pcs)',
    description: 'Minced chicken skewers infused with cream, saffron, and fine herbs, grilled gently on glowing embers.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'bbq-4',
    category_id: 'bbq',
    name: 'Bihari Boti',
    description: 'Thin beef fillets tenderized with raw papaya and Bihari spices, grilled to smoky charred perfection.',
    price: 1350,
    image_url: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80',
    badge: "Chef's Special",
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'bbq-5',
    category_id: 'bbq',
    name: 'Seekh Kebab (4 pcs)',
    description: 'Coarsely minced seasoned beef kebabs wrapped around iron skewers and smoked on coal.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format&fit=crop&w=600&q=80',
    badge: 'Classic',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'bbq-6',
    category_id: 'bbq',
    name: 'Mutton Chops (6 pcs)',
    description: 'Succulent lamb rib chops marinated in crushed black peppercorn, garlic, and vinegar.',
    price: 2200,
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    badge: 'Premium Cut',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'bbq-7',
    category_id: 'bbq',
    name: 'Chicken Chargha',
    description: 'Whole chicken deeply scored, spiced with aromatic masala, steamed, and flash-fried to golden crispness.',
    price: 1400,
    image_url: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=600&q=80',
    badge: 'Lahore Specialty',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'bbq-8',
    category_id: 'bbq',
    name: 'BBQ Platter (for 2)',
    description: 'Grand feast with 2 Reshmi Kebabs, 2 Seekh Kebabs, Malai Boti, Chicken Tikka chest, and mint chutney.',
    price: 3200,
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    badge: 'Grand Feast',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },

  // --- CHINESE (8 items) ---
  {
    id: 'chinese-1',
    category_id: 'chinese',
    name: 'Chicken Manchurian',
    description: 'Crispy fried chicken balls drenched in sweet and spicy garlic-ginger tomato sauce.',
    price: 1250,
    image_url: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80',
    badge: 'Bestseller',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'chinese-2',
    category_id: 'chinese',
    name: 'Chowmein',
    description: 'Wok-stirred egg noodles tossed with shredded chicken, crunchy carrots, cabbage, and sesame soy sauce.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'chinese-3',
    category_id: 'chinese',
    name: 'Egg Fried Rice',
    description: 'Classic wok-fried basmati rice scrambled with golden eggs, scallions, and light seasoning.',
    price: 750,
    image_url: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'chinese-4',
    category_id: 'chinese',
    name: 'Chicken Fried Rice',
    description: 'Wok-charred rice tossed with minced chicken chunks, garden carrots, scallions, and soy oil.',
    price: 850,
    image_url: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'chinese-5',
    category_id: 'chinese',
    name: 'Chicken Chilli Dry',
    description: 'Crispy fried chicken strips tossed dry with fiery green chilies, ginger slivers, and soy reduction.',
    price: 1350,
    image_url: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=600&q=80',
    badge: 'Spicy Hit',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'chinese-6',
    category_id: 'chinese',
    name: 'Sweet and Sour Chicken',
    description: 'Glazed chicken chunks, bell peppers, and pineapple wedges in sweet-tangy crimson sauce.',
    price: 1250,
    image_url: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'chinese-7',
    category_id: 'chinese',
    name: 'Chicken Shashlik',
    description: 'Chicken cubes, capsicum, and onions on skewers served on a sizzling platter with rich tomato gravy.',
    price: 1350,
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    badge: 'Sizzling',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'chinese-8',
    category_id: 'chinese',
    name: 'Beef Chilli Dry',
    description: 'Tender marinated beef slices flashed in high wok heat with fresh dark chilies and sesame seeds.',
    price: 1650,
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    badge: 'Premium',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },

  // --- FAST FOOD (9 items) ---
  {
    id: 'fast-1',
    category_id: 'fast-food',
    name: 'Zinger Burger',
    description: 'Crunchy golden-fried whole chicken thigh fillet, iceberg lettuce, and spicy mayo inside a toasted sesame bun.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80',
    badge: '-15% Special',
    discount_percent: 15,
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'fast-2',
    category_id: 'fast-food',
    name: 'Beef Burger',
    description: '100% pure grilled beef patty with cheddar cheese, caramelized onions, pickles, and smoky burger sauce.',
    price: 750,
    image_url: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'fast-3',
    category_id: 'fast-food',
    name: 'Double Patty Cheese Burger',
    description: 'Two smash beef patties layered with double yellow cheddar, garlic aioli, and crisp greens.',
    price: 950,
    image_url: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80',
    badge: 'Monster',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'fast-4',
    category_id: 'fast-food',
    name: 'Club Sandwich',
    description: 'Triple-layer toasted bread loaded with chicken, fried egg, cheese slice, lettuce, and homemade sauce.',
    price: 750,
    image_url: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'fast-5',
    category_id: 'fast-food',
    name: 'Chicken Shawarma',
    description: 'Spit-roasted shredded chicken stuffed into soft pita bread with garlic toum sauce and pickled turnips.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'fast-6',
    category_id: 'fast-food',
    name: 'Zinger Shawarma',
    description: 'Crispy fried spicy zinger strips wrapped in warm pita with cheese drizzle and pickled jalapenos.',
    price: 500,
    image_url: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=600&q=80',
    badge: 'Crispy Wrap',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'fast-7',
    category_id: 'fast-food',
    name: 'Chicken Paratha Roll',
    description: 'Flaky layered pan-crisped paratha stuffed with BBQ chicken tikka chunks, sliced onions, and green chutney.',
    price: 400,
    image_url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
    badge: 'Karachi Style',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'fast-8',
    category_id: 'fast-food',
    name: 'French Fries',
    description: 'Crispy salted golden potato fries served hot with ketchup and chili garlic dips.',
    price: 300,
    image_url: 'https://images.unsplash.com/photo-1576107232684-1279f3908594?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'fast-9',
    category_id: 'fast-food',
    name: 'Crispy Chicken Bucket (6 pcs)',
    description: 'Six jumbo bone-in chicken cuts seasoned with secret southern spices and pressure fried extra crispy.',
    price: 1800,
    image_url: 'https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=600&q=80',
    badge: 'Family Bucket',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },

  // --- PIZZA AND PASTA (7 items) ---
  {
    id: 'pizza-1',
    category_id: 'pizza-pasta',
    name: 'Fajita Pizza',
    description: 'Stone-oven crust topped with Mexican-spiced chicken, bell peppers, onions, and rich mozzarella.',
    price: 750,
    size_variants: [
      { name: 'Small (8")', price: 750 },
      { name: 'Medium (10")', price: 1300 },
      { name: 'Large (13")', price: 1800 }
    ],
    image_url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80',
    badge: 'Top Pick',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'pizza-2',
    category_id: 'pizza-pasta',
    name: 'Tikka Pizza',
    description: 'Pakistani-style BBQ chicken tikka chunks, spicy pizza sauce, black olives, onions, and loaded cheese.',
    price: 750,
    size_variants: [
      { name: 'Small (8")', price: 750 },
      { name: 'Medium (10")', price: 1300 },
      { name: 'Large (13")', price: 1800 }
    ],
    image_url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80',
    badge: 'Desi Fusion',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'pizza-3',
    category_id: 'pizza-pasta',
    name: 'Margherita Pizza',
    description: 'Classic Italian crust with sweet San Marzano tomato sauce, fresh buffalo mozzarella, and basil leaves.',
    price: 650,
    size_variants: [
      { name: 'Small (8")', price: 650 },
      { name: 'Medium (10")', price: 1100 },
      { name: 'Large (13")', price: 1500 }
    ],
    image_url: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'pizza-4',
    category_id: 'pizza-pasta',
    name: 'Pepperoni Pizza',
    description: 'Thin hand-stretched crust crowned with halal beef pepperoni slices, oregano, and bubbling cheese.',
    price: 900,
    size_variants: [
      { name: 'Small (8")', price: 900 },
      { name: 'Medium (10")', price: 1500 },
      { name: 'Large (13")', price: 2000 }
    ],
    image_url: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=600&q=80',
    badge: 'Classic',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'pasta-1',
    category_id: 'pizza-pasta',
    name: 'Alfredo Pasta',
    description: 'Fettuccine pasta enrobed in a rich parmesan cream reduction with pan-seared chicken and mushrooms.',
    price: 1150,
    image_url: 'https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&w=600&q=80',
    badge: 'Rich & Creamy',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'pasta-2',
    category_id: 'pizza-pasta',
    name: 'Crunchy Chicken Pasta',
    description: 'Penne pasta tossed in pink aurora sauce, topped with sliced golden crumb-fried chicken fillets.',
    price: 1050,
    image_url: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'pasta-3',
    category_id: 'pizza-pasta',
    name: 'Lasagna',
    description: 'Layers of durum pasta, seasoned minced beef Bolognese, bechamel, and gratinated golden mozzarella.',
    price: 1250,
    image_url: 'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?auto=format&fit=crop&w=600&q=80',
    badge: 'Comfort Classic',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },

  // --- STEAKS AND CONTINENTAL (6 items) ---
  {
    id: 'steak-1',
    category_id: 'steaks-continental',
    name: 'Ribeye Steak',
    description: '300g prime tenderized beef ribeye grilled to your liking with garlic herb butter, mashed potatoes, and pepper sauce.',
    price: 3200,
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
    badge: 'Prime Beef',
    veg_nonveg: 'non-veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'steak-2',
    category_id: 'steaks-continental',
    name: 'Grilled Salmon',
    description: 'Pan-seared Norwegian salmon steak served over sautéed asparagus with lemon-dill caper butter sauce.',
    price: 2800,
    image_url: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=600&q=80',
    badge: 'Ocean Fresh',
    veg_nonveg: 'non-veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'steak-3',
    category_id: 'steaks-continental',
    name: 'Grilled Chicken Steak',
    description: 'Twin grilled chicken fillets resting on a sizzling cast iron skillet with charred vegetables and mushroom sauce.',
    price: 1550,
    image_url: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=600&q=80',
    badge: 'Sizzling Hit',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'steak-4',
    category_id: 'steaks-continental',
    name: 'Chicken Cordon Bleu',
    description: 'Tender chicken breast stuffed with smoked turkey ham and melted Swiss cheese, coated in panko breadcrumbs.',
    price: 1650,
    image_url: 'https://images.unsplash.com/photo-1600891964599-f61ba0e24092?auto=format&fit=crop&w=600&q=80',
    badge: 'Continental',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'steak-5',
    category_id: 'steaks-continental',
    name: 'Truffle Mushroom Risotto',
    description: 'Creamy slow-stirred Arborio rice cooked with porcini broth, wild mushrooms, and white truffle oil drizzle.',
    price: 1650,
    image_url: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=600&q=80',
    badge: 'Gourmet',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'steak-6',
    category_id: 'steaks-continental',
    name: 'Fish and Chips',
    description: 'Crisp golden-battered fresh sea fish fillets served with steak fries, mushy peas, and homemade tartar sauce.',
    price: 1350,
    image_url: 'https://images.unsplash.com/photo-1526318896980-cf78c088247c?auto=format&fit=crop&w=600&q=80',
    badge: 'Golden Crispy',
    veg_nonveg: 'non-veg',
    rating: 4.8,
    is_available: true
  },

  // --- DRINKS (18 items) ---
  {
    id: 'drink-1',
    category_id: 'drinks',
    name: 'Mint Margarita',
    description: 'Zesty blended drink of fresh mint leaves, lemon juice, crushed ice, and sparkling soda.',
    price: 350,
    image_url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80',
    badge: 'Signature Cooler',
    veg_nonveg: 'veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'drink-2',
    category_id: 'drinks',
    name: 'Sweet Lassi',
    description: 'Traditional Punjabi sweet churned yogurt drink topped with a dollop of fresh thick malai.',
    price: 300,
    image_url: 'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?auto=format&fit=crop&w=600&q=80',
    badge: 'Traditional',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'drink-3',
    category_id: 'drinks',
    name: 'Salty Lassi',
    description: 'Refreshing savory churned yogurt with roasted cumin powder and black salt.',
    price: 300,
    image_url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'drink-4',
    category_id: 'drinks',
    name: 'Mango Shake',
    description: 'Thick shake made with sweet ripe Pakistani Chaunsa mango pulp and chilled full-cream milk.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=600&q=80',
    badge: 'Chaunsa Gold',
    veg_nonveg: 'veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'drink-5',
    category_id: 'drinks',
    name: 'Banana Shake',
    description: 'Fresh bananas blended with creamy milk, honey, and a touch of vanilla.',
    price: 400,
    image_url: 'https://images.unsplash.com/photo-1553787499-6f9133860278?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'drink-6',
    category_id: 'drinks',
    name: 'Oreo Shake',
    description: 'Decadent chocolate shake blended with crunchy Oreo cookies and crowned with whipped cream.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=600&q=80',
    badge: 'Kids Love It',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'drink-7',
    category_id: 'drinks',
    name: 'Fresh Lime',
    description: 'Sparkling mineral water infused with fresh green lime juice and sugar syrup on crushed ice.',
    price: 250,
    image_url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'drink-8',
    category_id: 'drinks',
    name: 'Virgin Mojito',
    description: 'Muddled fresh mint sprigs, lime wedges, simple syrup, and effervescent soda on cracked ice.',
    price: 400,
    image_url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80',
    badge: 'Cooling',
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'drink-9',
    category_id: 'drinks',
    name: 'Blue Lagoon',
    description: 'Vibrant blue curaçao flavor mixed with zesty citrus lemonade and chilled club soda.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'drink-10',
    category_id: 'drinks',
    name: 'Mango Passion Mocktail',
    description: 'A tropical fusion of exotic passion fruit puree and sweet mango nectar with sparkling fizz.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?auto=format&fit=crop&w=600&q=80',
    badge: 'Tropical',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'drink-11',
    category_id: 'drinks',
    name: 'Soft Drink 345ml',
    description: 'Chilled glass bottle / can of Coca-Cola, Sprite, or Fanta.',
    price: 120,
    image_url: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.5,
    is_available: true
  },
  {
    id: 'drink-12',
    category_id: 'drinks',
    name: 'Soft Drink 1.5L',
    description: 'Large family sharing bottle of chilled Coca-Cola or Sprite.',
    price: 280,
    image_url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.5,
    is_available: true
  },
  {
    id: 'drink-13',
    category_id: 'drinks',
    name: 'Mineral Water',
    description: 'Pure, refreshing bottled mineral water.',
    price: 100,
    image_url: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.6,
    is_available: true
  },
  {
    id: 'drink-14',
    category_id: 'drinks',
    name: 'Doodh Patti Chai',
    description: 'Pakistani royal tea simmered exclusively in pure milk and black tea leaves until golden brown.',
    price: 150,
    image_url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80',
    badge: 'Desi Heart',
    veg_nonveg: 'veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'drink-15',
    category_id: 'drinks',
    name: 'Karak Chai',
    description: 'Bold, robust spiced black tea brewed slowly with green cardamom, ginger, and condensed milk.',
    price: 200,
    image_url: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&q=80',
    badge: 'Cardamom Scented',
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'drink-16',
    category_id: 'drinks',
    name: 'Kashmiri Chai',
    description: 'Traditional pink tea brewed with special Kashmiri leaves, milk, and garnished with crushed pistachios & almonds.',
    price: 350,
    image_url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80',
    badge: 'Pink Tea Classic',
    veg_nonveg: 'veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'drink-17',
    category_id: 'drinks',
    name: 'Coffee Latte',
    description: 'Rich dark espresso roast layered with steamed milk and delicate microfoam art.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?auto=format&fit=crop&w=600&q=80',
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  },
  {
    id: 'drink-18',
    category_id: 'drinks',
    name: 'Cold Coffee',
    description: 'Blended espresso with chilled milk, vanilla bean ice cream, and chocolate syrup drizzle.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=600&q=80',
    badge: 'Chilled Coffee',
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },

  // --- DESSERTS (10 items) ---
  {
    id: 'dessert-1',
    category_id: 'desserts',
    name: 'Gulab Jamun (2 pcs)',
    description: 'Warm soft milk dumplings soaked in fragrant cardamom and saffron rose-sugar syrup.',
    price: 250,
    image_url: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80',
    badge: 'Royal Favorite',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'dessert-2',
    category_id: 'desserts',
    name: 'Kheer',
    description: 'Slow-cooked traditional rice pudding infused with saffron, milk reduction, and shredded silver warq.',
    price: 300,
    image_url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=600&q=80',
    badge: 'Shahi Kheer',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'dessert-3',
    category_id: 'desserts',
    name: 'Gajar Halwa',
    description: 'Red winter carrots slowly roasted in desi ghee, milk solids (khoya), and loaded with cashews.',
    price: 400,
    image_url: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80',
    badge: 'Winter Delight',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'dessert-4',
    category_id: 'desserts',
    name: 'Kulfi',
    description: 'Authentic dense frozen cream on stick scented with green cardamom, kewra, and roasted pistachios.',
    price: 350,
    image_url: 'https://images.unsplash.com/photo-1505394033641-40c6ad1178d7?auto=format&fit=crop&w=600&q=80',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'dessert-5',
    category_id: 'desserts',
    name: 'Ras Malai (2 pcs)',
    description: 'Tender cottage cheese discs immersed in sweet thickened milk flavored with saffron and crushed nuts.',
    price: 450,
    image_url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=600&q=80',
    badge: 'Pure Malai',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 5.0,
    is_available: true
  },
  {
    id: 'dessert-6',
    category_id: 'desserts',
    name: 'Falooda',
    description: 'Layers of rose syrup, basil seeds, handmade vermicelli, chilled milk, and royal kulfi slices.',
    price: 550,
    image_url: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80',
    badge: 'All-Time Classic',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'dessert-7',
    category_id: 'desserts',
    name: 'Brownie with Ice Cream',
    description: 'Warm, gooey Dutch chocolate fudge brownie served with a scoop of vanilla bean ice cream and hot chocolate.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&q=80',
    badge: 'Gooey Delight',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'dessert-8',
    category_id: 'desserts',
    name: 'Chocolate Lava Cake',
    description: 'Decadent chocolate sponge with an oozing liquid Belgian chocolate center, dusted with icing sugar.',
    price: 650,
    image_url: 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?auto=format&fit=crop&w=600&q=80',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.9,
    is_available: true
  },
  {
    id: 'dessert-9',
    category_id: 'desserts',
    name: 'Classic Tiramisu',
    description: 'Italian savoiardi ladyfingers soaked in espresso coffee layered with sweet mascarpone sabayon.',
    price: 750,
    image_url: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=600&q=80',
    badge: 'Italian Touch',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.8,
    is_available: true
  },
  {
    id: 'dessert-10',
    category_id: 'desserts',
    name: 'Ice Cream (per scoop)',
    description: 'Choice of French Vanilla, Belgian Chocolate, Mango, or Kulfa ice cream scoop.',
    price: 200,
    image_url: 'https://images.unsplash.com/photo-1505394033641-40c6ad1178d7?auto=format&fit=crop&w=600&q=80',
    discount_percent: 10,
    veg_nonveg: 'veg',
    rating: 4.7,
    is_available: true
  }
];

export const INITIAL_WEEKLY_SPECIALS: WeeklySpecial[] = [
  {
    id: 'mon-special',
    day: 'Monday',
    title: 'Biryani Day',
    dish_name: 'Chicken Biryani Special',
    description: 'Aromatic layered basmati rice with succulent chicken cooked in traditional dum style, served with fresh raita.',
    original_price: 650,
    special_price: 550,
    image_url: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80',
    badge: 'Save Rs 100'
  },
  {
    id: 'tue-special',
    day: 'Tuesday',
    title: 'Karahi Night',
    dish_name: 'Chicken Karahi Half',
    description: 'Wok-cooked fresh chicken in tomato, green chili and ginger gravy prepared in desi ghee.',
    original_price: 1500,
    special_price: 1300,
    image_url: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80',
    badge: 'Save Rs 200'
  },
  {
    id: 'wed-special',
    day: 'Wednesday',
    title: 'Pizza Day',
    dish_name: 'Medium Pizza (Any Flavor)',
    description: 'Freshly baked hand-stretched 10" pizza with stone-ground sauce and melted whole milk mozzarella.',
    original_price: 1300,
    special_price: 999,
    image_url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80',
    badge: 'Mega Deal'
  },
  {
    id: 'thu-special',
    day: 'Thursday',
    title: 'Chinese Night',
    dish_name: 'Chowmein + Manchurian Combo',
    description: 'Wok-tossed chicken chowmein paired with sizzling chicken Manchurian in rich glaze.',
    original_price: 2200,
    special_price: 1899,
    image_url: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80',
    badge: 'Chef Combo'
  },
  {
    id: 'fri-special',
    day: 'Friday',
    title: 'BBQ Night',
    dish_name: 'BBQ Platter Deluxe',
    description: 'Charcoal feast featuring seekh kebabs, reshmis, malai boti, chicken tikka, and hot butter naans.',
    original_price: 3200,
    special_price: 2799,
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    badge: 'Friday Grand'
  },
  {
    id: 'sat-special',
    day: 'Saturday',
    title: 'Nihari and Paya Breakfast',
    dish_name: 'Beef Nihari Royal Feast',
    description: '12-hour simmered shank nihari garnished with bone marrow, ginger julienne, and hot roghni naan.',
    original_price: 1100,
    special_price: 950,
    image_url: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=600&q=80',
    badge: 'Morning Royal'
  },
  {
    id: 'sun-special',
    day: 'Sunday',
    title: 'Family Feast',
    dish_name: 'Sunday Royal Family Deal',
    description: 'Grand dining: Full Chicken Karahi, 2 Chicken Biryani, 6 Roghni Naan, Raita, and 1.5L drink.',
    original_price: 4999,
    special_price: 4499,
    image_url: 'https://images.unsplash.com/photo-1545247181-516773ca83f3?auto=format&fit=crop&w=600&q=80',
    badge: 'Weekend Special'
  }
];

export const INITIAL_DEALS: Deal[] = [
  {
    id: 'deal-family',
    title: 'Family Deal',
    subtitle: 'The Ultimate Royal Gathering',
    price: 4999,
    original_value: 5800,
    description: 'Perfect feast for family get-togethers and celebrations.',
    items: [
      '1x Chicken Karahi (Full 1kg)',
      '2x Chicken Biryani Platter',
      '6x Freshly Baked Butter Naan',
      '1x Zeera Raita & Fresh Mint Salad',
      '1x Chilled Soft Drink 1.5L'
    ],
    serves: 'Serves 4 - 6 persons',
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80',
    badge: 'Best Value',
    is_active: true
  },
  {
    id: 'deal-student',
    title: 'Student Deal',
    subtitle: 'Fast, Crispy & Pocket-Friendly',
    price: 799,
    original_value: 1070,
    description: 'Quick crispy bite packed with flavor for campus hunger.',
    items: [
      '1x Crispy Zinger Burger',
      '1x Crispy Salted French Fries',
      '1x Chilled Soft Drink 345ml'
    ],
    serves: 'Serves 1 person',
    image_url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80',
    badge: 'Student Saver',
    is_active: true
  },
  {
    id: 'deal-lunch',
    title: 'Lunch Deal',
    subtitle: 'Authentic Mid-Day Comfort',
    price: 1199,
    original_value: 1400,
    description: 'Wholesome royal lunch combo served daily from 12 PM to 5 PM.',
    items: [
      '1x Authentic Chicken Biryani',
      '1x Zeera Raita',
      '1x Chilled Soft Drink 345ml',
      '1x Traditional Shahi Kheer'
    ],
    serves: 'Serves 1 - 2 persons',
    image_url: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80',
    badge: 'Lunch Special',
    is_active: true
  }
];

export const INITIAL_OFFERS: Offer[] = [
  {
    id: 'offer-first-order',
    title: 'First Order Discount',
    code: 'FIRST20',
    discount_type: 'percent',
    discount_value: 20,
    applies_to: 'whole_order',
    description: 'Get 20% off on your very first online order at Royal Taste.',
    is_active: true
  },
  {
    id: 'offer-zinger',
    title: 'Zinger Burger Craze',
    discount_type: 'percent',
    discount_value: 15,
    applies_to: 'item',
    target_id: 'fast-1',
    description: '15% discount auto-applied on our signature Zinger Burger.',
    is_active: true
  },
  {
    id: 'offer-desserts',
    title: 'Sweet Tooth Treat',
    discount_type: 'percent',
    discount_value: 10,
    applies_to: 'category',
    target_id: 'desserts',
    description: 'Enjoy 10% off across all royal Pakistani and continental desserts.',
    is_active: true
  }
];

export const INITIAL_CHEFS: Chef[] = [
  {
    id: 'chef-1',
    name: 'Ustad Tariq Jamil',
    role: 'Executive Head Chef',
    experience: '24 Years Experience',
    specialty: 'Dum Pukht, Mughlai Karahi & Royal Handi',
    bio: 'Trained under Lahore\'s legendary royal kitchen masters, Ustad Tariq safeguards age-old dum cooking recipes and secret whole spice formulations.',
    image_url: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'chef-2',
    name: 'Grill Master Farhan Ali',
    role: 'Master BBQ & Tandoor Specialist',
    experience: '16 Years Experience',
    specialty: 'Live Charcoal Grills, Bihari Boti & Seekh Kebabs',
    bio: 'An artisan of fire and coal, Chef Farhan brings unmatchable tenderness and smoky essence to every cut of meat.',
    image_url: 'https://images.unsplash.com/photo-1581299894007-aaa50297cf16?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'chef-3',
    name: 'Aisha Noor Khan',
    role: 'Pastry & Continental Chef',
    experience: '12 Years Experience',
    specialty: 'Royal Fusion Desserts & Artisan Steaks',
    bio: 'Le Cordon Bleu alumnus marrying rich Pakistani traditional dessert techniques with contemporary European pastry craft.',
    image_url: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=600&q=80'
  }
];

export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'The Royal Dining Hall',
    category: 'Ambience',
    image_url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-2',
    title: 'Signature Mutton Karahi in Desi Ghee',
    category: 'Food',
    image_url: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-3',
    title: 'Live Charcoal BBQ Pit',
    category: 'Kitchen',
    image_url: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-4',
    title: 'Private Family Lounge',
    category: 'Ambience',
    image_url: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-5',
    title: 'Dum Biryani with Golden Saffron',
    category: 'Food',
    image_url: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-6',
    title: 'Clay Oven Fresh Butter Naan',
    category: 'Kitchen',
    image_url: 'https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-7',
    title: 'Prime Ribeye Steak with Pepper Glaze',
    category: 'Food',
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gal-8',
    title: 'Traditional Warm Gulab Jamun & Shahi Kheer',
    category: 'Dessert',
    image_url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80'
  }
];

export const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Syed Hamza Ali',
    role: 'Food Connoisseur & Foodie',
    rating: 5,
    comment: 'The Mutton Karahi and Malai Boti here are unmatched in Lahore! Tender meat that literally melts in your mouth, served with boiling desi ghee aroma. Truly a five-star royal experience.',
    date: '2 days ago',
    avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'test-2',
    name: 'Dr. Fatima Zahra',
    role: 'Family Regular',
    rating: 5,
    comment: 'We booked a private table for our anniversary celebration. The service was impeccable, warm ambience, and the Dum Biryani was fragrant to perfection. The online ordering with live location is fantastic too!',
    date: '1 week ago',
    avatar_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'test-3',
    name: 'Bilal Qureshi',
    role: 'Executive Director',
    rating: 5,
    comment: 'Royal Taste hosted our corporate dinner of 40 guests. From the soup starters to the Dynamite Prawns and Steaks, every single dish arrived hot, fresh, and exceptionally flavorful.',
    date: '2 weeks ago',
    avatar_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
  }
];

export const INITIAL_SITE_SETTINGS: SiteSettings = {
  restaurant_name: 'ROYAL TASTE – Fine Dining',
  tagline: 'Delicious Food, Unforgettable Moments',
  phone: '+92 42 3578 9901',
  whatsapp: '+92 300 8472910',
  manager_name: 'Muhammad Rizwan Khan',
  manager_number: '+92 300 8472910',
  email: 'info@royaltaste.pk',
  address: 'Plot 42-B, MM Alam Road, Gulberg III, Lahore, Punjab, Pakistan',
  hours: 'Monday – Sunday: 12:00 PM – 01:00 AM (Open 7 Days)',
  lat: 31.5102,
  lng: 74.3587,
  google_maps_embed_url: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3401.378772097072!2d74.35651131512836!3d31.51020098137351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3919045a27891cf3%3A0x86b03b7a5a8f4b0!2sM.M.+Alam+Rd%2C+Gulberg+III%2C+Lahore!5e0!3m2!1sen!2s!4v1620000000000!5m2!1sen!2s',
  free_delivery_minimum: 2000,
  announcement_banner: 'Free Delivery on Orders Above Rs 2000 across Lahore',
  social_facebook: 'https://facebook.com/royaltastepk',
  social_instagram: 'https://instagram.com/royaltastepk',
  social_youtube: 'https://youtube.com/@royaltastepk',
  social_tiktok: 'https://tiktok.com/@royaltastepk'
};
