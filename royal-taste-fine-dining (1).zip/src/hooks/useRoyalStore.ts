import { useSyncExternalStore } from 'react';
import { royalStore, RoyalTasteSnapshot } from '../services/store';

// Module-level stable references for useSyncExternalStore to prevent re-subscription and infinite loops
const subscribe = (onStoreChange: () => void) => royalStore.subscribe(onStoreChange);
const getSnapshot = (): RoyalTasteSnapshot => royalStore.getSnapshot();

export function useRoyalStore() {
  const state: RoyalTasteSnapshot = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getSnapshot
  );

  return {
    ...state,
    store: royalStore
  };
}
