/**
 * Automated AI-Driven Keyword Analysis & WhatsApp Response Template Generator
 * Designed for ROYAL TASTE – Fine Dining (MM Alam Road, Gulberg III, Lahore)
 * Features context entity extraction (guests, time, area, dishes, urgency) and tailored multi-perspective drafts.
 */

export interface ExtractedEntities {
  guestCount?: number;
  timeOrDate?: string;
  locationArea?: string;
  dishesMentioned: string[];
  urgency: 'high' | 'normal';
  sentimentIntent: 'booking' | 'delivery' | 'catering' | 'menu_inquiry' | 'deal' | 'complaint' | 'location' | 'dietary' | 'general';
}

export interface ResponseTemplates {
  customer: {
    regal: string;      // Gracious, formal Pakistani hospitality inquiry
    concise: string;    // Direct, fast message
    vip: string;        // VIP table / celebration inquiry
  };
  manager: {
    instantConfirmation: string;    // Direct confirmation acknowledging pax, time, address
    executiveHospitality: string;  // Detailed warm greeting, mentions desi ghee, halal, ambiance
    followUpAction: string;        // Clear next steps (e.g. sharing Google Maps pin, menu PDF link)
  };
}

export interface KeywordRule {
  id: string;
  category: string;
  intent: ExtractedEntities['sentimentIntent'];
  keywords: string[];
  quickActionLabel: string;
  customerDrafts: (entities: ExtractedEntities, text: string) => {
    regal: string;
    concise: string;
    vip: string;
  };
  managerDrafts: (customerName: string, entities: ExtractedEntities, text: string) => {
    instantConfirmation: string;
    executiveHospitality: string;
    followUpAction: string;
  };
}

// -------------------------------------------------------------
// Entity Extraction Utilities
// -------------------------------------------------------------

export function extractEntities(text: string): ExtractedEntities {
  const normalized = text.toLowerCase();

  // 1. Extract Guest Count (e.g., "for 6 persons", "10 guests", "table for 4", "family of 8")
  let guestCount: number | undefined;
  const guestMatch =
    normalized.match(/(\d+)\s*(?:guests?|persons?|people|pax|seats?|heads?|family members?|banday)/i) ||
    normalized.match(/(?:table for|booking for|party of|seats? for)\s*(\d+)/i) ||
    normalized.match(/(?:family of|group of)\s*(\d+)/i);

  if (guestMatch) {
    guestCount = parseInt(guestMatch[1], 10);
  }

  // 2. Extract Time or Date references
  let timeOrDate: string | undefined;
  const timeMatch =
    normalized.match(/(\b(?:[0-1]?[0-9]|2[0-3])(?::[0-5][0-9])?\s*(?:am|pm)\b)/i) ||
    normalized.match(/\b(tonight|tomorrow(?: night| evening)?|this evening|today lunch|dinner|at lunch|at dinner|sunday evening|friday night)\b/i) ||
    normalized.match(/\b(8\s*pm|9\s*pm|10\s*pm|7\s*pm|8:30|9:30|10:30|1:00\s*pm|2\s*pm)\b/i);

  if (timeMatch) {
    timeOrDate = timeMatch[0].trim();
  }

  // 3. Extract Lahore Localities
  let locationArea: string | undefined;
  const areas = [
    { name: 'DHA Phase 6', regex: /dha\s*(?:phase)?\s*6/i },
    { name: 'DHA Phase 5', regex: /dha\s*(?:phase)?\s*5/i },
    { name: 'DHA Phase 1-4', regex: /dha\s*(?:phase)?\s*[1-4]/i },
    { name: 'DHA Lahore', regex: /\bdha\b/i },
    { name: 'Gulberg III (MM Alam Road)', regex: /(?:mm alam|gulberg\s*3|gulberg\s*iii)/i },
    { name: 'Gulberg', regex: /\bgulberg\b/i },
    { name: 'Johar Town', regex: /johar\s*town/i },
    { name: 'Model Town', regex: /model\s*town/i },
    { name: 'Cantt / Askari', regex: /(?:cantt|askari\s*\d*|defence raya)/i },
    { name: 'Bahria Town', regex: /bahria\s*(?:town)?/i },
    { name: 'Wapda Town', regex: /wapda\s*town/i },
    { name: 'Faisal Town', regex: /faisal\s*town/i },
    { name: 'Garden Town', regex: /garden\s*town/i },
    { name: 'Cavalry Ground', regex: /cavalry\s*ground/i }
  ];

  for (const item of areas) {
    if (item.regex.test(normalized)) {
      locationArea = item.name;
      break;
    }
  }

  // 4. Extract Signature Dishes
  const knownDishes = [
    'Mutton Karahi', 'Chicken Karahi', 'Shinwari Karahi', 'Chicken Handi', 'Beef Nihari',
    'Haleem', 'Paya', 'Chicken Biryani', 'Mutton Biryani', 'Malai Boti', 'Seekh Kebab',
    'Reshmi Kebab', 'Bihari Boti', 'Mutton Chops', 'Chicken Chargha', 'BBQ Platter',
    'Zinger Burger', 'Alfredo Pasta', 'Ribeye Steak', 'Grilled Salmon', 'Molten Lava Cake',
    'Shahi Kheer', 'Gulab Jamun', 'Mint Margarita', 'Desi Ghee'
  ];

  const dishesMentioned: string[] = [];
  for (const dish of knownDishes) {
    if (normalized.includes(dish.toLowerCase())) {
      dishesMentioned.push(dish);
    }
  }

  // 5. Detect Urgency
  const urgentKeywords = ['urgent', 'emergency', 'asap', 'immediately', 'right now', 'delay', 'late', 'where is', 'waiting', 'complaint'];
  const isUrgent = urgentKeywords.some((w) => normalized.includes(w));

  return {
    guestCount,
    timeOrDate,
    locationArea,
    dishesMentioned,
    urgency: isUrgent ? 'high' : 'normal',
    sentimentIntent: 'general'
  };
}

// -------------------------------------------------------------
// Comprehensive Keyword Rules Catalog
// -------------------------------------------------------------

export const KEYWORD_RULES: KeywordRule[] = [
  {
    id: 'reservation',
    category: 'Table Reservation & Celebrations',
    intent: 'booking',
    keywords: [
      'table', 'reservation', 'reserve', 'book', 'booking', 'seats', 'pax', 'guests',
      'birthday', 'anniversary', 'family', 'candle light', 'private hall', 'booth',
      'tonight', 'dinner table', 'lunch table', 'sitting', 'executive table'
    ],
    quickActionLabel: 'Confirm Table Booking',
    customerDrafts: (entities, text) => {
      const paxText = entities.guestCount ? ` for ${entities.guestCount} guests` : '';
      const timeText = entities.timeOrDate ? ` (${entities.timeOrDate})` : ' for tonight';
      return {
        regal: `Assalam-o-Alaikum Royal Taste Concierge! 👑\nI would be honored to reserve a regal dining table${paxText}${timeText}.\n\nInquiry details: "${text.trim()}"\n\nPlease let me know table availability and private booth options. Thank you!`,
        concise: `Assalam-o-Alaikum! Please check table availability${paxText}${timeText} at Royal Taste. Details: ${text.trim()}`,
        vip: `Assalam-o-Alaikum Manager Muhammad Rizwan! 👑\nWe are planning an exclusive celebration${paxText}${timeText} at Royal Taste. Kindly arrange an executive family table with special floral decor if available.\n\nNote: "${text.trim()}"`
      };
    },
    managerDrafts: (name, entities, text) => {
      const guestPhrase = entities.guestCount ? `for ${entities.guestCount} guests` : 'for your gathering';
      const timePhrase = entities.timeOrDate ? `at ${entities.timeOrDate}` : 'tonight';
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Honored Guest'}! 👑\nThis is Muhammad Rizwan, General Manager at Royal Taste.\n\nI have noted your request for a table ${guestPhrase} ${timePhrase}.\n\n✅ Executive Family Booth reserved on MM Alam Road, Gulberg III.\n✅ Complimentary valet parking arranged.\n\nPlease reply with your preferred arrival time to secure your instant VIP table pass. Looking forward to welcoming you!`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Distinguished Guest'}, General Manager Muhammad Rizwan here.\n\nThank you for choosing Royal Taste Fine Dining! Our royal culinary masters would be overjoyed to host you ${guestPhrase}.\n\nAll our dishes are prepared fresh upon order in 100% pure dairy desi ghee. May I also recommend reserving our signature Shinwari Mutton Karahi and Charcoal Malai Boti in advance for seamless service?`,
        followUpAction: `Assalam-o-Alaikum ${name || 'Dear Guest'}! Here are our restaurant details for your booking:\n📍 Location: Plot 42-B, MM Alam Road, Gulberg III, Lahore\n🗺️ Google Maps: https://maps.google.com/?q=31.5102,74.3587\n⏰ Dining Hours: 12:00 PM – 01:00 AM\n\nI will personally greet you at the reception entrance upon arrival.`
      };
    }
  },
  {
    id: 'delivery',
    category: 'Home Delivery & Area Coverage',
    intent: 'delivery',
    keywords: [
      'delivery', 'deliver', 'rider', 'takeaway', 'parcel', 'home delivery', 'address',
      'dha', 'gulberg', 'johar town', 'model town', 'cantt', 'bahria', 'charges', 'fee',
      'minimum order', 'packaging', 'thermal', 'hot delivery', 'eta'
    ],
    quickActionLabel: 'Dispatch Delivery ETA',
    customerDrafts: (entities, text) => {
      const areaText = entities.locationArea ? ` to ${entities.locationArea}` : '';
      return {
        regal: `Assalam-o-Alaikum Royal Taste Dispatch! 🛵\nI would like to place an order for home delivery${areaText}.\n\nOrder notes: "${text.trim()}"\n\nPlease confirm delivery coverage, estimated preparation time, and free delivery qualification (orders above Rs 2,000). Thank you!`,
        concise: `Assalam-o-Alaikum! Looking to order food delivery${areaText}. Can you deliver here and what is the ETA? Query: ${text.trim()}`,
        vip: `Assalam-o-Alaikum Royal Taste Management! 👑\nWe request express thermal-insulated delivery${areaText}.\nSpecial Instructions: "${text.trim()}". Kindly dispatch your senior rider with fresh salad and zeera raita.`
      };
    },
    managerDrafts: (name, entities, text) => {
      const areaPhrase = entities.locationArea ? `in ${entities.locationArea}` : 'to your doorstep';
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Valued Guest'}! 🛵\nManager Muhammad Rizwan here from Royal Taste.\n\nYes, we provide express hot delivery ${areaPhrase} in specialized thermal food warmers!\n\n• Delivery Time: 35–45 minutes\n• Free Delivery: On all orders above Rs 2,000\n• Included: Complimentary fresh mint salad, zeera raita & hot tandoori roghni naans.\n\nPlease share your exact delivery address or pin location to begin preparation!`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Respected Patron'}! Royal Taste delivers five-star Mughlai and Pakistani cuisine directly to your home. Every handi and karahi is cooked freshly in pure desi ghee so it arrives piping hot and full of aroma. What delicacies may we prepare for you today?`,
        followUpAction: `Assalam-o-Alaikum! Please tap below to share your live WhatsApp location with our delivery dispatch team: 📍\nOnce received, our executive chef will start your order immediately.`
      };
    }
  },
  {
    id: 'desi_karahi',
    category: 'Royal Shinwari, Karahi & Pure Desi Ghee',
    intent: 'menu_inquiry',
    keywords: [
      'karahi', 'mutton karahi', 'chicken karahi', 'shinwari', 'desi ghee', 'handi',
      'beef nihari', 'haleem', 'paya', 'chicken qorma', 'daal mash', 'roghni naan',
      'half', 'full', 'spicy', 'lamb', 'fresh slaughter', 'gravy'
    ],
    quickActionLabel: 'Share Karahi Menu & Timings',
    customerDrafts: (entities, text) => {
      const dishList = entities.dishesMentioned.length > 0 ? ` (${entities.dishesMentioned.join(', ')})` : '';
      return {
        regal: `Assalam-o-Alaikum Royal Taste Kitchen! 🥘\nI would love to inquire about your authentic desi karahi & handi specialties${dishList}.\n\nMy inquiry: "${text.trim()}"\n\nPlease let me know preparation time and pure desi ghee options. Thank you!`,
        concise: `Assalam-o-Alaikum! How long does the fresh Shinwari / Mutton Karahi take to prepare today? "${text.trim()}"`,
        vip: `Assalam-o-Alaikum Chef Team at Royal Taste! 👑\nWe would like to pre-order your signature Mutton Karahi and Chicken Handi simmered in 100% pure dairy desi ghee. Query: "${text.trim()}".`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Culinary Connoisseur'}! 🥘\nGeneral Manager Muhammad Rizwan here.\n\nOur authentic Shinwari and Royal Karahis are cooked fresh from scratch in 100% pure dairy desi ghee with freshly butchered farm meats and organic green chilies.\n\n• Mutton Karahi: Half (Rs 2,400) | Full (Rs 4,600)\n• Chicken Karahi: Half (Rs 1,500) | Full (Rs 2,800)\n• Cooking Time: ~35 mins (to ensure succulent tenderness)\n\nWould you like me to place your order with our master chef right now?`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Dear Food Lover'}! At Royal Taste, we never re-heat or pre-cook gravies. Each karahi is wok-tossed over high flame upon your order, accompanied by piping hot sesame Roghni Naans fresh from our clay tandoor. You will taste the regal difference!`,
        followUpAction: `Assalam-o-Alaikum! Would you prefer mild, medium, or traditional Shinwari black pepper seasoning for your karahi? Let me know and I will customize the spice blend.`
      };
    }
  },
  {
    id: 'bbq_kebabs',
    category: 'Charcoal BBQ, Kebabs & Signature Platters',
    intent: 'menu_inquiry',
    keywords: [
      'bbq', 'boti', 'malai boti', 'seekh kebab', 'reshmi kebab', 'bihari boti',
      'mutton chops', 'chargha', 'platter', 'bbq platter', 'tikka', 'chest piece',
      'leg piece', 'sajji', 'charcoal', 'grill', 'smoky'
    ],
    quickActionLabel: 'Recommend BBQ Platters',
    customerDrafts: (entities, text) => {
      return {
        regal: `Assalam-o-Alaikum! 🍢 I would like to inquire about your charcoal BBQ selections and platters.\n\nDetails: "${text.trim()}"\n\nPlease let me know if the BBQ Platter for 2 or Mutton Chops are available tonight. Thank you!`,
        concise: `Assalam-o-Alaikum! Inquiring about your BBQ menu and availability: "${text.trim()}".`,
        vip: `Assalam-o-Alaikum Manager Rizwan! 👑\nWe want to order an executive Charcoal BBQ assortment (Malai Boti, Reshmi Kebab, and Mutton Chops). Details: "${text.trim()}".`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Honored Guest'}! 🍢\nGeneral Manager Muhammad Rizwan here.\n\nOur live charcoal grills are fired up! We marinate our cuts in Greek yogurt, green papaya, and royal Mughlai spices for 12 hours:\n\n• BBQ Platter (for 2) Rs 3,200 (Malai Boti, Seekh Kebabs, Tikka & Chops)\n• Charcoal Malai Boti Rs 1,100 (melt-in-mouth creamy)\n• Mutton Chops (6 pcs) Rs 2,200\n\nShall I have our pitmaster prepare a platter for your dining?`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Valued Guest'}! Every skewer at Royal Taste is grilled over natural wood charcoal to give you that authentic Lahore smoky flavor without any artificial food coloring or tenderizers. Served with mint chutney and hot tandoori roghni naan!`,
        followUpAction: `Assalam-o-Alaikum! If you are ordering for a group, our Royal BBQ Grand Platter includes both mutton and chicken skewers. Would you like me to book it for you?`
      };
    }
  },
  {
    id: 'catering_events',
    category: 'Banquets, Corporate Catering & Hi-Tea',
    intent: 'catering',
    keywords: [
      'catering', 'banquet', 'event', 'corporate', 'wedding', 'valima', 'reception',
      'buffet', 'gathering', 'hall', '50', '100', '200', '30', '40', 'party',
      'headcount', 'per head', 'quote', 'quotation', 'live station', 'executive dinner'
    ],
    quickActionLabel: 'Send Custom Catering Quote',
    customerDrafts: (entities, text) => {
      const guestPhrase = entities.guestCount ? ` for approx ${entities.guestCount} guests` : '';
      return {
        regal: `Assalam-o-Alaikum Royal Taste Executive Management! 👑\nWe are organizing a private corporate banquet / family event${guestPhrase}.\n\nEvent details: "${text.trim()}"\n\nPlease share your premium buffet packages, live BBQ cooking station options, and per-head rates. Thank you!`,
        concise: `Assalam-o-Alaikum! Need catering quotation${guestPhrase} for a private function. Details: ${text.trim()}`,
        vip: `Assalam-o-Alaikum General Manager Muhammad Rizwan! 👑\nI am planning a VIP gala dinner${guestPhrase} and require Royal Taste's high-end catering with Mughlai live stations and uniformed executive waitstaff. Kindly review: "${text.trim()}".`
      };
    },
    managerDrafts: (name, entities, text) => {
      const pax = entities.guestCount || 50;
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Distinguished Host'}! 👑\nThis is Muhammad Rizwan, General Manager at Royal Taste.\n\nIt would be our honor to cater your prestigious event (${pax} guests). We offer full-service catering with:\n\n✨ Live Tandoori Naan & Charcoal BBQ setups\n✨ Copper degh presentations with pure desi ghee mutton karahi & biryani\n✨ Royal dessert bars & mocktail stations\n✨ Professional executive service staff\n\nMay I call you directly on this number to understand your exact menu preferences and date?`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Respected Patron'}! Royal Taste has hosted over 500 prestigious corporate galas, ambassador receptions, and wedding valimas across Lahore. We guarantee punctuality, flawless presentation, and food that your guests will talk about for months.`,
        followUpAction: `Assalam-o-Alaikum! I have prepared 3 bespoke event packages (Silver, Gold Royal, and Imperial Mughlai) ranging from Rs 2,450 to Rs 3,950 per head. Shall I send the complete PDF catalog right here on WhatsApp?`
      };
    }
  },
  {
    id: 'deals_discounts',
    category: 'Deals, Discounts & Promo Codes',
    intent: 'deal',
    keywords: [
      'deal', 'deals', 'offer', 'offers', 'discount', 'first20', 'family deal',
      'student deal', 'lunch deal', 'promo', 'coupon', 'code', 'save', 'budget',
      'combo', 'rates', 'best price', 'special offer'
    ],
    quickActionLabel: 'Apply Discount Code',
    customerDrafts: (entities, text) => {
      return {
        regal: `Assalam-o-Alaikum! 🏷️ I am inquiring about current discount packages and promotional deals at Royal Taste.\n\nQuery: "${text.trim()}"\n\nCould you please confirm if the 20% first order code (FIRST20) or Family Deals can be applied today? Thank you!`,
        concise: `Assalam-o-Alaikum! What special deals or promo discount codes are active today? "${text.trim()}"`,
        vip: `Assalam-o-Alaikum Manager Rizwan! 🏷️ Please share your best family combo deal and how to apply the *FIRST20* 20% privilege code for our order: "${text.trim()}".`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Valued Guest'}! 🎉\nGeneral Manager Muhammad Rizwan here.\n\nHere are our top active privilege deals today:\n\n• *FIRST20* Privilege: 20% OFF your entire first order!\n• *Family Feast Deal* (Rs 4,999): Full Chicken Karahi, 2 Special Biryanis, 6 Naans, Raita & 1.5L drink (serves 5-6)\n• *Executive Lunch Deal* (Rs 1,199): Chicken Biryani, Zeera Raita, Royal Shahi Kheer & Drink\n• *Student Saver* (Rs 799): Crispy Zinger Burger, Fries & Soft Drink\n\nWhich deal would you like me to book for you right away?`,
        executiveHospitality: `Assalam-o-Alaikum! At Royal Taste, our deals feature the exact same premium quality meat and pure desi ghee as our à la carte menu. You get maximum royal value with uncompromised five-star taste!`,
        followUpAction: `Assalam-o-Alaikum! Simply type *CONFIRM DEAL* and share your address/dining time, and I will lock in the 20% discount on your bill immediately.`
      };
    }
  },
  {
    id: 'halal_ingredients',
    category: 'Halal Standards, Hygiene & Meat Sourcing',
    intent: 'menu_inquiry',
    keywords: [
      'halal', 'certified', 'meat', 'mutton', 'beef', 'slaughter', 'hygiene',
      'desi ghee', 'pure dairy', 'clean', 'oil', 'organic', 'safe', 'food authority',
      'tour', 'kitchen'
    ],
    quickActionLabel: 'Verify Halal & Ghee Purity',
    customerDrafts: (entities, text) => {
      return {
        regal: `Assalam-o-Alaikum Royal Taste Management! 🛡️\nI would appreciate information regarding your Halal sourcing and cooking standards.\n\nQuery: "${text.trim()}"\n\nCould you please confirm your meat slaughter sources and desi ghee purity? Thank you!`,
        concise: `Assalam-o-Alaikum! Could you confirm if all meats are 100% Halal certified and cooked in pure dairy desi ghee? "${text.trim()}"`,
        vip: `Assalam-o-Alaikum Manager Rizwan! We maintain strict dietary & Halal standards. Kindly confirm meat sourcing and cooking fats used at Royal Taste: "${text.trim()}".`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Respected Patron'}! 🛡️\nGeneral Manager Muhammad Rizwan here.\n\nWe take sacred pride in our culinary integrity:\n\n✅ 100% Hand-Slaughtered Zabiha Halal meats procured daily from certified local farms.\n✅ 100% Pure Dairy Desi Ghee (no banaspati or trans-fats in our karahis and handis).\n✅ Punjab Food Authority A+ Grade certified commercial hygiene standards.\n\nYou and your family can dine with absolute trust and peace of mind!`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Honored Guest'}! Our open-view kitchen allows our guests to observe our chefs preparing each meal fresh. We would be honored to show you our clean kitchen on your next visit to MM Alam Road!`,
        followUpAction: `Assalam-o-Alaikum! If you or any family members have specific ingredient sensitivities or prefer low-sodium cooking, our chef can tailor your dish individually.`
      };
    }
  },
  {
    id: 'location_timings',
    category: 'Location, Directions, Valet & Hours',
    intent: 'location',
    keywords: [
      'location', 'where', 'address', 'directions', 'map', 'mm alam', 'gulberg',
      'lahore', 'hours', 'timing', 'time', 'open', 'close', 'midnight', 'parking',
      'valet', 'late night', 'distance'
    ],
    quickActionLabel: 'Send Google Maps Pin & Hours',
    customerDrafts: (entities, text) => {
      return {
        regal: `Assalam-o-Alaikum Royal Taste Reception! 📍\nCould you kindly share the exact location, valet parking facilities, and operating hours for Royal Taste?\n\nInquiry: "${text.trim()}"`,
        concise: `Assalam-o-Alaikum! What are your dining hours tonight and do you have valet parking? "${text.trim()}"`,
        vip: `Assalam-o-Alaikum Manager Muhammad Rizwan! 📍 Please share the direct Google Maps navigation pin and parking instructions for our arrival at MM Alam Road: "${text.trim()}".`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Dear Guest'}! 📍\nGeneral Manager Muhammad Rizwan here.\n\nHere are our direct restaurant details:\n\n• Address: Plot 42-B, MM Alam Road, Gulberg III, Lahore (Culinary Center)\n• Dining Hours: 12:00 PM – 01:00 AM (7 Days a week)\n• Valet Parking: Complimentary valet right at our royal entrance\n• Direct Pin: https://maps.google.com/?q=31.5102,74.3587\n\nWe look forward to hosting you!`,
        executiveHospitality: `Assalam-o-Alaikum! We are centrally situated in Gulberg III right across from top boutiques on MM Alam Road. Our uniformed valet will take care of your vehicle the moment you arrive so your dining experience starts seamlessly.`,
        followUpAction: `Assalam-o-Alaikum! If you need help finding us while driving, please call me directly at +92 300 1234567 and our staff will guide you right to our doorway.`
      };
    }
  },
  {
    id: 'dietary_custom',
    category: 'Dietary Preferences, Vegetarian & Spice Customization',
    intent: 'dietary',
    keywords: [
      'veg', 'vegetarian', 'paneer', 'palak paneer', 'daal', 'daal mash', 'daal fry',
      'mix sabzi', 'salad', 'spice', 'less spicy', 'mild', 'no chili', 'kids',
      'elderly', 'allergy', 'gluten', 'peanuts', 'diabetic', 'low oil'
    ],
    quickActionLabel: 'Customize Spices & Diet Menu',
    customerDrafts: (entities, text) => {
      return {
        regal: `Assalam-o-Alaikum Royal Taste Chef! 🥦\nI have a special dietary / spice customization request for our dining.\n\nDetails: "${text.trim()}"\n\nPlease confirm if your kitchen can prepare mild or vegetarian options for us. Thank you!`,
        concise: `Assalam-o-Alaikum! Can you prepare dishes with mild spices or vegetarian options? Details: "${text.trim()}"`,
        vip: `Assalam-o-Alaikum Manager Rizwan! 🥦 We have guests with dietary restrictions (mild spices / vegetarian preferences). Details: "${text.trim()}". Please ensure our chef prepares these dishes separately.`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Respected Guest'}! 🥦\nGeneral Manager Muhammad Rizwan here.\n\nAbsolutely! Because every single dish at Royal Taste is cooked freshly to order, our chefs can easily customize:\n\n• Spice Level: Mild / Kids-friendly, Medium, or Traditional Shinwari\n• Vegetarian Specialties: Palak Paneer (Rs 750), Daal Mash simmered in butter (Rs 650), Daal Fry (Rs 550) & Mix Sabzi (Rs 600)\n• Low-Oil & No-Salt options available on request\n\nPlease let me know your preferred dishes and our executive chef will prepare them to your exact specifications!`,
        executiveHospitality: `Assalam-o-Alaikum! We cater to all generations of Pakistani families, from young children to respected elders. Tell us your preference and we guarantee an exquisite, comfortable dining experience.`,
        followUpAction: `Assalam-o-Alaikum! Would you like me to send you our dedicated vegetarian and continental menu options?`
      };
    }
  },
  {
    id: 'complaints_delays',
    category: 'Order Delays, Service Feedback & Priority Escalation',
    intent: 'complaint',
    keywords: [
      'late', 'delay', 'rider late', 'cold food', 'complain', 'complaint', 'issue',
      'wrong order', 'missing item', 'refund', 'talk to manager', 'urgent',
      'waiting too long', 'rider where', 'unsatisfied'
    ],
    quickActionLabel: 'Priority Manager Escalation',
    customerDrafts: (entities, text) => {
      return {
        regal: `Assalam-o-Alaikum General Manager Muhammad Rizwan! ⚠️\nI need immediate assistance with an ongoing order / service issue.\n\nProblem details: "${text.trim()}"\n\nPlease contact me urgently to resolve this. Thank you.`,
        concise: `Assalam-o-Alaikum! There is an issue with my order/delivery: "${text.trim()}". Please update me immediately.`,
        vip: `Assalam-o-Alaikum Manager Rizwan! ⚠️ Urgent escalation regarding our order: "${text.trim()}". Please look into this personally.`
      };
    },
    managerDrafts: (name, entities, text) => {
      return {
        instantConfirmation: `Assalam-o-Alaikum ${name || 'Dear Patron'}, this is Muhammad Rizwan, General Manager at Royal Taste.\n\nI have personally taken notice of your message and sincerely apologize for this inconvenience. ⚠️\n\nI am looking into your order dispatch immediately and will update you within 2 minutes. Your absolute satisfaction is my personal responsibility. Please share your order number if handy.`,
        executiveHospitality: `Assalam-o-Alaikum ${name || 'Respected Patron'}. Royal Taste stands behind every single dish we serve. If anything has not met royal standards, I will personally arrange an immediate replacement or full resolution. I am calling you right now.`,
        followUpAction: `Assalam-o-Alaikum! I have dispatched our supervisory team to handle your matter directly. Thank you for your patience.`
      };
    }
  }
];

// -------------------------------------------------------------
// Core Analysis Engine
// -------------------------------------------------------------

export interface KeywordAnalysisResult {
  matchedCategory: string;
  matchedKeywords: string[];
  confidenceScore: number;
  entities: ExtractedEntities;
  templates: ResponseTemplates;
  quickActionLabel: string;
  suggestedCustomerDraft: string;
  suggestedManagerDraft: string;
}

export function analyzeInquiryKeywords(text: string, customerName: string = ''): KeywordAnalysisResult {
  const normalized = text.toLowerCase().trim();
  const entities = extractEntities(text);

  let bestRule: KeywordRule | null = null;
  let highestScore = 0;
  let matchedKeywords: string[] = [];

  // Match rules
  for (const rule of KEYWORD_RULES) {
    let score = 0;
    const hits: string[] = [];

    for (const kw of rule.keywords) {
      if (normalized.includes(kw)) {
        // Multi-word keywords get higher weight
        const weight = kw.split(' ').length > 1 ? 3 : 1.5;
        score += weight;
        hits.push(kw);
      }
    }

    if (score > highestScore) {
      highestScore = score;
      bestRule = rule;
      matchedKeywords = hits;
    }
  }

  // Calculate confidence score (0 to 100%)
  const confidenceScore = Math.min(100, Math.round(highestScore * 20));

  // Fallback for general inquiries
  if (!bestRule || highestScore === 0) {
    const generalCustomerDrafts = {
      regal: `Assalam-o-Alaikum Royal Taste Management! 👑\nI am contacting you regarding: "${text.trim() || 'table dining and delivery service'}"\n\nCould you please guide me on available options and timings? Thank you!`,
      concise: `Assalam-o-Alaikum! Inquiring about Royal Taste dining & menu: "${text.trim() || 'Please share details.'}"`,
      vip: `Assalam-o-Alaikum Manager Muhammad Rizwan! 👑 I would like to inquire about fine dining services at Royal Taste. Details: "${text.trim() || 'Please share your recommendations.'}"`
    };

    const generalManagerDrafts = {
      instantConfirmation: `Assalam-o-Alaikum ${customerName || 'Honored Guest'}! 👑\nThis is Muhammad Rizwan, General Manager at Royal Taste Fine Dining.\n\nThank you for reaching out! I have received your message: "${text.trim() || 'Inquiry received'}"\n\nHow may I best assist you today? I am at your service for table bookings on MM Alam Road, fast home delivery, or customized catering packages.`,
      executiveHospitality: `Assalam-o-Alaikum ${customerName || 'Distinguished Guest'}! Welcome to Royal Taste. We serve 100 authentic Pakistani dishes simmered in pure dairy desi ghee, live charcoal BBQ, and continental classics. May I send you our digital menu card?`,
      followUpAction: `Assalam-o-Alaikum! You can reach me directly on this WhatsApp line at any time. We look forward to serving you with royal warmth.`
    };

    return {
      matchedCategory: 'General Inquiry & Assistance',
      matchedKeywords: ['royal inquiry'],
      confidenceScore: 35,
      entities,
      templates: {
        customer: generalCustomerDrafts,
        manager: generalManagerDrafts
      },
      quickActionLabel: 'Connect with General Manager',
      suggestedCustomerDraft: generalCustomerDrafts.regal,
      suggestedManagerDraft: generalManagerDrafts.instantConfirmation
    };
  }

  // Extract generated drafts from the winning rule
  const customerDrafts = bestRule.customerDrafts(entities, text);
  const managerDrafts = bestRule.managerDrafts(customerName, entities, text);

  return {
    matchedCategory: bestRule.category,
    matchedKeywords,
    confidenceScore: Math.max(50, confidenceScore),
    entities,
    templates: {
      customer: customerDrafts,
      manager: managerDrafts
    },
    quickActionLabel: bestRule.quickActionLabel,
    suggestedCustomerDraft: customerDrafts.regal,
    suggestedManagerDraft: managerDrafts.instantConfirmation
  };
}
