import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Environment variables or localStorage fallback for runtime Supabase credentials
const envUrl = import.meta.env.VITE_SUPABASE_URL;
const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const getStoredSupabaseConfig = () => {
  const localUrl = localStorage.getItem('rt_supabase_url');
  const localKey = localStorage.getItem('rt_supabase_key');
  return {
    url: envUrl || localUrl || '',
    key: envKey || localKey || ''
  };
};

export const saveSupabaseConfig = (url: string, key: string) => {
  if (url) localStorage.setItem('rt_supabase_url', url.trim());
  else localStorage.removeItem('rt_supabase_url');

  if (key) localStorage.setItem('rt_supabase_key', key.trim());
  else localStorage.removeItem('rt_supabase_key');
};

let cachedClient: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient | null => {
  const { url, key } = getStoredSupabaseConfig();
  if (!url || !key) {
    return null;
  }
  if (!cachedClient) {
    try {
      cachedClient = createClient(url, key, {
        auth: {
          persistSession: true,
          autoRefreshToken: true
        }
      });
    } catch (err) {
      console.warn('Could not initialize Supabase client:', err);
      return null;
    }
  }
  return cachedClient;
};

export const isSupabaseConfigured = (): boolean => {
  const { url, key } = getStoredSupabaseConfig();
  return Boolean(url && key);
};
