import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { analyzeInquiryKeywords } from './src/utils/aiResponseTemplates.ts';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// Initialize Google Gen AI client with telemetry user-agent header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

// API Route: AI-Driven WhatsApp Response Draft Generator
app.post('/api/ai/draft-response', async (req: Request, res: Response) => {
  try {
    const {
      message = '',
      customerName = '',
      perspective = 'manager',
      templateStyle = 'default'
    } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message content is required.' });
      return;
    }

    // Comprehensive keyword and entity analysis
    const keywordAnalysis = analyzeInquiryKeywords(message, customerName);

    // If Gemini API Key is available, generate an authentic, bespoke royal response
    if (process.env.GEMINI_API_KEY) {
      try {
        const entitySummary = [
          keywordAnalysis.entities.guestCount ? `Guest Count: ${keywordAnalysis.entities.guestCount}` : null,
          keywordAnalysis.entities.timeOrDate ? `Time/Date: ${keywordAnalysis.entities.timeOrDate}` : null,
          keywordAnalysis.entities.locationArea ? `Delivery/Location: ${keywordAnalysis.entities.locationArea}` : null,
          keywordAnalysis.entities.dishesMentioned.length > 0 ? `Dishes: ${keywordAnalysis.entities.dishesMentioned.join(', ')}` : null,
          `Urgency: ${keywordAnalysis.entities.urgency}`
        ].filter(Boolean).join(' | ');

        const promptRole = perspective === 'customer'
          ? `You are assisting a customer drafting a WhatsApp message to General Manager Muhammad Rizwan at ROYAL TASTE – Fine Dining (MM Alam Road, Gulberg III, Lahore).
Customer's raw query: "${message}".
Detected Context: ${entitySummary}.
Style requested: ${templateStyle} (options: regal, concise, vip).
Generate a polite, well-formatted WhatsApp message suitable for Pakistani fine dining etiquette. Include any specific guest count, time, area, or dishes detected. Use natural line breaks and greetings (Assalam-o-Alaikum). Maximum 80 words.`
          : `A customer named "${customerName || 'Honored Guest'}" sent this inquiry to ROYAL TASTE – Fine Dining: "${message}".
Detected Intent: ${keywordAnalysis.matchedCategory} (${entitySummary}).
Style requested: ${templateStyle} (options: instantConfirmation, executiveHospitality, followUpAction).
Draft a response from Muhammad Rizwan (General Manager at Royal Taste, MM Alam Road, Gulberg III, Lahore).
Acknowledge their inquiry with "Assalam-o-Alaikum", directly address their specific parameters (table reservation, delivery area, pure dairy desi ghee, 100% Halal certification, or pricing), and offer immediate assistance on WhatsApp.
Keep it warm, executive, respectful, and formatted for WhatsApp with tasteful bullet points if relevant. Maximum 120 words.`;

        const geminiResponse = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptRole,
          config: {
            systemInstruction: 'You are an executive communication AI for ROYAL TASTE – Fine Dining, a premier luxury Pakistani restaurant in Lahore. Your tone is regal, warmly hospitable, and respectful. Use clear WhatsApp-friendly formatting with tasteful bullet points and polite Pakistani hospitality greetings.',
            temperature: 0.7
          }
        });

        const aiDraft = geminiResponse.text?.trim();
        if (aiDraft) {
          res.json({
            success: true,
            source: 'gemini-3.8-flash',
            matchedCategory: keywordAnalysis.matchedCategory,
            matchedKeywords: keywordAnalysis.matchedKeywords,
            confidenceScore: keywordAnalysis.confidenceScore,
            entities: keywordAnalysis.entities,
            templates: keywordAnalysis.templates,
            quickActionLabel: keywordAnalysis.quickActionLabel,
            draft: aiDraft,
            fallbackTemplate: perspective === 'customer'
              ? keywordAnalysis.suggestedCustomerDraft
              : keywordAnalysis.suggestedManagerDraft
          });
          return;
        }
      } catch (geminiError: any) {
        console.warn('Gemini API call fallback to keyword rule template:', geminiError?.message || geminiError);
      }
    }

    // Graceful rule-based keyword response fallback
    res.json({
      success: true,
      source: 'keyword-rule-engine',
      matchedCategory: keywordAnalysis.matchedCategory,
      matchedKeywords: keywordAnalysis.matchedKeywords,
      confidenceScore: keywordAnalysis.confidenceScore,
      entities: keywordAnalysis.entities,
      templates: keywordAnalysis.templates,
      quickActionLabel: keywordAnalysis.quickActionLabel,
      draft: perspective === 'customer'
        ? keywordAnalysis.suggestedCustomerDraft
        : keywordAnalysis.suggestedManagerDraft,
      fallbackTemplate: perspective === 'customer'
        ? keywordAnalysis.suggestedCustomerDraft
        : keywordAnalysis.suggestedManagerDraft
    });
  } catch (error: any) {
    console.error('Error generating AI response draft:', error);
    res.status(500).json({ error: 'Failed to process inquiry template.' });
  }
});

// Setup Vite middlewares or static files serving
async function setupServer() {
  if (!isProduction && fs.existsSync(path.resolve('vite.config.ts'))) {
    // Development mode with Vite middleware
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Production mode: serve built assets from dist
    const distPath = path.resolve('dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Royal Taste Server running on http://0.0.0.0:${PORT}`);
  });
}

setupServer();
